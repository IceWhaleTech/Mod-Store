module github.com/IceWhaleTech/zimaos-photos

go 1.24.4

toolchain go1.24.13

require (
	github.com/DATA-DOG/go-sqlmock v1.5.2
	github.com/IceWhaleTech/ZimaOS-Common v1.8.0-alpha1
	github.com/andybalholm/brotli v1.2.1
	github.com/buckket/go-blurhash v1.1.0
	github.com/danlock/gogosseract v0.0.11-0ad3421.0.20250623141706-2521da518be1
	github.com/deepteams/webp v1.2.1
	github.com/disintegration/imaging v1.6.2
	github.com/dsoprea/go-exif/v3 v3.0.1
	github.com/ebitengine/purego v0.10.0
	github.com/fsnotify/fsnotify v1.7.0
	github.com/getkin/kin-openapi v0.133.0
	github.com/go-sql-driver/mysql v1.9.3
	github.com/labstack/echo/v4 v4.13.4
	github.com/oapi-codegen/echo-middleware v1.0.1
	github.com/oapi-codegen/runtime v1.1.2
	github.com/oov/psd v0.0.0-20260818185439-a5d50ec0acac
	github.com/orca-zhang/ecache v1.1.3
	github.com/orca-zhang/zerocopy v0.0.0-20240829071230-70d6b7386927
	github.com/tetratelabs/wazero v1.7.3
	github.com/zsefvlol/timezonemapper v1.0.0
	golang.org/x/image v0.0.0-20191009234506-e7c1f5e7dbb8
	golang.org/x/time v0.14.0
)

require (
	filippo.io/edwards25519 v1.1.0 // indirect
	github.com/danlock/pkg v0.0.18-fc7c42d // indirect
	github.com/dsoprea/go-logging v0.0.0-20200710184922-b02d349568dd // indirect
	github.com/dsoprea/go-utility/v2 v2.0.0-20221003172846-a3e1774ef349 // indirect
	github.com/go-errors/errors v1.4.2 // indirect
	github.com/golang-jwt/jwt/v4 v4.5.2 // indirect
	github.com/golang-jwt/jwt/v5 v5.2.2 // indirect
	github.com/golang/geo v0.0.0-20210211234256-740aa86cb551 // indirect
	github.com/gopherjs/gopherjs v1.21.0 // indirect
	github.com/gorilla/mux v1.8.0 // indirect
	github.com/hopehook/zerocopy v0.0.0-20240803102957-fd9339cc668e // indirect
	github.com/jerbob92/wazero-emscripten-embind v1.3.0 // indirect
	github.com/labstack/echo-jwt/v4 v4.3.1 // indirect
	github.com/onsi/ginkgo/v2 v2.20.0 // indirect
	github.com/onsi/gomega v1.34.1 // indirect
	golang.org/x/exp v0.0.0-20260112195511-716be5621a96 // indirect
	gopkg.in/yaml.v2 v2.4.0 // indirect
)

require (
	github.com/apapsch/go-jsonmerge/v2 v2.0.0 // indirect
	github.com/dlclark/regexp2 v1.4.0
	github.com/go-openapi/jsonpointer v0.21.0 // indirect
	github.com/go-openapi/swag v0.23.0 // indirect
	github.com/google/uuid v1.6.0 // indirect
	github.com/josharian/intern v1.0.0 // indirect
	github.com/labstack/gommon v0.4.2 // indirect
	github.com/mailru/easyjson v0.7.7 // indirect
	github.com/mattn/go-colorable v0.1.14 // indirect
	github.com/mattn/go-isatty v0.0.20 // indirect
	github.com/mohae/deepcopy v0.0.0-20170929034955-c48cc78d4826 // indirect
	github.com/nlpodyssey/gotokenizers v0.2.0
	github.com/oasdiff/yaml v0.0.0-20250309154309-f31be36b4037 // indirect
	github.com/oasdiff/yaml3 v0.0.0-20250309153720-d2182401db90 // indirect
	github.com/perimeterx/marshmallow v1.1.5 // indirect
	github.com/valyala/bytebufferpool v1.0.0 // indirect
	github.com/valyala/fasttemplate v1.2.2 // indirect
	github.com/woodsbury/decimal128 v1.3.0 // indirect
	golang.org/x/crypto v0.47.0 // indirect
	golang.org/x/net v0.49.0
	golang.org/x/sync v0.19.0
	golang.org/x/sys v0.40.0
	golang.org/x/text v0.33.0
	google.golang.org/protobuf v1.34.1
	gopkg.in/yaml.v3 v3.0.1 // indirect
)

replace github.com/deepteams/webp => github.com/orca-zhang/webp v0.0.0-20260910164801-1fc7048acbe9
