package embedtokenizer

import (
	"os"
	"path/filepath"
	"sync"
)

var (
	atomicWriteBundleArtifactHookMu sync.RWMutex
	atomicWriteBundleArtifactHook   func(targetPath string, tmpPath string)
)

func setAtomicWriteBundleArtifactHookForTest(hook func(targetPath string, tmpPath string)) {
	atomicWriteBundleArtifactHookMu.Lock()
	defer atomicWriteBundleArtifactHookMu.Unlock()
	atomicWriteBundleArtifactHook = hook
}

func atomicWriteBundleArtifact(targetPath string, data []byte, perm os.FileMode) error {
	return writeBundleArtifactAtomicallyWithTmpSuffix(targetPath, perm, func(file *os.File) error {
		_, err := file.Write(data)
		return err
	})
}

func writeBundleArtifactAtomicallyWithTmpSuffix(targetPath string, perm os.FileMode, writeFn func(file *os.File) error) error {
	if err := os.MkdirAll(filepath.Dir(targetPath), 0o755); err != nil {
		return err
	}
	tmpFile, err := os.CreateTemp(filepath.Dir(targetPath), "."+filepath.Base(targetPath)+"-*.tmp")
	if err != nil {
		return err
	}
	tmpPath := tmpFile.Name()
	defer func() {
		_ = tmpFile.Close()
		_ = os.Remove(tmpPath)
	}()
	notifyAtomicWriteBundleArtifactHook(targetPath, tmpPath)
	if err := tmpFile.Chmod(perm); err != nil {
		return err
	}
	if err := writeFn(tmpFile); err != nil {
		return err
	}
	if err := tmpFile.Close(); err != nil {
		return err
	}
	return os.Rename(tmpPath, targetPath)
}

func notifyAtomicWriteBundleArtifactHook(targetPath string, tmpPath string) {
	atomicWriteBundleArtifactHookMu.RLock()
	hook := atomicWriteBundleArtifactHook
	atomicWriteBundleArtifactHookMu.RUnlock()
	if hook != nil {
		hook(targetPath, tmpPath)
	}
}
