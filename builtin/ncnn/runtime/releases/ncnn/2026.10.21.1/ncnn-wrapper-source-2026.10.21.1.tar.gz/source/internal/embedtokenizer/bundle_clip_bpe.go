package embedtokenizer

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"github.com/dlclark/regexp2"
	"github.com/nlpodyssey/gotokenizers/models/bpemodel"
	"github.com/nlpodyssey/gotokenizers/pretokenizers/bytelevelpretokenizer"
	"github.com/nlpodyssey/gotokenizers/vocabulary"
	"golang.org/x/text/unicode/norm"
)

type clipBPETokenizer struct {
	modelDir        string
	tokenizer       *byteLevelBPETokenizer
	bosID           int
	eosID           int
	defaultMax      int
	endOfWordSuffix string
}

var clipByteLevelSplittingRegexp = regexp2.MustCompile(
	`'s|'t|'re|'ve|'m|'ll|'d|[\p{L}]+|[\p{N}]|[^\s\p{L}\p{N}]+`,
	regexp2.IgnoreCase|regexp2.Multiline,
)

func hasCLIPTokenizerAssets(modelDir string) bool {
	tokenizerPath := filepath.Join(modelDir, "tokenizer.json")
	info, err := os.Stat(tokenizerPath)
	if err != nil || info.IsDir() {
		return false
	}
	config, err := readTokenizerConfig(filepath.Join(modelDir, "tokenizer_config.json"))
	if err == nil && strings.EqualFold(strings.TrimSpace(config.TokenizerClass), "CLIPTokenizer") {
		return true
	}
	rawTokenizer, err := os.ReadFile(tokenizerPath)
	if err != nil {
		return false
	}
	var tokenizer tokenizerJSON
	if err := json.Unmarshal(rawTokenizer, &tokenizer); err != nil {
		return false
	}
	return strings.EqualFold(strings.TrimSpace(tokenizer.Model.Type), "BPE")
}

func prepareCLIPTokenizerArtifacts(modelDir string) error {
	modelDir = filepath.Clean(strings.TrimSpace(modelDir))
	if modelDir == "" {
		return fmt.Errorf("clip tokenizer model dir is required")
	}
	rawTokenizer, err := os.ReadFile(filepath.Join(modelDir, "tokenizer.json"))
	if err != nil {
		return fmt.Errorf("read tokenizer.json: %w", err)
	}
	var tokenizer tokenizerJSON
	if err := json.Unmarshal(rawTokenizer, &tokenizer); err != nil {
		return fmt.Errorf("decode tokenizer.json: %w", err)
	}
	if _, err := os.Stat(filepath.Join(modelDir, "vocab.json")); err != nil {
		rawVocab, err := marshalTokenizerVocabMap(tokenizer.Model.Vocab)
		if err != nil {
			return err
		}
		if writeErr := atomicWriteBundleArtifact(filepath.Join(modelDir, "vocab.json"), rawVocab, 0o644); writeErr != nil {
			return fmt.Errorf("write vocab.json: %w", writeErr)
		}
	}
	if _, err := os.Stat(filepath.Join(modelDir, "merges.txt")); err != nil {
		merges, err := extractTokenizerMerges(tokenizer.Model.Merges)
		if err != nil {
			return err
		}
		lines := append([]string{"#version: 0.2"}, merges...)
		if writeErr := atomicWriteBundleArtifact(filepath.Join(modelDir, "merges.txt"), []byte(strings.Join(lines, "\n")+"\n"), 0o644); writeErr != nil {
			return fmt.Errorf("write merges.txt: %w", writeErr)
		}
	}
	return nil
}

func loadCLIPTokenizer(modelDir string) (*clipBPETokenizer, error) {
	modelDir = filepath.Clean(strings.TrimSpace(modelDir))
	if modelDir == "" {
		return nil, fmt.Errorf("clip tokenizer model dir is required")
	}
	if err := prepareCLIPTokenizerArtifacts(modelDir); err != nil {
		return nil, err
	}
	rawTokenizer, err := os.ReadFile(filepath.Join(modelDir, "tokenizer.json"))
	if err != nil {
		return nil, fmt.Errorf("read tokenizer.json: %w", err)
	}
	var tokenizerSpec tokenizerJSON
	if err := json.Unmarshal(rawTokenizer, &tokenizerSpec); err != nil {
		return nil, fmt.Errorf("decode tokenizer.json: %w", err)
	}
	vocab, err := vocabulary.FromJSONFile(filepath.Join(modelDir, "vocab.json"))
	if err != nil {
		return nil, fmt.Errorf("load clip vocabulary: %w", err)
	}
	merges, err := bpemodel.MergeMapFromFile(filepath.Join(modelDir, "merges.txt"), vocab, len(tokenizerSpec.Model.ContinuingSubwordPrefix))
	if err != nil {
		return nil, fmt.Errorf("load clip merges: %w", err)
	}
	model := bpemodel.New(
		vocab,
		merges,
		0,
		0.0,
		tokenizerSpec.Model.UnkToken,
		tokenizerSpec.Model.ContinuingSubwordPrefix,
		tokenizerSpec.Model.EndOfWordSuffix,
		tokenizerSpec.Model.FuseUnk,
	)
	preTokenizer := bytelevelpretokenizer.New(
		clipByteLevelSplittingRegexp,
		false,
		true,
	)
	tokenizer := newByteLevelBPETokenizer(preTokenizer, model, vocab)
	config, err := readTokenizerConfig(filepath.Join(modelDir, "tokenizer_config.json"))
	if err != nil && !os.IsNotExist(err) {
		return nil, fmt.Errorf("read clip tokenizer config: %w", err)
	}
	tokenToID, _, err := loadTokenIDs(modelDir)
	if err != nil {
		return nil, err
	}
	bosID, err := resolveSpecialTokenID(tokenToID, config.BosToken, 49406)
	if err != nil {
		return nil, err
	}
	eosID, err := resolveSpecialTokenID(tokenToID, config.EosToken, 49407)
	if err != nil {
		return nil, err
	}
	defaultMax := config.ModelMaxLength
	if defaultMax <= 0 {
		defaultMax = defaultCLIPMaxLength
	}
	return &clipBPETokenizer{
		modelDir:        modelDir,
		tokenizer:       tokenizer,
		bosID:           bosID,
		eosID:           eosID,
		defaultMax:      defaultMax,
		endOfWordSuffix: tokenizerSpec.Model.EndOfWordSuffix,
	}, nil
}

func resolveSpecialTokenID(tokenToID map[string]int, token string, fallback int) (int, error) {
	token = strings.TrimSpace(token)
	if token == "" {
		return fallback, nil
	}
	id, ok := tokenToID[token]
	if !ok {
		return 0, fmt.Errorf("tokenizer special token %q not found", token)
	}
	return id, nil
}

func extractTokenizerMerges(raw interface{}) ([]string, error) {
	switch typed := raw.(type) {
	case []string:
		if len(typed) == 0 {
			return nil, fmt.Errorf("tokenizer merges are required for clip bpe bundles")
		}
		return append([]string(nil), typed...), nil
	case []interface{}:
		if len(typed) == 0 {
			return nil, fmt.Errorf("tokenizer merges are required for clip bpe bundles")
		}
		merges := make([]string, 0, len(typed))
		for _, item := range typed {
			switch pair := item.(type) {
			case string:
				merges = append(merges, pair)
			case []interface{}:
				if len(pair) != 2 {
					return nil, fmt.Errorf("unexpected tokenizer merge pair length: %d", len(pair))
				}
				left, okLeft := pair[0].(string)
				right, okRight := pair[1].(string)
				if !okLeft || !okRight {
					return nil, fmt.Errorf("unexpected tokenizer merge pair types: %T %T", pair[0], pair[1])
				}
				merges = append(merges, left+" "+right)
			default:
				return nil, fmt.Errorf("unsupported tokenizer merge row type: %T", item)
			}
		}
		return merges, nil
	default:
		return nil, fmt.Errorf("unsupported tokenizer merges format: %T", raw)
	}
}

func marshalTokenizerVocabMap(raw interface{}) ([]byte, error) {
	vocab, ok := raw.(map[string]interface{})
	if !ok || len(vocab) == 0 {
		return nil, fmt.Errorf("clip tokenizer vocab must be a non-empty object, got %T", raw)
	}
	return json.Marshal(vocab)
}

func normalizeCLIPText(text string) string {
	text = norm.NFC.String(text)
	text = strings.ToLower(text)
	return strings.Join(strings.Fields(text), " ")
}

func (t *clipBPETokenizer) encode(text string, maxLength int) (BundleTextInputs, error) {
	if t == nil || t.tokenizer == nil {
		return BundleTextInputs{}, fmt.Errorf("clip tokenizer not initialized")
	}
	text = normalizeCLIPText(text)
	encoding, err := t.tokenizer.Encode(text)
	if err != nil {
		return BundleTextInputs{}, fmt.Errorf("clip tokenizer encode: %w", err)
	}
	contentIDs := make([]int, 0, len(encoding.IDs))
	for index, id := range encoding.IDs {
		token := ""
		if index < len(encoding.Tokens) {
			token = encoding.Tokens[index]
		}
		if clipTokenIsPureWhitespace(token, t.endOfWordSuffix) {
			continue
		}
		contentIDs = append(contentIDs, id)
	}
	inputIDs := make([]int, 0, len(contentIDs)+2)
	inputIDs = append(inputIDs, t.bosID)
	inputIDs = append(inputIDs, contentIDs...)
	inputIDs = append(inputIDs, t.eosID)
	if maxLength <= 0 {
		maxLength = t.defaultMax
	}
	if maxLength <= 0 {
		maxLength = defaultCLIPMaxLength
	}
	if len(inputIDs) >= maxLength {
		inputIDs = append([]int(nil), inputIDs[:maxLength]...)
		inputIDs[maxLength-1] = t.eosID
	} else {
		padCount := maxLength - len(inputIDs)
		for i := 0; i < padCount; i++ {
			inputIDs = append(inputIDs, 0)
		}
	}
	return BundleTextInputs{InputIDs: inputIDs}, nil
}

func clipTokenIsPureWhitespace(token string, endOfWordSuffix string) bool {
	if token == "" {
		return false
	}
	if endOfWordSuffix != "" {
		token = strings.TrimSuffix(token, endOfWordSuffix)
	}
	token = strings.ReplaceAll(token, "Ġ", " ")
	return strings.TrimSpace(token) == ""
}
