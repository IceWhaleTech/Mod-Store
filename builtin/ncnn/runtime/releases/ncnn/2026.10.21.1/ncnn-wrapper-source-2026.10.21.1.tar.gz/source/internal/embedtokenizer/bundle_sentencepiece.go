package embedtokenizer

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"

	"github.com/IceWhaleTech/zimaos-photos/internal/pathutil"
)

const defaultMaxLength = 256
const defaultCLIPMaxLength = 77

type BundleTextProfile string

const (
	BundleTextProfileSentencePiece BundleTextProfile = "sentencepiece"
	BundleTextProfileCLIPText      BundleTextProfile = "clip_text"
)

type bundleMetadata struct {
	ResolvedModelDir string `json:"resolved_model_dir"`
	MaxLength        int    `json:"max_length"`
}

type tokenizerJSON struct {
	Model struct {
		Type                    string      `json:"type"`
		Vocab                   interface{} `json:"vocab"`
		Merges                  interface{} `json:"merges,omitempty"`
		UnkToken                string      `json:"unk_token,omitempty"`
		ContinuingSubwordPrefix string      `json:"continuing_subword_prefix,omitempty"`
		EndOfWordSuffix         string      `json:"end_of_word_suffix,omitempty"`
		FuseUnk                 bool        `json:"fuse_unk,omitempty"`
	} `json:"model"`
	AddedTokens []tokenizerAddedToken `json:"added_tokens,omitempty"`
}

type tokenizerAddedToken struct {
	ID      int    `json:"id"`
	Content string `json:"content"`
}

type tokenizerConfig struct {
	DoLowerCase    bool   `json:"do_lower_case"`
	ModelMaxLength int    `json:"model_max_length"`
	BosToken       string `json:"bos_token"`
	EosToken       string `json:"eos_token"`
	PadToken       string `json:"pad_token"`
	UnkToken       string `json:"unk_token"`
	TokenizerClass string `json:"tokenizer_class"`
}

type sentencePieceTokenizer struct {
	modelDir    string
	tokenizer   *sentencepieceModelTokenizer
	tokenToID   map[string]int
	doLowerCase bool
	unkID       int
}

type BundleTextInputs struct {
	InputIDs      []int
	AttentionMask []float64
}

type bundleTokenizer interface {
	encode(text string, maxLength int) (BundleTextInputs, error)
}

var tokenizerCache sync.Map

func TokenizeBundleText(bundleDir string, text string) (BundleTextInputs, bool, error) {
	modelDir, maxLength, profile, ok, err := resolveBundleTextProfile(bundleDir)
	if err != nil {
		return BundleTextInputs{}, false, err
	}
	if !ok {
		return BundleTextInputs{}, false, nil
	}
	tokenizer, err := loadBundleTokenizer(modelDir, profile)
	if err != nil {
		return BundleTextInputs{}, false, err
	}
	inputs, err := tokenizer.encode(text, maxLength)
	if err != nil {
		return BundleTextInputs{}, false, err
	}
	return inputs, true, nil
}

func DetectBundleTextProfile(bundleDir string) (BundleTextProfile, bool, error) {
	_, _, profile, ok, err := resolveBundleTextProfile(bundleDir)
	return profile, ok, err
}

func resolveBundleTextProfile(bundleDir string) (string, int, BundleTextProfile, bool, error) {
	metadata, _ := readBundleMetadata(bundleDir)
	maxLength := metadata.MaxLength
	resolvedModelDir := ""
	if value := strings.TrimSpace(metadata.ResolvedModelDir); value != "" {
		if candidate, err := pathutil.JoinRelative(bundleDir, value); err == nil {
			resolvedModelDir = candidate
		}
	}
	candidates := []string{
		resolvedModelDir,
		strings.TrimSpace(bundleDir),
	}
	for _, candidate := range candidates {
		candidate = filepath.Clean(strings.TrimSpace(candidate))
		if candidate == "" {
			continue
		}
		if hasSentencePieceTokenizerAssets(candidate) {
			if err := prepareSentencePieceTokenizerArtifacts(candidate); err != nil {
				return "", 0, "", false, err
			}
			return candidate, maxLength, BundleTextProfileSentencePiece, true, nil
		}
		if hasCLIPTokenizerAssets(candidate) {
			if err := prepareCLIPTokenizerArtifacts(candidate); err != nil {
				return "", 0, "", false, err
			}
			return candidate, maxLength, BundleTextProfileCLIPText, true, nil
		}
	}
	return "", maxLength, "", false, nil
}

func readBundleMetadata(bundleDir string) (bundleMetadata, error) {
	path := filepath.Join(strings.TrimSpace(bundleDir), "metadata.json")
	data, err := os.ReadFile(path)
	if err != nil {
		return bundleMetadata{}, err
	}
	var metadata bundleMetadata
	if err := json.Unmarshal(data, &metadata); err != nil {
		return bundleMetadata{}, err
	}
	return metadata, nil
}

func hasSentencePieceTokenizerAssets(modelDir string) bool {
	required := []string{
		filepath.Join(modelDir, "tokenizer.json"),
	}
	optionalModel := []string{
		filepath.Join(modelDir, "tokenizer.model"),
		filepath.Join(modelDir, "sentencepiece.bpe.model"),
		filepath.Join(modelDir, "spiece.model"),
	}
	for _, path := range required {
		info, err := os.Stat(path)
		if err != nil || info.IsDir() {
			return false
		}
	}
	for _, path := range optionalModel {
		info, err := os.Stat(path)
		if err == nil && !info.IsDir() {
			return true
		}
	}
	return false
}

func prepareSentencePieceTokenizerArtifacts(modelDir string) error {
	modelDir = filepath.Clean(strings.TrimSpace(modelDir))
	if modelDir == "" {
		return fmt.Errorf("embedding tokenizer model dir is required")
	}
	targetModelPath := filepath.Join(modelDir, "spiece.model")
	if _, err := os.Stat(targetModelPath); err != nil {
		var raw []byte
		var readErr error
		var sourceModelPath string
		for _, candidate := range []string{"tokenizer.model", "sentencepiece.bpe.model"} {
			sourceModelPath = filepath.Join(modelDir, candidate)
			raw, readErr = os.ReadFile(sourceModelPath)
			if readErr == nil {
				break
			}
		}
		if readErr != nil {
			return fmt.Errorf("read sentencepiece model in %s: %w", modelDir, readErr)
		}
		if writeErr := atomicWriteBundleArtifact(targetModelPath, raw, 0o644); writeErr != nil {
			return fmt.Errorf("write %s: %w", targetModelPath, writeErr)
		}
	}
	vocabPath := filepath.Join(modelDir, "vocab.txt")
	if _, err := os.Stat(vocabPath); err == nil {
		return nil
	}
	rawTokenizer, err := os.ReadFile(filepath.Join(modelDir, "tokenizer.json"))
	if err != nil {
		return fmt.Errorf("read tokenizer.json: %w", err)
	}
	var tokenizer tokenizerJSON
	if err := json.Unmarshal(rawTokenizer, &tokenizer); err != nil {
		return fmt.Errorf("decode tokenizer.json: %w", err)
	}
	tokens, err := extractTokenizerVocab(tokenizer.Model.Vocab)
	if err != nil {
		return err
	}
	return atomicWriteBundleArtifact(vocabPath, []byte(strings.Join(tokens, "\n")+"\n"), 0o644)
}

func loadBundleTokenizer(modelDir string, profile BundleTextProfile) (bundleTokenizer, error) {
	modelDir = filepath.Clean(strings.TrimSpace(modelDir))
	if modelDir == "" {
		return nil, fmt.Errorf("embedding tokenizer model dir is required")
	}
	cacheKey := string(profile) + ":" + modelDir
	if cached, ok := tokenizerCache.Load(cacheKey); ok {
		if tokenizer, ok := cached.(bundleTokenizer); ok && tokenizer != nil {
			return tokenizer, nil
		}
	}
	switch profile {
	case BundleTextProfileSentencePiece:
		tokenizer, err := loadSentencePieceTokenizer(modelDir)
		if err != nil {
			return nil, err
		}
		tokenizerCache.Store(cacheKey, tokenizer)
		return tokenizer, nil
	case BundleTextProfileCLIPText:
		tokenizer, err := loadCLIPTokenizer(modelDir)
		if err != nil {
			return nil, err
		}
		tokenizerCache.Store(cacheKey, tokenizer)
		return tokenizer, nil
	default:
		return nil, fmt.Errorf("unsupported embedding tokenizer profile %q", profile)
	}
}

func loadSentencePieceTokenizer(modelDir string) (*sentencePieceTokenizer, error) {
	modelDir = filepath.Clean(strings.TrimSpace(modelDir))
	if modelDir == "" {
		return nil, fmt.Errorf("embedding tokenizer model dir is required")
	}
	if err := prepareSentencePieceTokenizerArtifacts(modelDir); err != nil {
		return nil, err
	}
	config, err := readTokenizerConfig(filepath.Join(modelDir, "tokenizer_config.json"))
	if err != nil && !os.IsNotExist(err) {
		return nil, fmt.Errorf("read embedding tokenizer config: %w", err)
	}
	tokenizer, err := newSentencepieceModelTokenizerFromFolder(modelDir, config.DoLowerCase)
	if err != nil {
		return nil, fmt.Errorf("load embedding sentencepiece tokenizer: %w", err)
	}
	tokenToID, unkID, err := loadTokenIDs(modelDir)
	if err != nil {
		return nil, err
	}
	value := &sentencePieceTokenizer{
		modelDir:    modelDir,
		tokenizer:   tokenizer,
		tokenToID:   tokenToID,
		doLowerCase: config.DoLowerCase,
		unkID:       unkID,
	}
	return value, nil
}

func readTokenizerConfig(path string) (tokenizerConfig, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return tokenizerConfig{}, err
	}
	var config tokenizerConfig
	if err := json.Unmarshal(raw, &config); err != nil {
		return tokenizerConfig{}, err
	}
	return config, nil
}

func loadTokenIDs(modelDir string) (map[string]int, int, error) {
	rawTokenizer, err := os.ReadFile(filepath.Join(modelDir, "tokenizer.json"))
	if err != nil {
		return nil, 0, fmt.Errorf("read tokenizer.json: %w", err)
	}
	var tokenizer tokenizerJSON
	if err := json.Unmarshal(rawTokenizer, &tokenizer); err != nil {
		return nil, 0, fmt.Errorf("decode tokenizer.json: %w", err)
	}
	tokens, err := extractTokenizerVocab(tokenizer.Model.Vocab)
	if err != nil {
		return nil, 0, err
	}
	tokenToID := make(map[string]int, len(tokens))
	unkID := 0
	for id, token := range tokens {
		tokenToID[token] = id
		if token == "<unk>" {
			unkID = id
		}
	}
	for _, token := range tokenizer.AddedTokens {
		if token.Content == "" {
			continue
		}
		tokenToID[token.Content] = token.ID
		if token.Content == "<unk>" {
			unkID = token.ID
		}
	}
	return tokenToID, unkID, nil
}

func extractTokenizerVocab(raw interface{}) ([]string, error) {
	switch typed := raw.(type) {
	case []interface{}:
		tokens := make([]string, 0, len(typed))
		for _, item := range typed {
			pair, ok := item.([]interface{})
			if !ok || len(pair) == 0 {
				return nil, fmt.Errorf("unexpected tokenizer vocab row: %T", item)
			}
			token, ok := pair[0].(string)
			if !ok || token == "" {
				return nil, fmt.Errorf("unexpected tokenizer token: %v", pair[0])
			}
			tokens = append(tokens, token)
		}
		return tokens, nil
	case map[string]interface{}:
		type item struct {
			token string
			id    int
		}
		items := make([]item, 0, len(typed))
		for token, idValue := range typed {
			id, ok := idValue.(float64)
			if !ok {
				return nil, fmt.Errorf("unexpected tokenizer id type for %q: %T", token, idValue)
			}
			items = append(items, item{token: token, id: int(id)})
		}
		sort.Slice(items, func(i, j int) bool { return items[i].id < items[j].id })
		tokens := make([]string, 0, len(items))
		for _, item := range items {
			tokens = append(tokens, item.token)
		}
		return tokens, nil
	default:
		return nil, fmt.Errorf("unsupported tokenizer vocab format: %T", raw)
	}
}

func (t *sentencePieceTokenizer) encode(text string, maxLength int) (BundleTextInputs, error) {
	if t == nil || t.tokenizer == nil || len(t.tokenToID) == 0 {
		return BundleTextInputs{}, fmt.Errorf("embedding tokenizer not initialized")
	}
	text = strings.TrimSpace(text)
	if t.doLowerCase {
		text = strings.ToLower(text)
	}
	tokens := append([]string{"<s>"}, append(t.tokenizer.Tokenize(text), "</s>")...)
	if maxLength <= 0 {
		maxLength = defaultMaxLength
	}
	if len(tokens) > maxLength {
		tokens = tokens[:maxLength]
	}
	inputIDs := make([]int, maxLength)
	attentionMask := make([]float64, maxLength)
	for index, token := range tokens {
		id, ok := t.tokenToID[token]
		if !ok {
			id = t.unkID
		}
		inputIDs[index] = id
		attentionMask[index] = 1.0
	}
	return BundleTextInputs{
		InputIDs:      inputIDs,
		AttentionMask: attentionMask,
	}, nil
}
