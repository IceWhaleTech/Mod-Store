package embedtokenizer

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
)

func TestDetectBundleTextProfileIgnoresAbsoluteResolvedModelDir(t *testing.T) {
	bundleDir := t.TempDir()
	externalDir := t.TempDir()
	metadata, err := json.Marshal(bundleMetadata{ResolvedModelDir: externalDir, MaxLength: 128})
	if err != nil {
		t.Fatalf("Marshal(metadata) error=%v", err)
	}
	if err := os.WriteFile(filepath.Join(bundleDir, "metadata.json"), metadata, 0o644); err != nil {
		t.Fatalf("WriteFile(metadata.json) error=%v", err)
	}
	if err := os.WriteFile(filepath.Join(externalDir, "tokenizer.json"), []byte(`{"model":{"type":"Unigram","vocab":[["<unk>",0],["<s>",0],["</s>",0]]}}`), 0o644); err != nil {
		t.Fatalf("WriteFile(tokenizer.json) error=%v", err)
	}
	if err := os.WriteFile(filepath.Join(externalDir, "tokenizer.model"), []byte("spm"), 0o644); err != nil {
		t.Fatalf("WriteFile(tokenizer.model) error=%v", err)
	}

	profile, ok, err := DetectBundleTextProfile(bundleDir)
	if err != nil {
		t.Fatalf("DetectBundleTextProfile error=%v", err)
	}
	if ok {
		t.Fatalf("DetectBundleTextProfile profile=%q ok=true want unsafe external dir ignored", profile)
	}
	for _, generated := range []string{"spiece.model", "vocab.txt"} {
		if _, err := os.Stat(filepath.Join(externalDir, generated)); !os.IsNotExist(err) {
			t.Fatalf("external generated artifact %s should not exist, stat error=%v", generated, err)
		}
	}
}
