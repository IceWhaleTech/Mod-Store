package embedtokenizer

import (
	"fmt"

	"github.com/nlpodyssey/gotokenizers/encodings"
	"github.com/nlpodyssey/gotokenizers/models"
	"github.com/nlpodyssey/gotokenizers/models/bpemodel"
	"github.com/nlpodyssey/gotokenizers/normalizedstring"
	"github.com/nlpodyssey/gotokenizers/pretokenizedstring"
	"github.com/nlpodyssey/gotokenizers/pretokenizers/bytelevelpretokenizer"
	"github.com/nlpodyssey/gotokenizers/vocabulary"
)

type byteLevelBPETokenizer struct {
	preTokenizer *bytelevelpretokenizer.ByteLevelPreTokenizer
	model        *bpemodel.BPEModel
	vocab        *vocabulary.Vocabulary
}

func newByteLevelBPETokenizer(
	preTokenizer *bytelevelpretokenizer.ByteLevelPreTokenizer,
	model *bpemodel.BPEModel,
	vocab *vocabulary.Vocabulary,
) *byteLevelBPETokenizer {
	return &byteLevelBPETokenizer{
		preTokenizer: preTokenizer,
		model:        model,
		vocab:        vocab,
	}
}

func (t *byteLevelBPETokenizer) Encode(text string) (*encodings.Encoding, error) {
	if t == nil || t.preTokenizer == nil || t.model == nil || t.vocab == nil {
		return nil, fmt.Errorf("byte-level bpe tokenizer not initialized")
	}

	pts := pretokenizedstring.FromString(text)
	if err := t.preTokenizer.PreTokenize(pts); err != nil {
		return nil, fmt.Errorf("byte-level bpe pre-tokenize: %w", err)
	}
	if err := pts.Tokenize(func(ns *normalizedstring.NormalizedString) ([]models.Token, error) {
		return t.model.Tokenize(ns.Get())
	}); err != nil {
		return nil, fmt.Errorf("byte-level bpe tokenize: %w", err)
	}
	encoding, err := pts.IntoEncoding(0, 0)
	if err != nil {
		return nil, fmt.Errorf("byte-level bpe encoding: %w", err)
	}
	return encoding, nil
}
