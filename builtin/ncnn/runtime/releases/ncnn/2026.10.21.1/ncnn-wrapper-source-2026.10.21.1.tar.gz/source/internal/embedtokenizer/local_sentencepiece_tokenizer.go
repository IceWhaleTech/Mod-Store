package embedtokenizer

import (
	"fmt"
	"math"
	"os"
	"path/filepath"
	"strings"
	"unicode"
	"unicode/utf8"

	"golang.org/x/text/unicode/norm"
	"google.golang.org/protobuf/encoding/protowire"
)

const (
	localSentencePieceUnknownType     = 2
	localSentencePieceControlType     = 3
	localSentencePieceUserDefinedType = 4
	localSentencePieceSeparator       = "▁"
)

type sentencepieceModelTokenizer struct {
	model *localSentencePieceModel
}

func newSentencepieceModelTokenizerFromFolder(path string, lowercase bool) (*sentencepieceModelTokenizer, error) {
	modelPath := filepath.Join(path, "spiece.model")
	model, err := newLocalSentencePieceModelFromFile(modelPath, lowercase)
	if err != nil {
		return nil, fmt.Errorf("load sentencepiece tokenizer from %s: %w", modelPath, err)
	}
	return &sentencepieceModelTokenizer{model: model}, nil
}

func (t *sentencepieceModelTokenizer) Tokenize(text string) []string {
	if t == nil || t.model == nil {
		return nil
	}
	tokens := t.model.Tokenize(text)
	result := make([]string, len(tokens))
	for i, token := range tokens {
		result[i] = token.Text
	}
	return result
}

type localSentencePieceToken struct {
	ID   int32
	Text string
}

type localSentencePieceTokenOffset struct {
	id    int32
	start int
	end   int
}

type localSentencePieceSlice struct {
	score float32
	index int32
	start int
	end   int
}

type localSentencePieceTrieNode struct {
	level    int
	score    float32
	index    int32
	end      bool
	children map[rune]*localSentencePieceTrieNode
}

type localSentencePieceModel struct {
	root         *localSentencePieceTrieNode
	lowercase    bool
	unknown      int32
	pieceCount   int32
	controlWords map[string]int32
}

func newLocalSentencePieceTrieNode(level int) *localSentencePieceTrieNode {
	return &localSentencePieceTrieNode{
		level: level,
	}
}

func newEmptyLocalSentencePieceModel(lowercase bool) *localSentencePieceModel {
	return &localSentencePieceModel{
		root:         newLocalSentencePieceTrieNode(0),
		lowercase:    lowercase,
		unknown:      0,
		controlWords: make(map[string]int32),
	}
}

func newLocalSentencePieceModelFromFile(filename string, lowercase bool) (*localSentencePieceModel, error) {
	raw, err := os.ReadFile(filename)
	if err != nil {
		return nil, fmt.Errorf("read sentencepiece model %s: %w", filename, err)
	}
	model := newEmptyLocalSentencePieceModel(lowercase)
	if err := model.load(raw); err != nil {
		return nil, fmt.Errorf("decode sentencepiece model %s: %w", filename, err)
	}
	return model, nil
}

func (m *localSentencePieceModel) load(raw []byte) error {
	for len(raw) > 0 {
		num, typ, n := protowire.ConsumeTag(raw)
		if n < 0 {
			return protowire.ParseError(n)
		}
		raw = raw[n:]
		switch num {
		case 1:
			if typ != protowire.BytesType {
				return fmt.Errorf("unexpected sentencepiece pieces wire type %d", typ)
			}
			pieceRaw, n := protowire.ConsumeBytes(raw)
			if n < 0 {
				return protowire.ParseError(n)
			}
			raw = raw[n:]
			piece, score, pieceType, err := parseLocalSentencePieceEntry(pieceRaw)
			if err != nil {
				return err
			}
			index := int32(len(m.controlWords)) // overwritten below for non-control if needed
			index = 0
			switch pieceType {
			case localSentencePieceUnknownType:
				index = int32(len(m.controlWords))
			}
			_ = index
			m.addParsedPiece(piece, score, pieceType)
		default:
			n := protowire.ConsumeFieldValue(num, typ, raw)
			if n < 0 {
				return protowire.ParseError(n)
			}
			raw = raw[n:]
		}
	}
	return nil
}

func parseLocalSentencePieceEntry(raw []byte) (string, float32, int32, error) {
	var (
		piece     string
		score     float32
		pieceType int32 = 1
	)
	for len(raw) > 0 {
		num, typ, n := protowire.ConsumeTag(raw)
		if n < 0 {
			return "", 0, 0, protowire.ParseError(n)
		}
		raw = raw[n:]
		switch num {
		case 1:
			if typ != protowire.BytesType {
				return "", 0, 0, fmt.Errorf("unexpected sentencepiece piece wire type %d", typ)
			}
			value, n := protowire.ConsumeString(raw)
			if n < 0 {
				return "", 0, 0, protowire.ParseError(n)
			}
			piece = value
			raw = raw[n:]
		case 2:
			if typ != protowire.Fixed32Type {
				return "", 0, 0, fmt.Errorf("unexpected sentencepiece score wire type %d", typ)
			}
			value, n := protowire.ConsumeFixed32(raw)
			if n < 0 {
				return "", 0, 0, protowire.ParseError(n)
			}
			score = math.Float32frombits(value)
			raw = raw[n:]
		case 3:
			if typ != protowire.VarintType {
				return "", 0, 0, fmt.Errorf("unexpected sentencepiece type wire type %d", typ)
			}
			value, n := protowire.ConsumeVarint(raw)
			if n < 0 {
				return "", 0, 0, protowire.ParseError(n)
			}
			pieceType = int32(value)
			raw = raw[n:]
		default:
			n := protowire.ConsumeFieldValue(num, typ, raw)
			if n < 0 {
				return "", 0, 0, protowire.ParseError(n)
			}
			raw = raw[n:]
		}
	}
	if piece == "" {
		return "", 0, 0, fmt.Errorf("sentencepiece entry missing piece text")
	}
	return piece, score, pieceType, nil
}

func (m *localSentencePieceModel) addParsedPiece(piece string, score float32, pieceType int32) {
	index := m.pieceCount
	switch pieceType {
	case localSentencePieceUnknownType:
		m.unknown = index
	case localSentencePieceControlType:
		m.controlWords[piece] = index
	case 1, localSentencePieceUserDefinedType:
		m.insert(piece, score, index)
	}
	m.pieceCount++
}

const localSentencePieceMinScore float32 = -math.MaxFloat32

func (m *localSentencePieceModel) Tokenize(text string) []localSentencePieceToken {
	text = normalizeLocalSentencePieceText(text)
	if m.lowercase {
		text = strings.ToLower(text)
	}
	runes := localSentencePieceToRunes(text)
	replaceLocalSentencePieceWhitespace(runes)
	slices := m.decodeForwardToken(runes)
	slices = m.decodeBackwards(slices)
	offsets := m.sliceToTokens(slices)
	return makeLocalSentencePieceTokens(offsets, runes)
}

func (m *localSentencePieceModel) insert(word string, score float32, index int32) {
	_, size := utf8.DecodeLastRuneInString(word)
	charCount := len(word)
	node := m.root
	for i, r := range word {
		child, ok := node.children[r]
		if !ok {
			child = newLocalSentencePieceTrieNode(node.level + 1)
			if node.children == nil {
				node.children = make(map[rune]*localSentencePieceTrieNode)
			}
			node.children[r] = child
		}
		if i == charCount-size {
			child.end = true
			child.score = score
			child.index = index
		}
		node = child
	}
}

func (m *localSentencePieceModel) commonPrefixSearch(runes []rune, cb func(*localSentencePieceTrieNode)) {
	node := m.root
	for _, r := range runes {
		child, ok := node.children[r]
		if !ok {
			break
		}
		if child.end {
			cb(child)
		}
		node = child
	}
}

func (m *localSentencePieceModel) decodeForwardToken(runes []rune) []localSentencePieceSlice {
	scores := initLocalSentencePieceScores(len(runes) + 1)
	slices := m.initSlices(len(runes) + 1)
	scores[0] = 0
	for i := range runes {
		m.commonPrefixSearch(runes[i:], func(node *localSentencePieceTrieNode) {
			localScore := scores[i] + node.score
			charEnd := i + node.level
			if localScore > scores[charEnd] {
				slices[charEnd] = localSentencePieceSlice{score: localScore, index: node.index, start: i, end: charEnd}
				scores[charEnd] = localScore
			}
		})
		if scores[i+1] <= localSentencePieceMinScore {
			slices[i+1] = localSentencePieceSlice{score: localSentencePieceMinScore, index: m.unknown, start: i, end: i + 1}
			scores[i+1] = 0
		}
	}
	return slices
}

func (m *localSentencePieceModel) decodeBackwards(slices []localSentencePieceSlice) []localSentencePieceSlice {
	best := make([]localSentencePieceSlice, len(slices))
	lastIndex := len(slices) - 1
	i := lastIndex
	index := lastIndex
	for ; i >= 0; i-- {
		slice := slices[index]
		if slice.start == -1 {
			i++
			break
		}
		best[i] = slice
		index = slice.start
	}
	return best[i : lastIndex+1]
}

func (m *localSentencePieceModel) sliceToTokens(slices []localSentencePieceSlice) []localSentencePieceTokenOffset {
	tokens := make([]localSentencePieceTokenOffset, 0, len(slices)+1)
	isPrevUnknown := false
	for _, slice := range slices {
		if isPrevUnknown && slice.index == m.unknown {
			tokens[len(tokens)-1].end = slice.end
		} else {
			tokens = append(tokens, localSentencePieceTokenOffset{id: slice.index, start: slice.start, end: slice.end})
		}
		isPrevUnknown = slice.index == m.unknown
	}
	return tokens
}

func (m *localSentencePieceModel) initSlices(length int) []localSentencePieceSlice {
	slices := make([]localSentencePieceSlice, length)
	for i := range slices {
		slices[i].start = -1
		slices[i].index = m.unknown
	}
	return slices
}

func initLocalSentencePieceScores(length int) []float32 {
	scores := make([]float32, length)
	for i := range scores {
		scores[i] = localSentencePieceMinScore
	}
	return scores
}

func replaceLocalSentencePieceWhitespace(runes []rune) {
	for i, r := range runes {
		if unicode.IsSpace(r) {
			runes[i] = []rune(localSentencePieceSeparator)[0]
		}
	}
}

func localSentencePieceToRunes(text string) []rune {
	separatorRune := []rune(localSentencePieceSeparator)[0]
	runes := make([]rune, 0, len(text)+1)
	first, _ := utf8.DecodeRuneInString(text)
	if first != separatorRune {
		runes = append(runes, separatorRune)
	}
	for _, r := range text {
		runes = append(runes, r)
	}
	return runes
}

func makeLocalSentencePieceTokens(offsets []localSentencePieceTokenOffset, runes []rune) []localSentencePieceToken {
	tokens := make([]localSentencePieceToken, len(offsets))
	for i, offset := range offsets {
		tokens[i] = localSentencePieceToken{ID: offset.id, Text: string(runes[offset.start:offset.end])}
	}
	return tokens
}

func sanitizeLocalSentencePieceText(s string) string {
	return norm.NFKC.String(s)
}

func normalizeLocalSentencePieceText(s string) string {
	replacer := func(r rune) rune {
		if isLocalSentencePieceControl(r) || r == 0 {
			return -1
		}
		if unicode.IsSpace(r) {
			return ' '
		}
		return r
	}
	return sanitizeLocalSentencePieceText(strings.Map(replacer, s))
}

var localSentencePieceControlChars = []rune{
	0x007F, 0x00AD, 0x0600, 0x0601, 0x0602, 0x0603, 0x0604, 0x0605, 0x061C, 0x06DD, 0x070F,
	0x08E2, 0x180E, 0x200B, 0x200C, 0x200D, 0x200E, 0x200F, 0x202A, 0x202B, 0x202C, 0x202D,
	0x202E, 0x2060, 0x2061, 0x2062, 0x2063, 0x2064, 0x2066, 0x2067, 0x2068, 0x2069, 0x206A,
	0x206B, 0x206C, 0x206D, 0x206E, 0x206F, 0xFEFF, 0xFFF9, 0xFFFA, 0xFFFB, 0x110BD,
	0x110CD, 0x13430, 0x13431, 0x13432, 0x13433, 0x13434, 0x13435, 0x13436, 0x13437,
	0x13438, 0x1BCA0, 0x1BCA1, 0x1BCA2, 0x1BCA3, 0x1D173, 0x1D174, 0x1D175, 0x1D176,
	0x1D177, 0x1D178, 0x1D179, 0x1D17A, 0xE0001,
}

func isLocalSentencePieceControl(c rune) bool {
	if c == ' ' || c == '\n' || c == '\r' || c == '\t' {
		return false
	}
	if c <= 0x001F || (c >= 0x0080 && c <= 0x009F) ||
		(c >= 0xE0020 && c <= 0xE007F) ||
		(c >= 0xE000 && c <= 0xF8FF) ||
		(c >= 0xF0000 && c <= 0xFFFFD) ||
		(c >= 0x100000 && c <= 0x10FFFD) ||
		(c >= 0xD800 && c <= 0xDB7F) ||
		(c >= 0xDB80 && c <= 0xDBFF) ||
		(c >= 0xDC00 && c <= 0xDFFF) ||
		isLocalSentencePieceControlChar(c) {
		return true
	}
	return false
}

func isLocalSentencePieceControlChar(c rune) bool {
	for _, ch := range localSentencePieceControlChars {
		if ch == c {
			return true
		}
	}
	return false
}
