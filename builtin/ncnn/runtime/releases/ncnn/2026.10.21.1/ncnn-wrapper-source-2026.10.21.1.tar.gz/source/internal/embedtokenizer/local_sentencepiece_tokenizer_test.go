package embedtokenizer

import (
	"reflect"
	"testing"
)

func TestLocalSentencePieceTrieNodeDoesNotRetainPrefixText(t *testing.T) {
	if _, ok := reflect.TypeOf(localSentencePieceTrieNode{}).FieldByName("text"); ok {
		t.Fatal("localSentencePieceTrieNode retains every prefix string")
	}
}

func TestLocalSentencePieceTrieLeafDoesNotAllocateChildrenMap(t *testing.T) {
	model := newEmptyLocalSentencePieceModel(false)
	model.insert("token", 1, 7)

	node := model.root
	for _, r := range "token" {
		node = node.children[r]
		if node == nil {
			t.Fatalf("missing trie node for %q", r)
		}
	}
	if node.children != nil {
		t.Fatal("leaf trie node allocates an unused children map")
	}
}

func TestLocalSentencePieceTrieMemoryOptimizationPreservesTokenization(t *testing.T) {
	model := newEmptyLocalSentencePieceModel(false)
	model.insert(localSentencePieceSeparator+"hello", 10, 1)
	model.insert(localSentencePieceSeparator+"hell", 1, 2)
	model.insert("o", 1, 3)

	tokens := model.Tokenize("hello")
	want := []localSentencePieceToken{{ID: 1, Text: localSentencePieceSeparator + "hello"}}
	if !reflect.DeepEqual(tokens, want) {
		t.Fatalf("Tokenize(hello)=%v want %v", tokens, want)
	}
}
