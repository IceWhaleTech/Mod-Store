package pathutil

import (
	"fmt"
	"path"
	"path/filepath"
	"strings"
)

func CleanRelative(value string) (string, error) {
	raw := strings.TrimSpace(value)
	logical := strings.ReplaceAll(raw, `\`, "/")
	if logical == "" || path.IsAbs(logical) || hasDrivePrefix(logical) {
		return "", fmt.Errorf("unsafe relative path %q", value)
	}

	cleaned := path.Clean(logical)
	if cleaned == "." || cleaned == ".." || strings.HasPrefix(cleaned, "../") {
		return "", fmt.Errorf("unsafe relative path %q", value)
	}
	return filepath.FromSlash(cleaned), nil
}

func JoinRelative(root, value string) (string, error) {
	root = strings.TrimSpace(root)
	if root == "" {
		return "", fmt.Errorf("path root is required")
	}
	relative, err := CleanRelative(value)
	if err != nil {
		return "", err
	}
	return filepath.Join(filepath.Clean(root), relative), nil
}

func hasDrivePrefix(value string) bool {
	if len(value) < 2 || value[1] != ':' {
		return false
	}
	first := value[0]
	return first >= 'a' && first <= 'z' || first >= 'A' && first <= 'Z'
}
