package pathutil

import (
	"path/filepath"
	"testing"
)

func TestCleanRelativeRejectsUnsafePaths(t *testing.T) {
	t.Parallel()

	for _, value := range []string{
		"",
		".",
		"..",
		"../escape",
		"nested/../../escape",
		"/media/ZimaOS-HD/AppData/photos/models/ncnn/mobileclip2-s4-int8",
		`C:\models\ncnn\mobileclip2-s4`,
		"C:/models/ncnn/mobileclip2-s4",
		`\\server\share\model.bin`,
		"//server/share/model.bin",
	} {
		value := value
		t.Run(value, func(t *testing.T) {
			t.Parallel()
			if cleaned, err := CleanRelative(value); err == nil {
				t.Fatalf("CleanRelative(%q)=%q want error", value, cleaned)
			}
		})
	}
}

func TestCleanRelativeNormalizesSafeNestedPaths(t *testing.T) {
	t.Parallel()

	for value, want := range map[string]string{
		"model.param":                 "model.param",
		"ncnn/runtime/model.bin":      filepath.Join("ncnn", "runtime", "model.bin"),
		`ncnn\runtime\tokenizer.json`: filepath.Join("ncnn", "runtime", "tokenizer.json"),
		"nested/../model.param":       "model.param",
	} {
		got, err := CleanRelative(value)
		if err != nil {
			t.Fatalf("CleanRelative(%q) error=%v", value, err)
		}
		if got != want {
			t.Fatalf("CleanRelative(%q)=%q want %q", value, got, want)
		}
	}
}

func TestJoinRelativeRejectsAbsolutePathInsteadOfDuplicatingRoot(t *testing.T) {
	t.Parallel()

	root := "/media/ZimaOS-HD/AppData/photos/models/ncnn/mobileclip2-s4-int8"
	if joined, err := JoinRelative(root, root); err == nil {
		t.Fatalf("JoinRelative(%q, %q)=%q want error", root, root, joined)
	}

	joined, err := JoinRelative(root, "model.param")
	if err != nil {
		t.Fatalf("JoinRelative(valid) error=%v", err)
	}
	if want := filepath.Join(root, "model.param"); joined != want {
		t.Fatalf("JoinRelative(valid)=%q want %q", joined, want)
	}
}
