# NCNN Runtime Wrapper Scaffold

This directory contains the in-repo `libzima_ncnn_runtime_v7` ABI scaffold.

Build it with:

```bash
bash ./scripts/build_ncnn_runtime_wrapper.sh --output-dir /tmp/ncnn-wrapper
```

Cross-build Linux runtime artifacts with:

```bash
bash ./scripts/build_ncnn_runtime_wrapper.sh \
  --target-os linux \
  --target-arch amd64 \
  --output-dir /tmp/ncnn-wrapper-linux-amd64
```

For ZimaOS release/runtime artifacts, do not build this cgo shared library
directly on a ZimaOS host. The host glibc can be newer or otherwise
incompatible with deployed ZimaOS systems, and the resulting `.so` may fail to
load there. Build in a pinned compatible Linux builder/sysroot instead. The
script refuses `ZIMAOS_RUNTIME_TARGET=zimaos` by default; set
`ZIMAOS_ALLOW_NATIVE_CGO_BUILD=1` only for local experiments where the artifact
will not be published.

To stage the current host build into the standard runtime publish layout, use:

```bash
bash ./scripts/stage_ncnn_runtime_wrapper.sh --output-dir /tmp/ncnn-runtime-artifacts
```

Or stage a Linux runtime layout directly from macOS with:

```bash
bash ./scripts/stage_ncnn_runtime_wrapper.sh \
  --target-os linux \
  --target-arch amd64 \
  --output-dir /tmp/ncnn-runtime-artifacts
```

The generated shared library exports these symbols:

- `zima_ncnn_create_json_v2`
- `zima_ncnn_destroy_json_v2`
- `zima_ncnn_status_json_v2`
- `zima_ncnn_load_json_v2`
- `zima_ncnn_infer_json_v2`
- `zima_ncnn_unload_json_v2`
- `zima_ncnn_switch_backend_json_v2`

Current status:

- The wrapper compiles directly from this repo.
- The artifact ABI is v7 while the exported function ABI remains `json-v2`.
- Native NCNN inference supports embedding, detection, face, and OCR model classes.
- OCR loads detector and recognizer nets through the same dynamically resolved
  `libncnn` C API as the other model classes.
- OCR DB postprocessing, quadrilateral crops, and CTC decoding execute inside
  the wrapper; no `RapidOcrNcnn` executable is launched or packaged.
- `unload` destroys both OCR nets, while the separately supervised Photos AI
  worker remains the crash/OOM recovery boundary.

The single-image CPU path packs NRGBA pixels directly and samples common
concrete image types without boxing a color for each pixel. Channel order,
alpha conversion and interpolation remain unchanged. Split `face_embed` calls
decode the source for aligned crops without constructing an unused detector
tensor. These changes require rebuilding and installing this shared library;
updating the Photos executable alone does not update the wrapper.

Detector inputs are packed directly into the padded RGB tensor after the same
Linear resize, without two intermediate NRGBA canvases. Extracted vision
outputs borrow the native Mat until decoding completes; the caller must retain
and then destroy that Mat. Only owned detections and vectors may leave this
operation. Finite-value validation and error cleanup still apply.

YOLO decoding reads row-major and feature-major outputs through a view, without
transposing the entire output. Shape interpretation uses the loaded net's
profile. Candidate storage starts only after a valid box is accepted and grows
as needed; its initial capacity of at most 64 is not a detection limit. Score
thresholds, class ties, row order and stable NMS remain unchanged.

OCR padding writes NRGBA and decoded YCbCr directly into its owned white
canvas. JPEG conversion uses disjoint row bands with at most GOMAXPROCS
workers; other image formats retain imaging's original conversion. OCR net
outputs are decoded inside a callback while the native Mat and extractor are
alive. Only owned boxes, text and character scores may leave the callback.
Output, extractor and input are released in that order, including failure
paths. This removes Go tensor copies without adding a pool; Go allocation
reductions do not measure native memory or RSS, and native objects now remain
alive until decoding ends. Model parameters and outputs remain unchanged.

OCR detector and recognizer now pass their resized NRGBA bytes and actual
stride to NCNN's RGBA2RGB/RGBA2BGR conversion. This removes the intermediate
packed three-channel Go buffer. Alpha is still dropped without premultiplying;
channel order, resizing and normalization remain unchanged. NCNN still owns a
new floating-point Mat and performs native conversion; this is not a fully
zero-copy model input. Go pixels stay alive until the internal call completes.

OCR probability-map postprocessing uses a reusable ring queue containing only
the pending BFS frontier. Each popped pixel contributes its score and boundary
corners immediately; no full component index array is retained. Queue growth
preserves FIFO order even when wrapped, keeping score accumulation and boundary
order equivalent. Boundary storage grows with actual edge points. Queue,
boundary and geometry scratch are confined to one image; returned boxes own
their points. Thresholds, the 1000-component limit, geometry and stable sorting
are unchanged. The queue has no fixed size limit, and irregular components can
still require large frontiers or boundaries.

Geometry now sorts and deduplicates owned boundary scratch in place with a
typed comparator. A single reusable monotone-chain buffer replaces copied
sorting points and separate lower/upper allocations. Hull order, collinear
turn handling and the minimum-area rectangle calculation remain equivalent.
The private geometry helpers consume boundary storage and borrow the hull
until the next scratch reuse; only value-owned rectangles and boxes escape.
Storage is confined to one probability map, with no cross-image cache.

Visited pixels use one bit each and the bitmap is allocated only after the
first foreground component. The outer scan checks the probability threshold
before querying the bitmap, avoiding bit operations for background pixels.
Empty valid maps retain non-nil empty results
without Go postprocessing allocations. This excludes image decoding, input
preparation and native inference. Corner ordering uses a fixed four-point
array with the same insertion order as the old small-slice sort. Final stable
box sorting is skipped for fewer than two boxes. BFS order, score accumulation,
thresholds and the 1000-component limit remain unchanged.

Microbenchmarks and optional local CPU model benchmarks are in
`native_single_image_performance_test.go`. The latter require
`ZIMAOS_NCNN_NATIVE_LIBRARY_PATH`, `ZIMAOS_NCNN_BENCHMARK_DETECT_BUNDLE`, and
`ZIMAOS_NCNN_BENCHMARK_FACE_BUNDLE` to point to existing local files. They
include JPEG I/O, decoding, preparation, native inference and postprocessing,
with models loaded outside timing and four native inference threads. The
optional `TestNativeSingleImageOutputParity` additionally writes model outputs
and input tensor digests to `ZIMAOS_NCNN_PARITY_OUTPUT_DIR` for baseline
comparison. See the [measurements and validation report](../../docs/process/image-vlm-preprocessing-performance-2026-10-20.md).

`native_ocr_performance_test.go` adds padding and single-image OCR benchmarks.
Set `ZIMAOS_NCNN_BENCHMARK_OCR_BUNDLE` to a local RapidOCR bundle and
`ZIMAOS_NCNN_NATIVE_LIBRARY_PATH` to the NCNN library. Its detect, one-region
recognize and full two-line OCR cases use four native threads with model load
outside timing. `TestNativeOCRSingleImageParity` writes complete outputs and
the padded-pixel digest to `ZIMAOS_NCNN_OCR_PARITY_OUTPUT_DIR`; compare old and
new binaries. `native_ocr_output_test.go` separately benchmarks a simulated
64x6625 recognition output with finite-value validation and CTC decoding; that
microbenchmark does not run a native model.

`native_ocr_input_test.go` covers the removed input packing, including an
optional real NCNN comparison of normalized tensors when the native library
environment variable is set. `BenchmarkNativeOCRPreparedInput` measures Go
resize/clone and input preparation with simulated bindings; it excludes native
conversion and graph execution. Use `BenchmarkNativeOCRSingleImage` separately
for the complete single-image CPU path.

`native_ocr_postprocess_test.go` benchmarks blank, text, many-component and
dense 768x512 probability maps without native graph execution. A frozen decoder
checks traversal, boundaries and exact boxes/scores; allocation budgets prevent
duplicate component storage and oversized boundary buffers from returning.
Report these microbenchmarks separately from actual single-image OCR results.

`native_ocr_frontier_test.go` checks wrapped queue growth, randomized FIFO order,
allocation-free warm reuse and streaming traversal against the frozen BFS:
all visited bits, exact score bits, ordered boundary points and unchanged input.
It includes word/row boundaries, irregular regions and nonfinite values, plus
a dense-map frontier capacity check. The separate frontier allocation budget
test prevents retaining the full component again. Report even small allocation
increases on tiny components alongside the dense-map savings.

`native_ocr_geometry_test.go` checks zero warm per-component geometry
allocations, tighter full-map budgets and exact hull/rectangle parity against
the frozen old geometry, including degeneracy, ties, signed zero and large
convex hulls. This does not change the model, thresholds or public ABI.

`native_ocr_compact_postprocess_test.go` adds blank-map and per-box allocation
checks, compact full-map budgets, word/row boundary traversal parity, and exact
corner-ordering comparison with a frozen old implementation. Include dense
maps in CPU timing comparisons when evaluating the bitmap's resource savings.

`native_ocr_crop_test.go` freezes the old crop, generic sampling and rotation
to compare exact pixels across image types, transparency, nonzero bounds,
subimage stride, edge coordinates, tall rotation and concurrent ownership.
Tall crops write directly into one final canvas. NRGBA sampling reads visible
neighbors directly and keeps the original channel arithmetic and rounding.
`BenchmarkNativeOCRCropSingleRegion` reports horizontal/vertical NRGBA and JPEG
crop costs separately; use `BenchmarkNativeOCRSingleImage` for complete OCR
calls, including the unchanged detection-only control. Neither benchmark
measures VLM vision encoding or generation.

`native_ocr_identity_input_test.go` checks skipping the resize clone only for
NRGBA inputs already at the original target dimensions. Borrowed pixels are
read-only during synchronous NCNN conversion; subimages retain their stride
with a zero-origin header. Other types retain imaging's original path.
Tests compare visible bytes, projection, source ownership and optional native
normalized tensors. `BenchmarkNativeOCRResizeInput` uses simulated bindings
for same-size and resized cases. `BenchmarkNativeOCRIdentitySingleImage`
measures real aligned-detector and 48-high recognition cases; report those
separately from the existing unaligned single-image control. Savings depend
on dimensions and do not remove NCNN's own input Mat allocation.

Dual-axis NRGBA resizing now streams Linear-filtered rows through bounded
per-worker windows in `native_ocr_resize.go`, avoiding the complete horizontal
intermediate image. Weight calculation, channel/alpha accumulation, horizontal
byte quantization followed by vertical filtering, and rounding match imaging
v1.6.2. Each worker owns its cache and disjoint output rows; all workers finish
before returning the owned result. No state is retained across images. The
window size depends on the vertical filter support, and total scratch also
depends on GOMAXPROCS. Same-size borrowing, single-axis resizing, other types,
and invalid-size behavior retain their existing paths.

`native_ocr_resize_stream_test.go` compares complete pixels against imaging,
including transparent hidden colors, alpha endpoints, negative bounds, parent
stride, random/large ratios, window reuse and concurrent output ownership.
Fixed-single-CPU allocation budgets prevent the full intermediate from
returning. `BenchmarkNativeOCRStreamingResize` separates detector, recognizer
and larger downscales from same-size and single-axis controls. Measure real
`BenchmarkNativeOCRSingleImage` independently and compare complete model JSON;
local resize speedups are not full OCR or VLM speedups. Rebuild and install the
shared library for this change to take effect.

OCR detection synthesizes white border rows while streaming the
original two-pass Linear filter, avoiding a full padded canvas when an
NRGBA/YCbCr source changes on both axes. Per-worker scan rows preserve source
stride, alpha, negative bounds and the standard library's YCbCr conversion.
Full OCR uses this detection path too; same-size, single-axis, other types
and invalid padded dimensions retain the existing path. Any full canvas
created by that fallback is reused for recognition. The Photos contract
of a detection precheck followed by ordinary full OCR is unchanged; this does
not enable detection-box reuse or skip detection in the full call.

`native_ocr_fused_detector_test.go` compares complete detector input bytes and
boxes against independent old padding/Linear and postprocessing references,
including all YCbCr subsampling ratios, both profiles, concurrent ownership
and overflowed-size errors. Fixed-single-CPU budgets reject the full canvas.
`BenchmarkNativeOCRFusedDetector` uses simulated inference to separate NRGBA,
JPEG and larger JPEG preparation from aligned calls. Its historical
`full-jpeg-control` case now also uses streaming detection. Report
actual `BenchmarkNativeOCRSingleImage` detect/recognize/full independently;
precheck savings are not full OCR, RSS/native-memory or VLM speedups. Rebuild
and install the shared library to enable this path.

YOLO/SCRFD dual-axis NRGBA/YCbCr resizing uses the same row windows to write
directly into the final RGB letterbox tensor. This removes the full horizontal
intermediate and the final NRGBA resize canvas. Horizontal byte quantization,
vertical alpha-weighted filtering, unpremultiplication and RGB rounding remain
identical to imaging v1.6.2. Final alpha is discarded; transparent visible pixels
explicitly overwrite the tensor with zeros instead of retaining padding 114.
Each worker owns its scratch and disjoint output rows; no state survives the
call. Same-size, single-axis and other image types retain their original path.
Face embedding still skips detector preparation. NCNN input Mat allocation,
normalization, target dimensions, projection and model settings are unchanged.

`native_detector_stream_test.go` first enforces decoded-source + RGB-output +
512 KiB allocation budgets at one Go CPU for both detector profiles. Independent
old imaging references compare all RGB bytes and projection, including
transparency, tiny/portrait inputs, fallback types and concurrent ownership.
The reused source reader is checked with negative bounds, parent stride and
all six YCbCr subsampling ratios. `BenchmarkNativeDetectorStreamingPreparation`
includes file read/decode and has aligned, single-axis and grayscale controls;
it excludes native conversion and graph execution. Compare real
`BenchmarkNativeSingleImageInference` separately, keeping face embedding as a
control. The shared filter also emits OCR NRGBA, so verify OCR pixels, model
JSON and performance too. Rebuild/install the library; Go B/op is not RSS,
native memory or VLM latency.

Full OCR and explicit skip-detection recognition prepare only the bounding rectangle of
text regions for cropping when no full fallback canvas exists. The region
keeps the original padded coordinates and a bilinear sampling halo; geometry,
rounding, rotation and model input remain unchanged. Interior NRGBA regions
borrow a read-only header; YCbCr converts only the required region with the
same standard-library conversion as the full canvas. Regions touching the
border contain the original white pixels. Unsupported types retain the full
canvas conversion. Empty boxes and detection-only calls need no crop canvas.
The rectangle can cover the whole image; no cross-image cache or pool is added.
Final crops and native Mats still own their storage. This does not enable
Photos detection-box reuse or change its ordinary full-call contract.

`native_ocr_region_test.go` first rejects whole-canvas allocation for NRGBA and
JPEG recognition, empty full calls and empty/detection-only skip calls. An
independent old full-canvas/crop/Linear oracle checks complete model input,
including negative bounds, parent stride, six YCbCr subsampling ratios,
transparency, border/tilted/rotated/multiple boxes, fallback paths, crop errors
and concurrent source ownership. `BenchmarkNativeOCRRegionPreparation` uses
simulated bindings and excludes image decoding and native graph execution.
Compare actual ordinary and aligned `BenchmarkNativeOCR{Identity,}SingleImage`
separately, including all time ranges and regressions. Rebuild and install
the shared library; Go cumulative allocation is not RSS/native peak memory
or VLM inference speed.

## Optional Embedding Helper Mode

For local bring-up, the wrapper can expose a real `embedding` model-class path by
delegating `Load`/`Infer` to a Python helper script instead of native NCNN
kernels.

Enable it explicitly:

```bash
export ZIMAOS_NCNN_RUNTIME_ENABLE_EMBEDDING_HELPER=1
export ZIMAOS_NCNN_RUNTIME_EMBEDDING_HELPER_PYTHON="$HOME/.cache/zimaos-mds-model-cache/photo-search/public-helper-venv/bin/python"
export ZIMAOS_NCNN_RUNTIME_EMBEDDING_HELPER_SCRIPT="/path/to/repo/scripts/ncnn_embedding_helper.py"
```

Scope and limits:

- helper mode currently only supports `model_class=embedding`
- this is intended as a correctness / integration bridge, not the final native runtime design
