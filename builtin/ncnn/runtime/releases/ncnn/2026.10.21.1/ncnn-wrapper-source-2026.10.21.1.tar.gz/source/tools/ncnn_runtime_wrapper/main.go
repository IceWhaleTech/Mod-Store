package main

/*
#include <stdint.h>
#include <stdlib.h>
*/
import "C"

import (
	"encoding/json"
	"fmt"
	"math"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"unsafe"

	"github.com/IceWhaleTech/zimaos-photos/internal/embedtokenizer"
)

const modelClassVision = "vision"
const modelClassEmbedding = "embedding"
const modelClassOCR = "ocr"

const ncnnRuntimeArtifactABI = "v7"
const ncnnRuntimeJSONABI = "json-v2"

var ncnnRuntimeVersion = "2026.09.04.1"

const (
	envEnableEmbeddingHelper = "ZIMAOS_NCNN_RUNTIME_ENABLE_EMBEDDING_HELPER"
	envEmbeddingHelperPython = "ZIMAOS_NCNN_RUNTIME_EMBEDDING_HELPER_PYTHON"
	envEmbeddingHelperScript = "ZIMAOS_NCNN_RUNTIME_EMBEDDING_HELPER_SCRIPT"
)

type deviceInfo struct {
	Backend string `json:"backend,omitempty"`
	Name    string `json:"name,omitempty"`
	ID      string `json:"id,omitempty"`
}

type runtimeStatus struct {
	RuntimeVersion    string            `json:"runtime_version,omitempty"`
	ArtifactABI       string            `json:"artifact_abi,omitempty"`
	JSONABI           string            `json:"json_abi,omitempty"`
	SupportedTasks    []string          `json:"supported_tasks,omitempty"`
	BackendMode       string            `json:"backend_mode,omitempty"`
	BackendRequested  []string          `json:"backend_requested,omitempty"`
	SupportedBackends []string          `json:"supported_backends,omitempty"`
	AvailableDevices  []deviceInfo      `json:"available_devices,omitempty"`
	PreferredBackend  string            `json:"preferred_backend,omitempty"`
	BackendEffective  string            `json:"backend_effective,omitempty"`
	DeviceEffective   string            `json:"device_effective,omitempty"`
	DegradedToCPU     bool              `json:"degraded_to_cpu,omitempty"`
	DegradeReason     string            `json:"degrade_reason,omitempty"`
	BackendErrors     map[string]string `json:"backend_errors,omitempty"`
	LoadedClasses     []string          `json:"loaded_classes,omitempty"`
}

type loadRequest struct {
	ModelClass        string                 `json:"model_class"`
	BundleID          string                 `json:"bundle_id"`
	BundlePath        string                 `json:"bundle_path,omitempty"`
	BackendCandidates []string               `json:"backend_candidates,omitempty"`
	DeviceHint        string                 `json:"device_hint,omitempty"`
	AllowCPUFallback  bool                   `json:"allow_cpu_fallback"`
	Priority          string                 `json:"priority,omitempty"`
	ThreadLimit       int                    `json:"thread_limit,omitempty"`
	Metadata          map[string]interface{} `json:"metadata,omitempty"`
}

type loadResult struct {
	BackendEffective string `json:"backend_effective,omitempty"`
	DeviceEffective  string `json:"device_effective,omitempty"`
	DegradedToCPU    bool   `json:"degraded_to_cpu,omitempty"`
	DegradeReason    string `json:"degrade_reason,omitempty"`
}

type loadResultPayload struct {
	loadResult
	Error string `json:"error,omitempty"`
}

type inferRequest struct {
	ModelClass  string                 `json:"model_class"`
	BundleID    string                 `json:"bundle_id,omitempty"`
	Task        string                 `json:"task,omitempty"`
	ThreadLimit int                    `json:"thread_limit,omitempty"`
	Input       map[string]interface{} `json:"input,omitempty"`
}

type bundleReadyManifest struct {
	BundleID   string   `json:"bundle_id"`
	ModelClass string   `json:"model_class"`
	Artifacts  []string `json:"artifacts"`
}

type wrapperStatus struct {
	runtimeStatus
	Available *bool `json:"available,omitempty"`
}

type wrapperInferResult struct {
	Output map[string]interface{} `json:"output,omitempty"`
}

func modelClassBase(modelClass string) string {
	modelClass = strings.TrimSpace(modelClass)
	if modelClass == "" {
		return ""
	}
	if index := strings.Index(modelClass, ":"); index >= 0 {
		modelClass = modelClass[:index]
	}
	return strings.TrimSpace(modelClass)
}

func modelClassMatchesUnload(existing string, requested string) bool {
	existing = strings.TrimSpace(existing)
	requested = strings.TrimSpace(requested)
	if requested == "" {
		return true
	}
	if strings.Contains(requested, ":") {
		return strings.EqualFold(existing, requested)
	}
	return strings.EqualFold(modelClassBase(existing), requested)
}

type createRuntimeResult struct {
	HandleID uint64 `json:"handle_id"`
}

var wrapperAvailableFalse = false
var wrapperAvailableTrue = true
var wrapperRuntimeHandles = newWrapperRuntimeHandleManager()

func main() {}

//export zima_ncnn_create_json_v2
func zima_ncnn_create_json_v2(req *C.char, reqLen C.size_t, out *C.char, outCap C.size_t) C.size_t {
	_ = req
	_ = reqLen
	handleID, err := wrapperRuntimeHandles.create()
	if err != nil {
		payload := mustMarshal(map[string]interface{}{"error": err.Error()})
		return writeJSONResponse(payload, out, outCap)
	}
	payload := mustMarshal(createRuntimeResult{HandleID: handleID})
	return writeJSONResponse(payload, out, outCap)
}

//export zima_ncnn_destroy_json_v2
func zima_ncnn_destroy_json_v2(req *C.char, reqLen C.size_t, out *C.char, outCap C.size_t) C.size_t {
	var parsed handleRequest
	_ = decodeJSONRequest(req, reqLen, &parsed)
	if err := wrapperRuntimeHandles.destroy(parsed.HandleID); err != nil {
		payload := mustMarshal(map[string]interface{}{"error": err.Error()})
		return writeJSONResponse(payload, out, outCap)
	}
	payload := mustMarshal(map[string]interface{}{"ok": true})
	return writeJSONResponse(payload, out, outCap)
}

//export zima_ncnn_status_json_v2
func zima_ncnn_status_json_v2(req *C.char, reqLen C.size_t, out *C.char, outCap C.size_t) C.size_t {
	runtimeValue, err := wrapperRuntimeHandles.runtimeFromJSONRequest(req, reqLen)
	if err != nil {
		payload := mustMarshal(map[string]interface{}{"error": err.Error()})
		return writeJSONResponse(payload, out, outCap)
	}
	helper, helperEnabled := resolveEmbeddingHelperSpec()
	native, nativeEnabled := resolveNativeEmbeddingSpec()
	payload := mustMarshal(runtimeValue.status(helper, helperEnabled, native, nativeEnabled))
	return writeJSONResponse(payload, out, outCap)
}

//export zima_ncnn_load_json_v2
func zima_ncnn_load_json_v2(req *C.char, reqLen C.size_t, out *C.char, outCap C.size_t) C.size_t {
	var parsed handledLoadRequest
	_ = decodeJSONRequest(req, reqLen, &parsed)
	runtimeValue, err := wrapperRuntimeHandles.runtime(parsed.HandleID)
	if err != nil {
		payload := mustMarshal(loadResultPayload{Error: err.Error()})
		return writeJSONResponse(payload, out, outCap)
	}
	loadReq := parsed.loadRequest
	modelClass := strings.TrimSpace(loadReq.ModelClass)
	if modelClass == "" {
		modelClass = modelClassVision
	}
	modelBaseClass := modelClassBase(modelClass)
	if modelBaseClass == "" {
		modelBaseClass = modelClassVision
	}
	backendRequested := normalizeBackendList(loadReq.BackendCandidates)
	degradedToCPU := len(backendRequested) > 0 && !onlyCPUBackends(backendRequested)
	result := loadResultPayload{
		loadResult: loadResult{
			BackendEffective: "cpu",
			DeviceEffective:  "cpu:stub",
			DegradedToCPU:    degradedToCPU,
			DegradeReason:    "ncnn_runtime_unavailable",
		},
	}
	bundleDir, err := resolveValidatedBundleDir(loadReq.BundleID, loadReq.BundlePath, modelBaseClass)
	if err != nil {
		runtimeValue.rememberLoadFailure(err.Error())
		result.Error = err.Error()
		return writeJSONResponse(mustMarshal(result), out, outCap)
	}
	if helper, ok := resolveEmbeddingHelperSpec(); ok && strings.EqualFold(modelBaseClass, modelClassEmbedding) {
		loadResult, err := tryEmbeddingHelperLoad(helper, bundleDir, backendRequested)
		if err != nil {
			runtimeValue.rememberLoadFailure(err.Error())
			result.Error = err.Error()
			return writeJSONResponse(mustMarshal(result), out, outCap)
		}
		runtimeValue.rememberLoad(modelClass, backendRequested, bundleDir, loadReq.BundleID)
		return writeJSONResponse(mustMarshal(loadResult), out, outCap)
	}
	if native, ok := runtimeValue.nativeSpec(); ok && strings.EqualFold(modelBaseClass, modelClassEmbedding) {
		if _, supported, err := embedtokenizer.DetectBundleTextProfile(bundleDir); err != nil {
			runtimeValue.rememberLoadFailure(err.Error())
			result.Error = err.Error()
			return writeJSONResponse(mustMarshal(result), out, outCap)
		} else if supported {
			loadResult, err := tryNativeEmbeddingLoad(native, modelClass, bundleDir, loadReq, backendRequested)
			if err != nil {
				runtimeValue.rememberLoadFailure(err.Error())
				result.Error = err.Error()
				return writeJSONResponse(mustMarshal(result), out, outCap)
			}
			runtimeValue.rememberLoad(modelClass, backendRequested, bundleDir, loadReq.BundleID)
			return writeJSONResponse(mustMarshal(loadResult), out, outCap)
		}
	}
	if native, ok := runtimeValue.nativeSpec(); ok && strings.EqualFold(modelBaseClass, modelClassOCR) {
		loadResult, handled, err := tryNativeOCRLoad(native, modelClass, bundleDir, loadReq, backendRequested)
		if handled {
			if err != nil {
				runtimeValue.rememberLoadFailure(err.Error())
				result.Error = err.Error()
				return writeJSONResponse(mustMarshal(result), out, outCap)
			}
			runtimeValue.rememberLoad(modelClass, backendRequested, bundleDir, loadReq.BundleID)
			return writeJSONResponse(mustMarshal(loadResult), out, outCap)
		}
	}
	if native, ok := runtimeValue.nativeSpec(); ok && strings.EqualFold(modelBaseClass, modelClassVision) {
		loadResult, handled, err := tryNativeVisionLoad(native, modelClass, bundleDir, loadReq, backendRequested)
		if handled {
			if err != nil {
				runtimeValue.rememberLoadFailure(err.Error())
				result.Error = err.Error()
				return writeJSONResponse(mustMarshal(result), out, outCap)
			}
			runtimeValue.rememberLoad(modelClass, backendRequested, bundleDir, loadReq.BundleID)
			return writeJSONResponse(mustMarshal(loadResult), out, outCap)
		}
	}
	runtimeValue.rememberLoad(modelClass, backendRequested, bundleDir, loadReq.BundleID)

	return writeJSONResponse(mustMarshal(result), out, outCap)
}

//export zima_ncnn_infer_json_v2
func zima_ncnn_infer_json_v2(req *C.char, reqLen C.size_t, out *C.char, outCap C.size_t) C.size_t {
	var parsed handledInferRequest
	_ = decodeJSONRequest(req, reqLen, &parsed)
	runtimeValue, err := wrapperRuntimeHandles.runtime(parsed.HandleID)
	if err != nil {
		payload := mustMarshal(wrapperInferResult{
			Output: map[string]interface{}{
				"ok":    false,
				"error": err.Error(),
			},
		})
		return writeJSONResponse(payload, out, outCap)
	}
	inferReq := parsed.inferRequest
	if helper, ok := resolveEmbeddingHelperSpec(); ok {
		if result, ok := tryEmbeddingHelperInfer(runtimeValue, helper, inferReq); ok {
			payload := mustMarshal(result)
			return writeJSONResponse(payload, out, outCap)
		}
	}
	if native, ok := runtimeValue.nativeSpec(); ok {
		if result, ok := tryNativeEmbeddingInfer(runtimeValue, native, inferReq); ok {
			payload := mustMarshal(result)
			return writeJSONResponse(payload, out, outCap)
		}
		if result, ok := tryNativeVisionInfer(runtimeValue, native, inferReq); ok {
			payload := mustMarshal(result)
			return writeJSONResponse(payload, out, outCap)
		}
		if result, ok := tryNativeOCRInfer(runtimeValue, native, inferReq); ok {
			payload := mustMarshal(result)
			return writeJSONResponse(payload, out, outCap)
		}
	}
	loaded := runtimeValue.isLoaded(strings.TrimSpace(inferReq.ModelClass))
	errorCode := "ncnn_runtime_unavailable"
	if !loaded {
		errorCode = "ncnn_model_class_not_loaded"
	}
	payload := mustMarshal(wrapperInferResult{
		Output: map[string]interface{}{
			"ok":             false,
			"error":          errorCode,
			"degrade_reason": "ncnn_wrapper_stub",
			"model_class":    strings.TrimSpace(inferReq.ModelClass),
			"task":           strings.TrimSpace(inferReq.Task),
			"loaded":         loaded,
		},
	})
	return writeJSONResponse(payload, out, outCap)
}

//export zima_ncnn_unload_json_v2
func zima_ncnn_unload_json_v2(req *C.char, reqLen C.size_t, out *C.char, outCap C.size_t) C.size_t {
	var parsed handledUnloadRequest
	_ = decodeJSONRequest(req, reqLen, &parsed)
	runtimeValue, err := wrapperRuntimeHandles.runtime(parsed.HandleID)
	if err != nil {
		payload := mustMarshal(map[string]interface{}{"error": err.Error()})
		return writeJSONResponse(payload, out, outCap)
	}
	if native, ok := runtimeValue.nativeSpec(); ok && native.backend != nil {
		native.backend.unload(strings.TrimSpace(parsed.ModelClass))
	}
	runtimeValue.unload(strings.TrimSpace(parsed.ModelClass))
	payload := mustMarshal(map[string]interface{}{"ok": true})
	return writeJSONResponse(payload, out, outCap)
}

//export zima_ncnn_switch_backend_json_v2
func zima_ncnn_switch_backend_json_v2(req *C.char, reqLen C.size_t, out *C.char, outCap C.size_t) C.size_t {
	var parsed handledSwitchBackendRequest
	_ = decodeJSONRequest(req, reqLen, &parsed)
	runtimeValue, err := wrapperRuntimeHandles.runtime(parsed.HandleID)
	if err != nil {
		payload := mustMarshal(map[string]interface{}{"error": err.Error()})
		return writeJSONResponse(payload, out, outCap)
	}
	if native, ok := runtimeValue.nativeSpec(); ok && native.backend != nil {
		native.backend.unload("")
	}
	runtimeValue.switchBackends(parsed.BackendCandidates)
	helper, helperEnabled := resolveEmbeddingHelperSpec()
	native, nativeEnabled := resolveNativeEmbeddingSpec()
	payload := mustMarshal(runtimeValue.status(helper, helperEnabled, native, nativeEnabled))
	return writeJSONResponse(payload, out, outCap)
}

func mustMarshal(value interface{}) []byte {
	payload, err := json.Marshal(value)
	if err != nil {
		return []byte(`{"error":"json_marshal_failed"}`)
	}
	return payload
}

func writeJSONResponse(payload []byte, out *C.char, outCap C.size_t) C.size_t {
	required := C.size_t(len(payload))
	if out == nil || outCap == 0 {
		return required
	}
	buffer := unsafe.Slice((*byte)(unsafe.Pointer(out)), int(outCap))
	n := copy(buffer, payload)
	if n < len(buffer) {
		buffer[n] = 0
	}
	return required
}

func decodeJSONRequest(req *C.char, reqLen C.size_t, out interface{}) error {
	if req == nil || reqLen == 0 {
		return nil
	}
	raw := C.GoBytes(unsafe.Pointer(req), C.int(reqLen))
	if len(raw) == 0 {
		return nil
	}
	return json.Unmarshal(raw, out)
}

func onlyCPUBackends(backends []string) bool {
	for _, backend := range backends {
		if !strings.EqualFold(strings.TrimSpace(backend), "cpu") {
			return false
		}
	}
	return true
}

type handleRequest struct {
	HandleID uint64 `json:"handle_id"`
}

type handledLoadRequest struct {
	HandleID uint64 `json:"handle_id"`
	loadRequest
}

type handledInferRequest struct {
	HandleID uint64 `json:"handle_id"`
	inferRequest
}

type handledUnloadRequest struct {
	HandleID   uint64 `json:"handle_id"`
	ModelClass string `json:"model_class"`
}

type handledSwitchBackendRequest struct {
	HandleID          uint64   `json:"handle_id"`
	BackendCandidates []string `json:"backend_candidates"`
}

type wrapperRuntimeState struct {
	mu               sync.Mutex
	backendRequested []string
	loadedClasses    []string
	loadedBundles    map[string]string
	loadedBundleIDs  map[string]string
	lastLoadError    string
	native           nativeEmbeddingSpec
}

type wrapperRuntimeHandleManager struct {
	mu       sync.Mutex
	nextID   uint64
	runtimes map[uint64]*wrapperRuntimeState
}

func newWrapperRuntimeHandleManager() *wrapperRuntimeHandleManager {
	return &wrapperRuntimeHandleManager{
		nextID:   1,
		runtimes: make(map[uint64]*wrapperRuntimeState),
	}
}

func newWrapperRuntimeState() (*wrapperRuntimeState, error) {
	native, _ := resolveNativeEmbeddingSpec()
	return &wrapperRuntimeState{
		backendRequested: []string{"cpu"},
		loadedBundles:    make(map[string]string),
		loadedBundleIDs:  make(map[string]string),
		native:           native,
	}, nil
}

func (m *wrapperRuntimeHandleManager) create() (uint64, error) {
	if m == nil {
		return 0, fmt.Errorf("wrapper runtime handle manager is unavailable")
	}
	runtimeValue, err := newWrapperRuntimeState()
	if err != nil {
		return 0, err
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	handleID := m.nextID
	m.nextID++
	m.runtimes[handleID] = runtimeValue
	return handleID, nil
}

func (m *wrapperRuntimeHandleManager) runtime(handleID uint64) (*wrapperRuntimeState, error) {
	if m == nil {
		return nil, fmt.Errorf("wrapper runtime handle manager is unavailable")
	}
	if handleID == 0 {
		return nil, fmt.Errorf("ncnn runtime handle_id is required")
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	runtimeValue := m.runtimes[handleID]
	if runtimeValue == nil {
		return nil, fmt.Errorf("ncnn runtime handle %d not found", handleID)
	}
	return runtimeValue, nil
}

func (m *wrapperRuntimeHandleManager) runtimeFromJSONRequest(req *C.char, reqLen C.size_t) (*wrapperRuntimeState, error) {
	var parsed handleRequest
	if err := decodeJSONRequest(req, reqLen, &parsed); err != nil {
		return nil, err
	}
	return m.runtime(parsed.HandleID)
}

func (m *wrapperRuntimeHandleManager) destroy(handleID uint64) error {
	runtimeValue, err := m.runtime(handleID)
	if err != nil {
		return err
	}
	if native, ok := runtimeValue.nativeSpec(); ok && native.backend != nil {
		native.backend.unload("")
	}
	runtimeValue.unload("")
	m.mu.Lock()
	defer m.mu.Unlock()
	delete(m.runtimes, handleID)
	return nil
}

func (s *wrapperRuntimeState) nativeSpec() (nativeEmbeddingSpec, bool) {
	if s == nil || s.native.backend == nil {
		return nativeEmbeddingSpec{}, false
	}
	return s.native, true
}

func (s *wrapperRuntimeState) status(helper embeddingHelperSpec, helperEnabled bool, native nativeEmbeddingSpec, nativeEnabled bool) wrapperStatus {
	s.mu.Lock()
	defer s.mu.Unlock()

	degradeReason := "ncnn_wrapper_stub"
	backendErrors := buildBackendErrors(s.lastLoadError)
	if nativeErr := nativeEmbeddingBackendError(); strings.TrimSpace(nativeErr) != "" {
		backendErrors["native"] = nativeErr
	}
	available := &wrapperAvailableFalse
	device := deviceInfo{Backend: "cpu", Name: "stub-cpu", ID: "cpu:stub"}
	deviceEffective := helper.deviceID()
	if helperEnabled {
		degradeReason = ""
		backendErrors = buildHelperBackendErrors(s.lastLoadError)
		available = &wrapperAvailableTrue
		device = deviceInfo{Backend: "cpu", Name: "embedding-helper-cpu", ID: helper.deviceID()}
		deviceEffective = helper.deviceID()
	} else if nativeEnabled {
		degradeReason = ""
		backendErrors = buildNativeBackendErrors(s.lastLoadError, native.libraryPath())
		available = &wrapperAvailableTrue
		device = deviceInfo{Backend: "cpu", Name: "ncnn-native-cpu", ID: native.deviceID()}
		deviceEffective = native.deviceID()
	}
	return wrapperStatus{
		runtimeStatus: runtimeStatus{
			RuntimeVersion: ncnnRuntimeVersion,
			ArtifactABI:    ncnnRuntimeArtifactABI,
			JSONABI:        ncnnRuntimeJSONABI,
			SupportedTasks: []string{
				"text_embedding",
				"detect",
				"detect_*",
				"face",
				"face_detect",
				"face_embed",
				"ocr",
			},
			BackendRequested: append([]string(nil), s.backendRequested...),
			SupportedBackends: []string{
				"cpu",
			},
			AvailableDevices: []deviceInfo{device},
			PreferredBackend: "cpu",
			BackendEffective: "cpu",
			DeviceEffective:  deviceEffective,
			DegradedToCPU:    false,
			DegradeReason:    degradeReason,
			BackendErrors:    backendErrors,
			LoadedClasses:    append([]string(nil), s.loadedClasses...),
		},
		Available: available,
	}
}

func (s *wrapperRuntimeState) rememberLoad(modelClass string, backendRequested []string, bundleDir string, bundleID string) {
	s.mu.Lock()
	defer s.mu.Unlock()

	if len(backendRequested) > 0 {
		s.backendRequested = append([]string(nil), backendRequested...)
	}
	s.lastLoadError = ""
	if modelClass = strings.TrimSpace(modelClass); modelClass != "" {
		s.loadedBundles[modelClass] = strings.TrimSpace(bundleDir)
		s.loadedBundleIDs[modelClass] = strings.TrimSpace(bundleID)
	}
	s.touchLoadedLocked(modelClass)
}

func (s *wrapperRuntimeState) rememberLoadFailure(message string) {
	s.mu.Lock()
	defer s.mu.Unlock()

	s.lastLoadError = strings.TrimSpace(message)
}

func (s *wrapperRuntimeState) unload(modelClass string) {
	s.mu.Lock()
	defer s.mu.Unlock()

	modelClass = strings.TrimSpace(modelClass)
	if modelClass == "" {
		s.loadedClasses = nil
		s.loadedBundles = make(map[string]string)
		s.loadedBundleIDs = make(map[string]string)
		return
	}
	filtered := s.loadedClasses[:0]
	for _, existing := range s.loadedClasses {
		if modelClassMatchesUnload(existing, modelClass) {
			delete(s.loadedBundles, strings.TrimSpace(existing))
			delete(s.loadedBundleIDs, strings.TrimSpace(existing))
			continue
		}
		filtered = append(filtered, existing)
	}
	s.loadedClasses = filtered
}

func (s *wrapperRuntimeState) switchBackends(backends []string) {
	s.mu.Lock()
	defer s.mu.Unlock()

	normalized := normalizeBackendList(backends)
	if len(normalized) == 0 {
		normalized = []string{"cpu"}
	}
	s.backendRequested = append([]string(nil), normalized...)
	s.loadedClasses = nil
	s.loadedBundles = make(map[string]string)
	s.loadedBundleIDs = make(map[string]string)
}

func (s *wrapperRuntimeState) isLoaded(modelClass string) bool {
	s.mu.Lock()
	defer s.mu.Unlock()

	modelClass = strings.TrimSpace(modelClass)
	for _, existing := range s.loadedClasses {
		if strings.EqualFold(strings.TrimSpace(existing), modelClass) {
			return true
		}
	}
	return false
}

func (s *wrapperRuntimeState) loadedBundle(modelClass string) (string, string, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()

	modelClass = strings.TrimSpace(modelClass)
	if modelClass == "" {
		return "", "", false
	}
	bundleDir := strings.TrimSpace(s.loadedBundles[modelClass])
	if bundleDir == "" {
		return "", "", false
	}
	return bundleDir, strings.TrimSpace(s.loadedBundleIDs[modelClass]), true
}

func (s *wrapperRuntimeState) touchLoadedLocked(modelClass string) {
	modelClass = strings.TrimSpace(modelClass)
	if modelClass == "" {
		return
	}
	filtered := s.loadedClasses[:0]
	for _, existing := range s.loadedClasses {
		if strings.EqualFold(strings.TrimSpace(existing), modelClass) {
			continue
		}
		filtered = append(filtered, existing)
	}
	s.loadedClasses = append(filtered, modelClass)
}

func autoBackendCandidates() []string {
	return []string{"qcom", "cuda", "rocm", "oneapi", "sycl", "vulkan", "cpu"}
}

func normalizeBackendList(values []string) []string {
	seen := make(map[string]struct{}, len(values))
	result := make([]string, 0, len(values))
	for _, value := range values {
		for _, part := range strings.Split(value, ",") {
			backend := normalizeBackend(part)
			if backend == "" {
				continue
			}
			if backend == "auto" {
				for _, candidate := range autoBackendCandidates() {
					if _, ok := seen[candidate]; ok {
						continue
					}
					seen[candidate] = struct{}{}
					result = append(result, candidate)
				}
				continue
			}
			if _, ok := seen[backend]; ok {
				continue
			}
			seen[backend] = struct{}{}
			result = append(result, backend)
		}
	}
	if len(result) == 0 {
		return autoBackendCandidates()
	}
	return result
}

func normalizeBackend(value string) string {
	value = strings.ToLower(strings.TrimSpace(value))
	switch value {
	case "", "default":
		return ""
	case "syscl":
		return "sycl"
	default:
		return value
	}
}

func resolveValidatedBundleDir(bundleID, bundlePath, modelClass string) (string, error) {
	bundleDir, err := resolveBundleDir(bundleID, bundlePath)
	if err != nil {
		return "", err
	}
	if err := validateBundleDir(bundleDir, bundleID, modelClass); err != nil {
		return "", err
	}
	return bundleDir, nil
}

func resolveBundleDir(bundleID, bundlePath string) (string, error) {
	if path := strings.TrimSpace(bundlePath); path != "" {
		return filepath.Clean(path), nil
	}
	bundleID = strings.TrimSpace(bundleID)
	if bundleID == "" {
		return "", fmt.Errorf("ncnn bundle id or bundle path is required")
	}
	for _, candidate := range candidateBundleDirs(bundleID) {
		if hasReadyManifest(candidate) {
			return candidate, nil
		}
	}
	return "", fmt.Errorf("ncnn bundle %s is not ready in the standard model cache", bundleID)
}

func validateBundleDir(bundleDir, bundleID, modelClass string) error {
	bundleDir = filepath.Clean(strings.TrimSpace(bundleDir))
	if bundleDir == "" {
		return fmt.Errorf("ncnn bundle path is required")
	}
	info, err := os.Stat(bundleDir)
	if err != nil {
		return fmt.Errorf("ncnn bundle path %s not accessible: %w", bundleDir, err)
	}
	if !info.IsDir() {
		return fmt.Errorf("ncnn bundle path %s is not a directory", bundleDir)
	}
	manifestPath := filepath.Join(bundleDir, ".ready.json")
	data, err := os.ReadFile(manifestPath)
	if err != nil {
		return fmt.Errorf("ncnn bundle %s missing .ready.json: %w", bundleDir, err)
	}
	var manifest bundleReadyManifest
	if err := json.Unmarshal(data, &manifest); err != nil {
		return fmt.Errorf("decode ncnn bundle manifest %s: %w", manifestPath, err)
	}
	if expected := strings.TrimSpace(bundleID); expected != "" && strings.TrimSpace(manifest.BundleID) != "" && !strings.EqualFold(strings.TrimSpace(manifest.BundleID), expected) {
		return fmt.Errorf("ncnn bundle manifest %s reports bundle_id=%s, want %s", manifestPath, manifest.BundleID, expected)
	}
	if expected := modelClassBase(modelClass); expected != "" && strings.TrimSpace(manifest.ModelClass) != "" && !strings.EqualFold(strings.TrimSpace(manifest.ModelClass), expected) {
		return fmt.Errorf("ncnn bundle manifest %s reports model_class=%s, want %s", manifestPath, manifest.ModelClass, expected)
	}
	if len(manifest.Artifacts) == 0 {
		return fmt.Errorf("ncnn bundle manifest %s does not list any artifacts", manifestPath)
	}
	for _, artifact := range manifest.Artifacts {
		artifactPath := strings.TrimSpace(artifact)
		if artifactPath == "" {
			continue
		}
		if !filepath.IsAbs(artifactPath) {
			artifactPath = filepath.Join(bundleDir, artifactPath)
		}
		info, err := os.Stat(artifactPath)
		if err != nil {
			return fmt.Errorf("ncnn bundle artifact missing: %s: %w", artifactPath, err)
		}
		if info.IsDir() {
			return fmt.Errorf("ncnn bundle artifact %s is a directory", artifactPath)
		}
	}
	return nil
}

func candidateBundleDirs(bundleID string) []string {
	bundleID = strings.TrimSpace(bundleID)
	if bundleID == "" {
		return nil
	}
	seen := make(map[string]struct{}, 8)
	candidates := make([]string, 0, 8)
	appendCandidate := func(candidate string) {
		candidate = filepath.Clean(strings.TrimSpace(candidate))
		if candidate == "" {
			return
		}
		if _, ok := seen[candidate]; ok {
			return
		}
		seen[candidate] = struct{}{}
		candidates = append(candidates, candidate)
	}
	for _, cacheDir := range candidateModelCacheDirs() {
		for _, alias := range bundleAliases(bundleID) {
			appendCandidate(filepath.Join(cacheDir, "ncnn", alias))
		}
	}
	return candidates
}

func candidateModelCacheDirs() []string {
	seen := make(map[string]struct{}, 6)
	candidates := make([]string, 0, 6)
	appendCandidate := func(candidate string) {
		candidate = filepath.Clean(strings.TrimSpace(candidate))
		if candidate == "" {
			return
		}
		if _, ok := seen[candidate]; ok {
			return
		}
		seen[candidate] = struct{}{}
		candidates = append(candidates, candidate)
	}
	appendCandidate(os.Getenv("ZIMAOS_MODEL_CACHE_DIR"))
	if isLikelyZimaOSEnvironment() {
		appendCandidate("/media/ZimaOS-HD/AppData/photos/models")
		appendCandidate("/media/ZimaOS-HD/AppData/.models")
		appendCandidate("/media/ZimaOS-HD/AppData/.search/models")
		appendCandidate("/media/ZimaOS-HD/AppData/.search")
	}
	if homeDir, err := os.UserHomeDir(); err == nil {
		appendCandidate(filepath.Join(strings.TrimSpace(homeDir), ".cache", "zimaos-mds-model-cache"))
	}
	appendCandidate(filepath.Join(os.TempDir(), "zimaos-mds-model-cache"))
	return candidates
}

func bundleAliases(bundleID string) []string {
	return []string{bundleID}
}

func hasReadyManifest(bundleDir string) bool {
	info, err := os.Stat(filepath.Join(strings.TrimSpace(bundleDir), ".ready.json"))
	return err == nil && !info.IsDir()
}

func isLikelyZimaOSEnvironment() bool {
	target := strings.ToLower(strings.TrimSpace(os.Getenv("ZIMAOS_RUNTIME_TARGET")))
	switch target {
	case "zimaos", "zimaos-buildroot", "buildroot", "casaos":
		return true
	}
	if _, err := os.Stat("/etc/casaos"); err == nil {
		return true
	}
	if _, err := os.Stat("/media/ZimaOS-HD"); err == nil {
		return true
	}
	data, err := os.ReadFile("/etc/os-release")
	if err != nil {
		return false
	}
	text := strings.ToLower(string(data))
	return strings.Contains(text, "zimaos") || strings.Contains(text, "casaos") || strings.Contains(text, "buildroot")
}

func buildBackendErrors(lastLoadError string) map[string]string {
	errors := map[string]string{
		"cpu": "built-in wrapper scaffold compiled successfully, but real ncnn kernels are not linked yet",
	}
	if text := strings.TrimSpace(lastLoadError); text != "" {
		errors["bundle"] = text
	}
	return errors
}

func buildHelperBackendErrors(lastLoadError string) map[string]string {
	errors := map[string]string{
		"cpu": "embedding helper backend active",
	}
	if text := strings.TrimSpace(lastLoadError); text != "" {
		errors["bundle"] = text
	}
	return errors
}

func buildNativeBackendErrors(lastLoadError string, libraryPath string) map[string]string {
	errors := map[string]string{
		"cpu": "native ncnn embedding backend active",
	}
	if text := strings.TrimSpace(libraryPath); text != "" {
		errors["library"] = text
	}
	if text := strings.TrimSpace(lastLoadError); text != "" {
		errors["bundle"] = text
	}
	return errors
}

type embeddingHelperSpec struct {
	pythonPath string
	scriptPath string
}

type embeddingHelperRequest struct {
	Text          string    `json:"text,omitempty"`
	InputIDs      []int     `json:"input_ids,omitempty"`
	AttentionMask []float64 `json:"attention_mask,omitempty"`
}

func (h embeddingHelperSpec) deviceID() string {
	if h.pythonPath == "" || h.scriptPath == "" {
		return "cpu:stub"
	}
	return "cpu:embedding-helper"
}

func resolveEmbeddingHelperSpec() (embeddingHelperSpec, bool) {
	if !envEnabled(liveGetenv(envEnableEmbeddingHelper)) {
		return embeddingHelperSpec{}, false
	}
	pythonPath := configuredEmbeddingHelperPythonPath()
	scriptPath := configuredEmbeddingHelperScriptPath()
	if pythonPath == "" || scriptPath == "" {
		return embeddingHelperSpec{}, false
	}
	return embeddingHelperSpec{
		pythonPath: pythonPath,
		scriptPath: scriptPath,
	}, true
}

func envEnabled(raw string) bool {
	switch strings.ToLower(strings.TrimSpace(raw)) {
	case "1", "true", "yes", "on", "enabled":
		return true
	default:
		return false
	}
}

func configuredEmbeddingHelperPythonPath() string {
	if path := strings.TrimSpace(liveGetenv(envEmbeddingHelperPython)); path != "" {
		if info, err := os.Stat(path); err == nil && !info.IsDir() {
			return path
		}
		return ""
	}
	for _, candidate := range embeddingHelperPythonCandidates() {
		if info, err := os.Stat(candidate); err == nil && !info.IsDir() {
			return candidate
		}
	}
	return ""
}

func embeddingHelperPythonCandidates() []string {
	candidates := make([]string, 0, 4)
	if homeDir, err := os.UserHomeDir(); err == nil {
		candidates = append(candidates, filepath.Join(homeDir, ".cache", "zimaos-mds-model-cache", "photo-search", "public-helper-venv", "bin", "python"))
		candidates = append(candidates, filepath.Join(homeDir, ".cache", "zimaos-mds-model-cache", "photo-search", "public-helper-venv", "bin", "python3"))
	}
	if path, err := exec.LookPath("python3"); err == nil {
		candidates = append(candidates, path)
	}
	if path, err := exec.LookPath("python"); err == nil {
		candidates = append(candidates, path)
	}
	return candidates
}

func configuredEmbeddingHelperScriptPath() string {
	if override := strings.TrimSpace(liveGetenv(envEmbeddingHelperScript)); override != "" {
		candidate := filepath.Clean(override)
		if info, err := os.Stat(candidate); err == nil && !info.IsDir() {
			return candidate
		}
		return ""
	}
	if wd, err := os.Getwd(); err == nil {
		if path, ok := findEmbeddingHelperScriptFromDir(wd); ok {
			return path
		}
	}
	if executablePath, err := os.Executable(); err == nil {
		if path, ok := findEmbeddingHelperScriptFromDir(filepath.Dir(executablePath)); ok {
			return path
		}
	}
	return ""
}

func liveGetenv(name string) string {
	name = strings.TrimSpace(name)
	if name == "" {
		return ""
	}
	cname := C.CString(name)
	defer C.free(unsafe.Pointer(cname))
	value := C.getenv(cname)
	if value == nil {
		return ""
	}
	return C.GoString(value)
}

func findEmbeddingHelperScriptFromDir(start string) (string, bool) {
	dir := filepath.Clean(start)
	for {
		candidate := filepath.Join(dir, "scripts", "ncnn_embedding_helper.py")
		if info, err := os.Stat(candidate); err == nil && !info.IsDir() {
			return candidate, true
		}
		parent := filepath.Dir(dir)
		if parent == dir {
			return "", false
		}
		dir = parent
	}
}

func tryEmbeddingHelperLoad(helper embeddingHelperSpec, bundleDir string, backendRequested []string) (loadResultPayload, error) {
	if err := probeEmbeddingHelperBundle(helper, bundleDir); err != nil {
		return loadResultPayload{}, err
	}
	degradedToCPU := len(backendRequested) > 0 && !onlyCPUBackends(backendRequested)
	degradeReason := ""
	if degradedToCPU {
		degradeReason = "ncnn_embedding_helper_cpu_only"
	}
	return loadResultPayload{
		loadResult: loadResult{
			BackendEffective: "cpu",
			DeviceEffective:  helper.deviceID(),
			DegradedToCPU:    degradedToCPU,
			DegradeReason:    degradeReason,
		},
	}, nil
}

func tryEmbeddingHelperInfer(state *wrapperRuntimeState, helper embeddingHelperSpec, parsed inferRequest) (wrapperInferResult, bool) {
	modelClass := strings.TrimSpace(parsed.ModelClass)
	if !strings.EqualFold(modelClassBase(modelClass), modelClassEmbedding) {
		return wrapperInferResult{}, false
	}
	if !strings.EqualFold(strings.TrimSpace(parsed.Task), "embedding") {
		return wrapperInferResult{
			Output: map[string]interface{}{
				"ok":    false,
				"error": "unsupported_task",
				"task":  strings.TrimSpace(parsed.Task),
			},
		}, true
	}
	if state == nil {
		return wrapperInferResult{}, false
	}
	bundleDir, bundleID, ok := state.loadedBundle(modelClass)
	if !ok {
		return wrapperInferResult{
			Output: map[string]interface{}{
				"ok":             false,
				"error":          "ncnn_model_class_not_loaded",
				"degrade_reason": "ncnn_embedding_helper_not_loaded",
				"model_class":    modelClass,
				"task":           strings.TrimSpace(parsed.Task),
				"loaded":         false,
			},
		}, true
	}
	text, _ := parsed.Input["text"].(string)
	helperRequest := embeddingHelperRequest{Text: text}
	if inputIDs, attentionMask, provided, err := extractPretokenizedEmbeddingInputs(parsed.Input); err != nil {
		return wrapperInferResult{
			Output: map[string]interface{}{
				"ok":             false,
				"error":          err.Error(),
				"degrade_reason": "ncnn_embedding_invalid_pretokenized_input",
				"model_class":    modelClass,
				"bundle_id":      bundleID,
				"task":           strings.TrimSpace(parsed.Task),
				"loaded":         true,
			},
		}, true
	} else if provided {
		helperRequest.Text = ""
		helperRequest.InputIDs = inputIDs
		helperRequest.AttentionMask = attentionMask
	} else if tokenizedInputs, tokenized, err := embedtokenizer.TokenizeBundleText(bundleDir, text); err != nil {
		return wrapperInferResult{
			Output: map[string]interface{}{
				"ok":             false,
				"error":          err.Error(),
				"degrade_reason": "ncnn_embedding_go_tokenization_failed",
				"model_class":    modelClass,
				"bundle_id":      bundleID,
				"task":           strings.TrimSpace(parsed.Task),
				"loaded":         true,
			},
		}, true
	} else if tokenized {
		helperRequest.Text = ""
		helperRequest.InputIDs = tokenizedInputs.InputIDs
		helperRequest.AttentionMask = tokenizedInputs.AttentionMask
	}
	embedding, err := runEmbeddingHelper(helper, bundleDir, helperRequest)
	if err != nil {
		return wrapperInferResult{
			Output: map[string]interface{}{
				"ok":             false,
				"error":          err.Error(),
				"degrade_reason": "ncnn_embedding_helper_failed",
				"model_class":    modelClass,
				"bundle_id":      bundleID,
				"task":           strings.TrimSpace(parsed.Task),
				"loaded":         true,
			},
		}, true
	}
	return wrapperInferResult{
		Output: map[string]interface{}{
			"embedding":   embedding,
			"dimension":   len(embedding),
			"bundle_id":   bundleID,
			"model_class": modelClass,
			"ok":          true,
		},
	}, true
}

func extractPretokenizedEmbeddingInputs(input map[string]interface{}) ([]int, []float64, bool, error) {
	inputIDs, hasInputIDs, err := parsePretokenizedInputIDs(input["input_ids"])
	if err != nil {
		return nil, nil, false, err
	}
	attentionMask, hasAttentionMask, err := parsePretokenizedAttentionMask(input["attention_mask"])
	if err != nil {
		return nil, nil, false, err
	}
	if !hasInputIDs && !hasAttentionMask {
		return nil, nil, false, nil
	}
	if !hasInputIDs || !hasAttentionMask {
		return nil, nil, false, fmt.Errorf("input_ids and attention_mask must both be provided")
	}
	if len(inputIDs) == 0 || len(attentionMask) == 0 {
		return nil, nil, false, fmt.Errorf("input_ids and attention_mask must be non-empty")
	}
	if len(inputIDs) != len(attentionMask) {
		return nil, nil, false, fmt.Errorf("input_ids and attention_mask must have identical length")
	}
	return inputIDs, attentionMask, true, nil
}

func parsePretokenizedInputIDs(raw interface{}) ([]int, bool, error) {
	switch typed := raw.(type) {
	case nil:
		return nil, false, nil
	case []int:
		return append([]int(nil), typed...), true, nil
	case []float64:
		result := make([]int, 0, len(typed))
		for _, value := range typed {
			id, err := jsonNumberToInt(value)
			if err != nil {
				return nil, false, fmt.Errorf("input_ids: %w", err)
			}
			result = append(result, id)
		}
		return result, true, nil
	case []interface{}:
		result := make([]int, 0, len(typed))
		for _, value := range typed {
			id, err := genericNumberToInt(value)
			if err != nil {
				return nil, false, fmt.Errorf("input_ids: %w", err)
			}
			result = append(result, id)
		}
		return result, true, nil
	default:
		return nil, false, fmt.Errorf("input_ids must be an array, got %T", raw)
	}
}

func parsePretokenizedAttentionMask(raw interface{}) ([]float64, bool, error) {
	switch typed := raw.(type) {
	case nil:
		return nil, false, nil
	case []float64:
		return append([]float64(nil), typed...), true, nil
	case []int:
		result := make([]float64, 0, len(typed))
		for _, value := range typed {
			result = append(result, float64(value))
		}
		return result, true, nil
	case []interface{}:
		result := make([]float64, 0, len(typed))
		for _, value := range typed {
			number, err := genericNumberToFloat64(value)
			if err != nil {
				return nil, false, fmt.Errorf("attention_mask: %w", err)
			}
			result = append(result, number)
		}
		return result, true, nil
	default:
		return nil, false, fmt.Errorf("attention_mask must be an array, got %T", raw)
	}
}

func genericNumberToInt(value interface{}) (int, error) {
	switch typed := value.(type) {
	case int:
		return typed, nil
	case int32:
		return int(typed), nil
	case int64:
		return int(typed), nil
	case float64:
		return jsonNumberToInt(typed)
	default:
		return 0, fmt.Errorf("expected integer number, got %T", value)
	}
}

func genericNumberToFloat64(value interface{}) (float64, error) {
	switch typed := value.(type) {
	case int:
		return float64(typed), nil
	case int32:
		return float64(typed), nil
	case int64:
		return float64(typed), nil
	case float64:
		return typed, nil
	default:
		return 0, fmt.Errorf("expected numeric value, got %T", value)
	}
}

func jsonNumberToInt(value float64) (int, error) {
	if math.Trunc(value) != value {
		return 0, fmt.Errorf("expected integer-valued float, got %v", value)
	}
	return int(value), nil
}

func probeEmbeddingHelperBundle(helper embeddingHelperSpec, bundleDir string) error {
	output, err := runEmbeddingHelperCommand(helper, nil, "--bundle-dir", bundleDir, "--probe")
	if err != nil {
		return err
	}
	if len(output) == 0 {
		return fmt.Errorf("embedding helper probe returned empty output")
	}
	return nil
}

func runEmbeddingHelper(helper embeddingHelperSpec, bundleDir string, request embeddingHelperRequest) ([]float64, error) {
	payload, err := json.Marshal(request)
	if err != nil {
		return nil, err
	}
	output, err := runEmbeddingHelperCommand(helper, payload, "--bundle-dir", bundleDir, "--stdin-json")
	if err != nil {
		return nil, err
	}
	var response struct {
		Embedding []float64 `json:"embedding"`
		Error     string    `json:"error"`
	}
	if err := json.Unmarshal(output, &response); err != nil {
		return nil, fmt.Errorf("decode embedding helper response: %w", err)
	}
	if text := strings.TrimSpace(response.Error); text != "" {
		return nil, fmt.Errorf("%s", text)
	}
	if len(response.Embedding) == 0 {
		return nil, fmt.Errorf("embedding helper returned empty embedding")
	}
	return append([]float64(nil), response.Embedding...), nil
}

func runEmbeddingHelperCommand(helper embeddingHelperSpec, stdin []byte, args ...string) ([]byte, error) {
	cmdArgs := append([]string{helper.scriptPath}, args...)
	cmd := exec.Command(helper.pythonPath, cmdArgs...)
	if len(stdin) > 0 {
		cmd.Stdin = strings.NewReader(string(stdin))
	}
	output, err := cmd.CombinedOutput()
	if err != nil {
		text := strings.TrimSpace(string(output))
		if text == "" {
			return nil, fmt.Errorf("embedding helper failed: %w", err)
		}
		return nil, fmt.Errorf("embedding helper failed: %w: %s", err, text)
	}
	return output, nil
}
