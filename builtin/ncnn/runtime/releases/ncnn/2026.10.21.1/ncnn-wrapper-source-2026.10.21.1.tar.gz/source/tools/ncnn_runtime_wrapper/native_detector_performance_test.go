package main

import (
	"os"
	"path/filepath"
	"testing"
)

func nativeDetectorPreparationSource(t testing.TB) string {
	t.Helper()
	body, _ := nativePerformanceJPEG(t, 768, 512)
	path := filepath.Join(t.TempDir(), "source.jpg")
	if err := os.WriteFile(path, body, 0o600); err != nil {
		t.Fatal(err)
	}
	return path
}

func BenchmarkNativeDetectorPreparation(b *testing.B) {
	path := nativeDetectorPreparationSource(b)
	profile := nativeVisionProfile{kind: nativeVisionProfileYOLOv8Detect, targetWidth: 640, targetHeight: 640}
	input := map[string]interface{}{"image": path}
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		prepared, err := prepareNativeVisionImageInputForTask(profile, input, "detect")
		if err != nil || len(prepared.pixels) != 640*640*3 {
			b.Fatalf("prepare: %v", err)
		}
	}
}
