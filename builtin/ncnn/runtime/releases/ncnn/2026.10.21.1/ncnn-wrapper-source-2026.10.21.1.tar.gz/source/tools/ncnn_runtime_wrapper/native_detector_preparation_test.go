package main

import (
	"bytes"
	"image"
	"image/color"
	"image/png"
	"math"
	"os"
	"path/filepath"
	"testing"

	"github.com/disintegration/imaging"
)

func TestNativePaddedRGBPixelsUsesOnlyOutputAllocation(t *testing.T) {
	src := nativePerformanceImage(61, 43)
	allocs := testing.AllocsPerRun(10, func() {
		if len(nativeImageRGBPixelsPadded(src, 64, 64, image.Pt(1, 10), 114)) != 64*64*3 {
			t.Fatal("invalid RGB tensor")
		}
	})
	if allocs != 1 {
		t.Fatalf("padded RGB allocs=%v, want only the output allocation", allocs)
	}
}

func TestNativePaddedRGBPixelsMatchesOriginalCanvas(t *testing.T) {
	parent := nativePerformanceImage(67, 49)
	sources := []*image.NRGBA{parent, parent.SubImage(image.Rect(3, 5, 62, 44)).(*image.NRGBA)}
	negative := image.NewNRGBA(image.Rect(-7, -9, 32, 21))
	copy(negative.Pix, parent.Pix)
	sources = append(sources, negative)
	for _, src := range sources {
		before := append([]byte(nil), src.Pix...)
		for _, size := range []image.Point{{64, 64}, {63, 41}, {1, 1}} {
			for _, pos := range []image.Point{{0, 0}, {1, 10}, {-9, -7}, {50, 37}, {100, 100}} {
				canvas := imaging.New(size.X, size.Y, color.NRGBA{R: 114, G: 114, B: 114, A: 255})
				want := nativeVisionRGBPixels(imaging.Paste(canvas, src, pos))
				got := nativeImageRGBPixelsPadded(src, size.X, size.Y, pos, 114)
				if !bytes.Equal(got, want) {
					t.Fatalf("bounds=%v size=%v pos=%v changed tensor", src.Bounds(), size, pos)
				}
				got[0] ^= 0xff
				if !bytes.Equal(src.Pix, before) {
					t.Fatal("packing modified source pixels")
				}
			}
		}
	}
}

func TestNativeDetectorPreparationMatchesOriginalPixelsAndGeometry(t *testing.T) {
	for _, size := range []image.Point{{71, 45}, {45, 71}, {64, 64}, {1, 1}} {
		src := nativePerformanceImage(size.X, size.Y)
		path := filepath.Join(t.TempDir(), "source.png")
		f, err := os.Create(path)
		if err != nil {
			t.Fatal(err)
		}
		err = png.Encode(f, src)
		closeErr := f.Close()
		if err != nil || closeErr != nil {
			t.Fatalf("write PNG: %v %v", err, closeErr)
		}
		decoded, err := imaging.Open(path)
		if err != nil {
			t.Fatal(err)
		}
		for _, kind := range []nativeVisionProfileKind{nativeVisionProfileYOLOv8Detect, nativeVisionProfileSCRFDFace} {
			profile := nativeVisionProfile{kind: kind, targetWidth: 63, targetHeight: 65}
			got, err := prepareNativeVisionImageInputForTask(profile, map[string]interface{}{"image": path}, "detect")
			if err != nil {
				t.Fatal(err)
			}
			scale := math.Min(63/float64(size.X), 65/float64(size.Y))
			w, h := max(1, int(math.Round(float64(size.X)*scale))), max(1, int(math.Round(float64(size.Y)*scale)))
			pad := image.Pt((63-w)/2, (65-h)/2)
			want := imaging.Paste(imaging.New(63, 65, color.NRGBA{R: 114, G: 114, B: 114, A: 255}), imaging.Resize(decoded, w, h, imaging.Linear), pad)
			if !bytes.Equal(got.pixels, nativeVisionRGBPixels(want)) || got.scale != scale || got.padX != pad.X || got.padY != pad.Y || got.sourceWidth != size.X || got.sourceHeight != size.Y || got.width != 63 || got.height != 65 {
				t.Fatalf("%v %v changed detector pixels or geometry", size, kind)
			}
		}
	}
}
