package main

import (
	"bytes"
	"fmt"
	"image"
	"image/color"
	"image/png"
	"math"
	"os"
	"path/filepath"
	"runtime"
	"sync"
	"testing"

	"github.com/disintegration/imaging"
)

func nativeStreamingDetectorSource(t testing.TB, width, height int, format string) string {
	t.Helper()
	var body []byte
	if format == "jpeg" {
		body, _ = nativePerformanceJPEG(t, width, height)
	} else {
		var src image.Image = nativePerformanceImage(width, height)
		if format == "gray" {
			gray := image.NewGray(src.Bounds())
			for i := range gray.Pix {
				gray.Pix[i] = byte(i * 79)
			}
			src = gray
		}
		var encoded bytes.Buffer
		if err := png.Encode(&encoded, src); err != nil {
			t.Fatal(err)
		}
		body = encoded.Bytes()
	}
	path := filepath.Join(t.TempDir(), "source")
	if err := os.WriteFile(path, body, 0o600); err != nil {
		t.Fatal(err)
	}
	return path
}

func referenceNativeStreamingDetector(src image.Image, target image.Point) ([]byte, float64, image.Point) {
	bounds := src.Bounds()
	scale := math.Min(float64(target.X)/float64(bounds.Dx()), float64(target.Y)/float64(bounds.Dy()))
	w, h := max(1, int(math.Round(float64(bounds.Dx())*scale))), max(1, int(math.Round(float64(bounds.Dy())*scale)))
	pad := image.Pt((target.X-w)/2, (target.Y-h)/2)
	canvas := imaging.Paste(imaging.New(target.X, target.Y, color.NRGBA{114, 114, 114, 255}), imaging.Resize(src, w, h, imaging.Linear), pad)
	pixels := make([]byte, target.X*target.Y*3)
	for y := 0; y < target.Y; y++ {
		for x := 0; x < target.X; x++ {
			i, j := y*canvas.Stride+x*4, (y*target.X+x)*3
			pixels[j], pixels[j+1], pixels[j+2] = canvas.Pix[i], canvas.Pix[i+1], canvas.Pix[i+2]
		}
	}
	return pixels, scale, pad
}

func TestNativeDetectorStreamingAllocationBudget(t *testing.T) {
	previous := runtime.GOMAXPROCS(1)
	defer runtime.GOMAXPROCS(previous)
	for _, tc := range []struct {
		format        string
		width, height int
	}{{"jpeg", 768, 512}, {"png", 768, 512}, {"jpeg", 1536, 1024}} {
		path := nativeStreamingDetectorSource(t, tc.width, tc.height, tc.format)
		decoded, err := imaging.Open(path)
		if err != nil {
			t.Fatal(err)
		}
		var decodedBytes int
		switch src := decoded.(type) {
		case *image.NRGBA:
			decodedBytes = len(src.Pix)
		case *image.YCbCr:
			decodedBytes = len(src.Y) + len(src.Cb) + len(src.Cr)
		default:
			t.Fatalf("unexpected decoded type %T", decoded)
		}
		for _, kind := range []nativeVisionProfileKind{nativeVisionProfileYOLOv8Detect, nativeVisionProfileSCRFDFace} {
			t.Run(fmt.Sprintf("%s/%dx%d/%s", tc.format, tc.width, tc.height, kind), func(t *testing.T) {
				profile := nativeVisionProfile{kind: kind, targetWidth: 640, targetHeight: 640}
				runtime.GC()
				var before, after runtime.MemStats
				runtime.ReadMemStats(&before)
				for i := 0; i < 3; i++ {
					got, err := prepareNativeVisionImageInputForTask(profile, map[string]interface{}{"image": path}, "detect")
					if err != nil || len(got.pixels) != 640*640*3 {
						t.Fatalf("invalid preparation: %v", err)
					}
				}
				runtime.ReadMemStats(&after)
				budget := uint64(decodedBytes + 640*640*3 + 512*1024)
				if got := (after.TotalAlloc - before.TotalAlloc) / 3; got > budget {
					t.Fatalf("detector allocated %d bytes/image, budget %d; full resize canvases remain", got, budget)
				}
			})
		}
	}
}

func TestNativeDetectorStreamingInputParity(t *testing.T) {
	previous := runtime.GOMAXPROCS(1)
	defer runtime.GOMAXPROCS(previous)
	for _, procs := range []int{1, 4} {
		runtime.GOMAXPROCS(procs)
		for _, format := range []string{"jpeg", "png", "gray"} {
			for _, size := range []image.Point{{71, 45}, {45, 71}, {1, 17}, {64, 64}} {
				path := nativeStreamingDetectorSource(t, size.X, size.Y, format)
				src, err := imaging.Open(path)
				if err != nil {
					t.Fatal(err)
				}
				for _, target := range []image.Point{{63, 65}, {64, 64}, {71, 45}, {128, 96}, {1, 1}} {
					want, scale, pad := referenceNativeStreamingDetector(src, target)
					for _, kind := range []nativeVisionProfileKind{nativeVisionProfileYOLOv8Detect, nativeVisionProfileSCRFDFace} {
						profile := nativeVisionProfile{kind: kind, targetWidth: target.X, targetHeight: target.Y}
						got, err := prepareNativeVisionImageInputForTask(profile, map[string]interface{}{"image": path}, "detect")
						if err != nil || !bytes.Equal(got.pixels, want) || got.scale != scale || got.padX != pad.X || got.padY != pad.Y || got.width != target.X || got.height != target.Y || got.sourceWidth != size.X || got.sourceHeight != size.Y {
							t.Fatalf("cpu=%d %s %v→%v %s: tensor/geometry differs: %v", procs, format, size, target, kind, err)
						}
						before := imaging.Clone(got.sourceImage)
						got.pixels[0] ^= 255
						if !bytes.Equal(imaging.Clone(got.sourceImage).Pix, before.Pix) {
							t.Fatal("tensor aliases decoded source")
						}
					}
				}
			}
		}
	}
}

// The reused row reader must match imaging's scanner even without a border.
func TestNativeDetectorStreamingSourceParity(t *testing.T) {
	previous := runtime.GOMAXPROCS(1)
	defer runtime.GOMAXPROCS(previous)
	for _, procs := range []int{1, 4} {
		runtime.GOMAXPROCS(procs)
		for _, src := range nativePixelTestSources() {
			linear := rapidOCRLinearSource{width: src.Bounds().Dx(), height: src.Bounds().Dy()}
			switch src := src.(type) {
			case *image.NRGBA:
				linear.nrgba = src
			case *image.YCbCr:
				linear.ycbcr = src
			default:
				continue
			}
			before := imaging.Clone(src)
			for _, target := range []image.Point{{1, 1}, {7, 5}, {63, 65}, {3, 69}} {
				want := imaging.Resize(src, target.X, target.Y, imaging.Linear)
				got := rapidOCRResizeLinearSource(linear, target.X, target.Y)
				if got.Rect != want.Rect || !bytes.Equal(got.Pix, want.Pix) || !bytes.Equal(imaging.Clone(src).Pix, before.Pix) {
					t.Fatalf("cpu=%d %T bounds=%v target=%v: row conversion differs", procs, src, src.Bounds(), target)
				}
			}
		}
	}
}

func TestNativeDetectorStreamingConcurrentOwnership(t *testing.T) {
	path := nativeStreamingDetectorSource(t, 193, 129, "png")
	src, err := imaging.Open(path)
	if err != nil {
		t.Fatal(err)
	}
	want, _, _ := referenceNativeStreamingDetector(src, image.Pt(128, 128))
	var wg sync.WaitGroup
	for i := 0; i < 8; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			profile := nativeVisionProfile{kind: nativeVisionProfileYOLOv8Detect, targetWidth: 128, targetHeight: 128}
			got, err := prepareNativeVisionImageInputForTask(profile, map[string]interface{}{"image": path}, "detect")
			if err != nil || !bytes.Equal(got.pixels, want) {
				t.Error("concurrent detector tensor differs", err)
				return
			}
			got.pixels[0] ^= 255
		}()
	}
	wg.Wait()
}

func BenchmarkNativeDetectorStreamingPreparation(b *testing.B) {
	for _, tc := range []struct {
		name, format  string
		width, height int
	}{{"jpeg", "jpeg", 768, 512}, {"png", "png", 768, 512}, {"large-jpeg", "jpeg", 1536, 1024}, {"aligned-jpeg-control", "jpeg", 640, 640}, {"single-axis-jpeg-control", "jpeg", 1, 512}, {"gray-control", "gray", 768, 512}} {
		path := nativeStreamingDetectorSource(b, tc.width, tc.height, tc.format)
		b.Run(tc.name, func(b *testing.B) {
			profile := nativeVisionProfile{kind: nativeVisionProfileYOLOv8Detect, targetWidth: 640, targetHeight: 640}
			b.ReportAllocs()
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				got, err := prepareNativeVisionImageInputForTask(profile, map[string]interface{}{"image": path}, "detect")
				if err != nil || len(got.pixels) != 640*640*3 {
					b.Fatal("invalid preparation", err)
				}
			}
		})
	}
}
