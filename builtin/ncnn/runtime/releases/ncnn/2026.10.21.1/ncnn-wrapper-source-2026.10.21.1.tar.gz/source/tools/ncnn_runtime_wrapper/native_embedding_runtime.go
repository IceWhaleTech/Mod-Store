package main

import (
	"encoding/json"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"unsafe"

	"github.com/IceWhaleTech/zimaos-photos/internal/embedtokenizer"
	"github.com/ebitengine/purego"
)

const envNativeLibraryPath = "ZIMAOS_NCNN_NATIVE_LIBRARY_PATH"

type nativeEmbeddingSpec struct {
	backend *nativeEmbeddingRuntime
}

func (s nativeEmbeddingSpec) deviceID() string {
	if s.backend == nil {
		return "cpu:stub"
	}
	return "cpu:ncnn-native"
}

func (s nativeEmbeddingSpec) libraryPath() string {
	if s.backend == nil || s.backend.base == nil {
		return ""
	}
	return s.backend.base.libraryPath
}

type nativeEmbeddingBackend struct {
	libraryPath string
	bindings    nativeNCNNBindings
}

type nativeEmbeddingRuntime struct {
	base *nativeEmbeddingBackend

	mu     sync.Mutex
	loaded map[string]*nativeEmbeddingModel
}

type nativeEmbeddingModel struct {
	lifecycleMu       sync.RWMutex
	net               uintptr
	splitHeadNet      uintptr
	faceEmbeddingNet  uintptr
	profile           nativeEmbeddingProfile
	visionProfile     nativeVisionProfile
	ocrProfile        rapidOCRBundleLayout
	ocrKeys           []string
	threadLimit       int
	useFP16Packed     bool
	useFP16Storage    bool
	useFP16Arithmetic bool
	useINT8Packed     bool
	useINT8Storage    bool
	useINT8Arithmetic bool
	usePackingLayout  bool
	splitFeatureBlob  string
	splitHeadInput    string
	splitHeadOutput   string
	splitPostprocess  string
}

type nativeEmbeddingProfile string

const (
	nativeEmbeddingProfileSentencePiece   nativeEmbeddingProfile = "sentencepiece"
	nativeEmbeddingRuntimeKindSplitNCNN                          = "split_ncnn"
	nativeEmbeddingPostprocessL2Normalize                        = "l2_normalize"
)

type nativeEmbeddingBundleLayout struct {
	runtimeKind         string
	rootParamPath       string
	rootModelPath       string
	backboneParamPath   string
	backboneModelPath   string
	backboneFeatureBlob string
	headParamPath       string
	headModelPath       string
	headInputName       string
	headOutputName      string
	headPostprocess     string
}

type nativePreparedEmbeddingInputs struct {
	profile       nativeEmbeddingProfile
	inputIDs      []int
	attentionMask []float64
}

type nativeEmbeddingLoadOptions struct {
	threadLimit       int
	useFP16Packed     bool
	useFP16Storage    bool
	useFP16Arithmetic bool
	useINT8Packed     bool
	useINT8Storage    bool
	useINT8Arithmetic bool
	usePackingLayout  bool
}

var nativeLoadNetFromDir = func(backend *nativeEmbeddingBackend, bundleDir string, options nativeEmbeddingLoadOptions) (uintptr, error) {
	return backend.loadNetFromDir(bundleDir, options)
}

type nativeNCNNBindings struct {
	netCreate                  func() uintptr
	netDestroy                 func(uintptr)
	netSetOption               func(uintptr, uintptr)
	netLoadParam               func(uintptr, *byte) int32
	netLoadModel               func(uintptr, *byte) int32
	optionCreate               func() uintptr
	optionDestroy              func(uintptr)
	optionSetNumThreads        func(uintptr, int32)
	optionSetUseFP16Packed     func(uintptr, int32)
	optionSetUseFP16Storage    func(uintptr, int32)
	optionSetUseFP16Arithmetic func(uintptr, int32)
	optionSetUseINT8Packed     func(uintptr, int32)
	optionSetUseINT8Storage    func(uintptr, int32)
	optionSetUseINT8Arithmetic func(uintptr, int32)
	optionSetUsePackingLayout  func(uintptr, int32)
	extractorCreate            func(uintptr) uintptr
	extractorDestroy           func(uintptr)
	extractorSetOption         func(uintptr, uintptr)
	extractorInput             func(uintptr, *byte, uintptr) int32
	extractorExtract           func(uintptr, *byte, *uintptr) int32
	matFromPixels              func(*byte, int32, int32, int32, int32, uintptr) uintptr
	matCreateExternal1DElem    func(int32, unsafe.Pointer, uintptr, int32, uintptr) uintptr
	matClone                   func(uintptr, uintptr) uintptr
	matDestroy                 func(uintptr)
	matGetDims                 func(uintptr) int32
	matGetW                    func(uintptr) int32
	matGetH                    func(uintptr) int32
	matGetD                    func(uintptr) int32
	matGetC                    func(uintptr) int32
	matGetData                 func(uintptr) unsafe.Pointer
	matSubstractMeanNormalize  func(uintptr, *float32, *float32)
}

var nativeEmbeddingBackendOnce sync.Once
var nativeEmbeddingBackendValue *nativeEmbeddingBackend
var nativeEmbeddingBackendErr error

func resolveNativeEmbeddingRuntime() (*nativeEmbeddingRuntime, bool) {
	backend, err := loadNativeEmbeddingBackend()
	if err != nil || backend == nil {
		return nil, false
	}
	return &nativeEmbeddingRuntime{
		base:   backend,
		loaded: make(map[string]*nativeEmbeddingModel),
	}, true
}

func resolveNativeEmbeddingSpec() (nativeEmbeddingSpec, bool) {
	runtime, ok := resolveNativeEmbeddingRuntime()
	if !ok || runtime == nil {
		return nativeEmbeddingSpec{}, false
	}
	return nativeEmbeddingSpec{backend: runtime}, true
}

func loadNativeEmbeddingBackend() (*nativeEmbeddingBackend, error) {
	nativeEmbeddingBackendOnce.Do(func() {
		nativeEmbeddingBackendValue, nativeEmbeddingBackendErr = openNativeEmbeddingBackend()
	})
	return nativeEmbeddingBackendValue, nativeEmbeddingBackendErr
}

func nativeEmbeddingBackendError() string {
	_, err := loadNativeEmbeddingBackend()
	if err == nil {
		return ""
	}
	return err.Error()
}

func openNativeEmbeddingBackend() (*nativeEmbeddingBackend, error) {
	candidates := nativeNCNNLibraryCandidates()
	var errors []string
	for _, candidate := range candidates {
		candidate = strings.TrimSpace(candidate)
		if candidate == "" {
			continue
		}
		preloadNativeNCNNSupportLibraries(filepath.Dir(candidate))
		handle, err := purego.Dlopen(candidate, purego.RTLD_NOW|purego.RTLD_GLOBAL)
		if err != nil {
			errors = append(errors, fmt.Sprintf("%s: %v", candidate, err))
			continue
		}
		bindings, err := registerNativeNCNNBindings(handle)
		if err != nil {
			errors = append(errors, fmt.Sprintf("%s: %v", candidate, err))
			continue
		}
		return &nativeEmbeddingBackend{
			libraryPath: candidate,
			bindings:    bindings,
		}, nil
	}
	if len(errors) > 0 {
		return nil, fmt.Errorf("native libncnn unavailable (%s)", strings.Join(errors, "; "))
	}
	return nil, fmt.Errorf("native libncnn not found")
}

func preloadNativeNCNNSupportLibraries(nativeDir string) {
	for _, libraryName := range []string{"libgomp.so.1", "libmvec.so.1", "libm.so.6"} {
		for _, candidate := range nativeSupportLibraryCandidates(nativeDir, libraryName) {
			if info, err := os.Stat(candidate); err != nil || info.IsDir() {
				continue
			}
			_, _ = purego.Dlopen(candidate, purego.RTLD_NOW|purego.RTLD_GLOBAL)
			break
		}
	}
}

func nativeSupportLibraryCandidates(nativeDir string, libraryName string) []string {
	libraryName = strings.TrimSpace(libraryName)
	if libraryName == "" {
		return nil
	}
	candidates := []string{
		filepath.Join(strings.TrimSpace(nativeDir), libraryName),
		filepath.Join("/usr/lib", libraryName),
		filepath.Join("/lib", libraryName),
		filepath.Join("/usr/lib64", libraryName),
		filepath.Join("/lib64", libraryName),
	}
	return uniqueNativeSupportLibraryCandidates(candidates)
}

func uniqueNativeSupportLibraryCandidates(candidates []string) []string {
	seen := make(map[string]struct{}, len(candidates))
	result := make([]string, 0, len(candidates))
	for _, candidate := range candidates {
		candidate = strings.TrimSpace(candidate)
		if candidate == "" {
			continue
		}
		if _, ok := seen[candidate]; ok {
			continue
		}
		seen[candidate] = struct{}{}
		result = append(result, candidate)
	}
	return result
}

func nativeNCNNLibraryCandidates() []string {
	libraryName := "libncnn.so"
	switch runtime.GOOS {
	case "darwin":
		libraryName = "libncnn.dylib"
	case "windows":
		libraryName = "ncnn.dll"
	}

	seen := make(map[string]struct{}, 8)
	candidates := make([]string, 0, 8)
	appendCandidate := func(candidate string) {
		candidate = strings.TrimSpace(candidate)
		if candidate == "" {
			return
		}
		if _, ok := seen[candidate]; ok {
			return
		}
		seen[candidate] = struct{}{}
		candidates = append(candidates, candidate)
	}

	appendCandidate(liveGetenv(envNativeLibraryPath))
	appendCandidate(os.Getenv(envNativeLibraryPath))
	appendCandidate(procSelfEnvValue(envNativeLibraryPath))
	appendCandidate(libraryName)
	switch runtime.GOOS {
	case "darwin":
		appendCandidate("/opt/homebrew/lib/" + libraryName)
		appendCandidate("/usr/local/lib/" + libraryName)
	default:
		appendCandidate("/usr/local/lib/" + libraryName)
		appendCandidate("/usr/lib/" + libraryName)
	}
	return candidates
}

func procSelfEnvValue(name string) string {
	name = strings.TrimSpace(name)
	if name == "" || runtime.GOOS != "linux" {
		return ""
	}
	data, err := os.ReadFile("/proc/self/environ")
	if err != nil {
		return ""
	}
	prefix := name + "="
	for _, entry := range strings.Split(string(data), "\x00") {
		if strings.HasPrefix(entry, prefix) {
			return strings.TrimSpace(strings.TrimPrefix(entry, prefix))
		}
	}
	return ""
}

func registerNativeNCNNBindings(handle uintptr) (nativeNCNNBindings, error) {
	bindings := nativeNCNNBindings{}
	for _, item := range []struct {
		symbol string
		target interface{}
	}{
		{"ncnn_net_create", &bindings.netCreate},
		{"ncnn_net_destroy", &bindings.netDestroy},
		{"ncnn_net_set_option", &bindings.netSetOption},
		{"ncnn_net_load_param", &bindings.netLoadParam},
		{"ncnn_net_load_model", &bindings.netLoadModel},
		{"ncnn_option_create", &bindings.optionCreate},
		{"ncnn_option_destroy", &bindings.optionDestroy},
		{"ncnn_option_set_num_threads", &bindings.optionSetNumThreads},
		{"ncnn_option_set_use_fp16_packed", &bindings.optionSetUseFP16Packed},
		{"ncnn_option_set_use_fp16_storage", &bindings.optionSetUseFP16Storage},
		{"ncnn_option_set_use_fp16_arithmetic", &bindings.optionSetUseFP16Arithmetic},
		{"ncnn_option_set_use_int8_packed", &bindings.optionSetUseINT8Packed},
		{"ncnn_option_set_use_int8_storage", &bindings.optionSetUseINT8Storage},
		{"ncnn_option_set_use_int8_arithmetic", &bindings.optionSetUseINT8Arithmetic},
		{"ncnn_option_set_use_packing_layout", &bindings.optionSetUsePackingLayout},
		{"ncnn_extractor_create", &bindings.extractorCreate},
		{"ncnn_extractor_destroy", &bindings.extractorDestroy},
		{"ncnn_extractor_set_option", &bindings.extractorSetOption},
		{"ncnn_extractor_input", &bindings.extractorInput},
		{"ncnn_extractor_extract", &bindings.extractorExtract},
		{"ncnn_mat_from_pixels", &bindings.matFromPixels},
		{"ncnn_mat_create_external_1d_elem", &bindings.matCreateExternal1DElem},
		{"ncnn_mat_clone", &bindings.matClone},
		{"ncnn_mat_destroy", &bindings.matDestroy},
		{"ncnn_mat_get_dims", &bindings.matGetDims},
		{"ncnn_mat_get_w", &bindings.matGetW},
		{"ncnn_mat_get_h", &bindings.matGetH},
		{"ncnn_mat_get_d", &bindings.matGetD},
		{"ncnn_mat_get_c", &bindings.matGetC},
		{"ncnn_mat_get_data", &bindings.matGetData},
		{"ncnn_mat_substract_mean_normalize", &bindings.matSubstractMeanNormalize},
	} {
		if err := registerNativeSymbol(handle, item.symbol, item.target); err != nil {
			return nativeNCNNBindings{}, err
		}
	}
	return bindings, nil
}

func registerNativeSymbol(handle uintptr, symbol string, target interface{}) (err error) {
	defer func() {
		if rec := recover(); rec != nil {
			err = fmt.Errorf("native ncnn symbol %s load failed: %v", symbol, rec)
		}
	}()
	purego.RegisterLibFunc(target, handle, symbol)
	return nil
}

func tryNativeEmbeddingLoad(native nativeEmbeddingSpec, modelClass, bundleDir string, req loadRequest, backendRequested []string) (loadResultPayload, error) {
	if native.backend == nil {
		return loadResultPayload{}, fmt.Errorf("native embedding backend unavailable")
	}
	if !strings.EqualFold(modelClassBase(modelClass), modelClassEmbedding) {
		return loadResultPayload{}, fmt.Errorf("unsupported native embedding model class %s", strings.TrimSpace(modelClass))
	}
	if _, ok, err := embedtokenizer.DetectBundleTextProfile(bundleDir); err != nil {
		return loadResultPayload{}, err
	} else if !ok {
		return loadResultPayload{}, fmt.Errorf("unsupported native embedding bundle")
	}
	options := resolveNativeEmbeddingLoadOptions(mergeBundleLoadMetadataForNativeRuntime(bundleDir, req.Metadata), req.ThreadLimit)
	if err := native.backend.load(modelClass, bundleDir, options); err != nil {
		return loadResultPayload{}, err
	}
	degradedToCPU := len(backendRequested) > 0 && !onlyCPUBackends(backendRequested)
	degradeReason := ""
	if degradedToCPU {
		degradeReason = "ncnn_native_embedding_cpu_only"
	}
	return loadResultPayload{
		loadResult: loadResult{
			BackendEffective: "cpu",
			DeviceEffective:  native.deviceID(),
			DegradedToCPU:    degradedToCPU,
			DegradeReason:    degradeReason,
		},
	}, nil
}

func tryNativeEmbeddingInfer(state *wrapperRuntimeState, native nativeEmbeddingSpec, parsed inferRequest) (wrapperInferResult, bool) {
	modelClass := strings.TrimSpace(parsed.ModelClass)
	if !strings.EqualFold(modelClassBase(modelClass), modelClassEmbedding) || native.backend == nil {
		return wrapperInferResult{}, false
	}
	if !strings.EqualFold(strings.TrimSpace(parsed.Task), "embedding") {
		return wrapperInferResult{
			Output: map[string]interface{}{
				"ok":    false,
				"error": "unsupported_task",
				"task":  strings.TrimSpace(parsed.Task),
			},
		}, true
	}
	if state == nil {
		return wrapperInferResult{}, false
	}
	bundleDir, bundleID, ok := state.loadedBundle(modelClass)
	if !ok {
		return wrapperInferResult{
			Output: map[string]interface{}{
				"ok":             false,
				"error":          "ncnn_model_class_not_loaded",
				"degrade_reason": "ncnn_native_embedding_not_loaded",
				"model_class":    modelClass,
				"task":           strings.TrimSpace(parsed.Task),
				"loaded":         false,
			},
		}, true
	}

	preparedInputs, err := prepareNativeEmbeddingInputs(bundleDir, parsed.Input)
	if err != nil {
		return wrapperInferResult{
			Output: map[string]interface{}{
				"ok":             false,
				"error":          err.Error(),
				"degrade_reason": "ncnn_embedding_invalid_pretokenized_input",
				"model_class":    modelClass,
				"bundle_id":      bundleID,
				"task":           strings.TrimSpace(parsed.Task),
				"loaded":         true,
			},
		}, true
	}
	embedding, inferErr := native.backend.infer(modelClass, preparedInputs, parsed.ThreadLimit)
	if inferErr != nil {
		return wrapperInferResult{
			Output: map[string]interface{}{
				"ok":             false,
				"error":          inferErr.Error(),
				"degrade_reason": "ncnn_native_embedding_failed",
				"model_class":    modelClass,
				"bundle_id":      bundleID,
				"task":           strings.TrimSpace(parsed.Task),
				"loaded":         true,
			},
		}, true
	}
	return wrapperInferResult{
		Output: map[string]interface{}{
			"embedding":   embedding,
			"dimension":   len(embedding),
			"bundle_id":   bundleID,
			"model_class": modelClass,
			"ok":          true,
		},
	}, true
}

func prepareNativeEmbeddingInputs(bundleDir string, input map[string]interface{}) (nativePreparedEmbeddingInputs, error) {
	profile, err := detectNativeEmbeddingProfile(bundleDir)
	if err != nil {
		return nativePreparedEmbeddingInputs{}, err
	}
	inputIDs, hasInputIDs, err := parsePretokenizedInputIDs(input["input_ids"])
	if err != nil {
		return nativePreparedEmbeddingInputs{}, err
	}
	attentionMask, hasAttentionMask, err := parsePretokenizedAttentionMask(input["attention_mask"])
	if err != nil {
		return nativePreparedEmbeddingInputs{}, err
	}
	if !hasInputIDs && !hasAttentionMask {
		text, _ := input["text"].(string)
		tokenizedInputs, tokenized, err := embedtokenizer.TokenizeBundleText(bundleDir, text)
		if err != nil {
			return nativePreparedEmbeddingInputs{}, err
		}
		if !tokenized {
			return nativePreparedEmbeddingInputs{}, fmt.Errorf("native embedding runtime requires input_ids and attention_mask")
		}
		return nativePreparedEmbeddingInputs{
			profile:       profile,
			inputIDs:      tokenizedInputs.InputIDs,
			attentionMask: tokenizedInputs.AttentionMask,
		}, nil
	}

	if !hasInputIDs || !hasAttentionMask {
		return nativePreparedEmbeddingInputs{}, fmt.Errorf("input_ids and attention_mask must both be provided")
	}
	if len(inputIDs) == 0 || len(attentionMask) == 0 {
		return nativePreparedEmbeddingInputs{}, fmt.Errorf("input_ids and attention_mask must be non-empty")
	}
	if len(inputIDs) != len(attentionMask) {
		return nativePreparedEmbeddingInputs{}, fmt.Errorf("input_ids and attention_mask must have identical length")
	}
	return nativePreparedEmbeddingInputs{
		profile:       profile,
		inputIDs:      inputIDs,
		attentionMask: attentionMask,
	}, nil
}

func detectNativeEmbeddingProfile(bundleDir string) (nativeEmbeddingProfile, error) {
	_, ok, err := embedtokenizer.DetectBundleTextProfile(bundleDir)
	if err != nil {
		return "", err
	}
	if !ok {
		return nativeEmbeddingProfileSentencePiece, nil
	}
	return nativeEmbeddingProfileSentencePiece, nil
}

func (r *nativeEmbeddingRuntime) load(modelClass, bundleDir string, options nativeEmbeddingLoadOptions) error {
	if r == nil || r.base == nil {
		return fmt.Errorf("native embedding backend unavailable")
	}
	modelClass = strings.TrimSpace(modelClass)
	if modelClass == "" {
		return fmt.Errorf("native embedding model class is required")
	}

	profile := nativeEmbeddingProfileSentencePiece
	visionProfile := nativeVisionProfile{}
	ocrProfile := rapidOCRBundleLayout{}
	var ocrKeys []string
	baseModelClass := modelClassBase(modelClass)
	modelDir := strings.TrimSpace(bundleDir)
	switch {
	case strings.EqualFold(baseModelClass, modelClassEmbedding):
		detectedProfile, err := detectNativeEmbeddingProfile(bundleDir)
		if err != nil {
			return err
		}
		profile = detectedProfile
	case strings.EqualFold(baseModelClass, modelClassVision):
		detectedProfile, ok, err := detectNativeVisionProfile(bundleDir)
		if err != nil {
			return err
		}
		if !ok {
			return fmt.Errorf("unsupported native vision bundle")
		}
		visionProfile = detectedProfile
		if strings.TrimSpace(visionProfile.detectorSubdir) != "" {
			modelDir = filepath.Join(strings.TrimSpace(bundleDir), strings.TrimSpace(visionProfile.detectorSubdir))
		}
	case strings.EqualFold(baseModelClass, modelClassOCR):
		detectedProfile, err := resolveRapidOCRBundleLayout(bundleDir)
		if err != nil {
			return err
		}
		ocrProfile = detectedProfile
		ocrKeys, err = rapidOCRReadKeys(bundleDir, detectedProfile)
		if err != nil {
			return err
		}
	default:
		return fmt.Errorf("unsupported native model class %s", modelClass)
	}
	options = nativeVisionLoadOptions(options, visionProfile)

	var bundleLayout nativeEmbeddingBundleLayout
	var net uintptr
	var splitHeadNet uintptr
	var err error
	cleanupNet := false
	cleanupSplitHeadNet := false
	var faceEmbeddingNet uintptr
	cleanupFaceEmbeddingNet := false
	defer func() {
		if cleanupFaceEmbeddingNet {
			r.base.bindings.netDestroy(faceEmbeddingNet)
		}
		if cleanupSplitHeadNet {
			r.base.bindings.netDestroy(splitHeadNet)
		}
		if cleanupNet {
			r.base.bindings.netDestroy(net)
		}
	}()

	switch {
	case strings.EqualFold(baseModelClass, modelClassEmbedding):
		bundleLayout, err = resolveNativeEmbeddingBundleLayout(bundleDir)
		if err != nil {
			return err
		}
		switch bundleLayout.runtimeKind {
		case nativeEmbeddingRuntimeKindSplitNCNN:
			net, err = r.base.loadNetFromPaths(bundleLayout.backboneParamPath, bundleLayout.backboneModelPath, options)
			if err != nil {
				return err
			}
			cleanupNet = true
			splitHeadNet, err = r.base.loadNetFromPaths(bundleLayout.headParamPath, bundleLayout.headModelPath, options)
			if err != nil {
				return err
			}
			cleanupSplitHeadNet = true
		default:
			net, err = r.base.loadNetFromPaths(bundleLayout.rootParamPath, bundleLayout.rootModelPath, options)
			if err != nil {
				return err
			}
			cleanupNet = true
		}
	case strings.EqualFold(baseModelClass, modelClassOCR):
		net, err = r.base.loadNetFromPaths(
			filepath.Join(bundleDir, filepath.FromSlash(ocrProfile.detModel)+".param"),
			filepath.Join(bundleDir, filepath.FromSlash(ocrProfile.detModel)+".bin"),
			options,
		)
		if err != nil {
			return err
		}
		cleanupNet = true
		splitHeadNet, err = r.base.loadNetFromPaths(
			filepath.Join(bundleDir, filepath.FromSlash(ocrProfile.recModel)+".param"),
			filepath.Join(bundleDir, filepath.FromSlash(ocrProfile.recModel)+".bin"),
			options,
		)
		if err != nil {
			return err
		}
		cleanupSplitHeadNet = true
	default:
		net, err = nativeLoadNetFromDir(r.base, modelDir, options)
		if err != nil {
			return err
		}
		cleanupNet = true
	}

	if visionProfile.faceBundle && strings.TrimSpace(visionProfile.faceEmbeddingSubdir) != "" {
		subdir := filepath.Join(strings.TrimSpace(bundleDir), strings.TrimSpace(visionProfile.faceEmbeddingSubdir))
		faceEmbeddingNet, err = nativeLoadNetFromDir(r.base, subdir, options)
		if err != nil {
			return err
		}
		cleanupFaceEmbeddingNet = true
	}

	loadedModel := &nativeEmbeddingModel{
		net:               net,
		splitHeadNet:      splitHeadNet,
		faceEmbeddingNet:  faceEmbeddingNet,
		profile:           profile,
		visionProfile:     visionProfile,
		ocrProfile:        ocrProfile,
		ocrKeys:           append([]string(nil), ocrKeys...),
		threadLimit:       options.threadLimit,
		useFP16Packed:     options.useFP16Packed,
		useFP16Storage:    options.useFP16Storage,
		useFP16Arithmetic: options.useFP16Arithmetic,
		useINT8Packed:     options.useINT8Packed,
		useINT8Storage:    options.useINT8Storage,
		useINT8Arithmetic: options.useINT8Arithmetic,
		usePackingLayout:  options.usePackingLayout,
		splitFeatureBlob:  bundleLayout.backboneFeatureBlob,
		splitHeadInput:    bundleLayout.headInputName,
		splitHeadOutput:   bundleLayout.headOutputName,
		splitPostprocess:  bundleLayout.headPostprocess,
	}
	r.mu.Lock()
	existing := r.loaded[modelClass]
	r.loaded[modelClass] = loadedModel
	cleanupNet = false
	cleanupSplitHeadNet = false
	cleanupFaceEmbeddingNet = false
	r.mu.Unlock()
	r.destroyNativeEmbeddingModel(existing)
	return nil
}

func (b *nativeEmbeddingBackend) loadNetFromDir(bundleDir string, options nativeEmbeddingLoadOptions) (uintptr, error) {
	paramPath := filepath.Join(strings.TrimSpace(bundleDir), "model.param")
	modelPath := filepath.Join(strings.TrimSpace(bundleDir), "model.bin")
	return b.loadNetFromPaths(paramPath, modelPath, options)
}

func (b *nativeEmbeddingBackend) loadNetFromPaths(paramPath, modelPath string, options nativeEmbeddingLoadOptions) (uintptr, error) {
	paramCString := append([]byte(paramPath), 0)
	modelCString := append([]byte(modelPath), 0)
	net := b.bindings.netCreate()
	if net == 0 {
		return 0, fmt.Errorf("ncnn_net_create returned nil")
	}
	cleanupNet := true
	defer func() {
		if cleanupNet {
			b.bindings.netDestroy(net)
		}
	}()

	opt := b.bindings.optionCreate()
	if opt == 0 {
		return 0, fmt.Errorf("ncnn_option_create returned nil")
	}
	b.configureLoadOption(opt, options)
	b.bindings.netSetOption(net, opt)
	b.bindings.optionDestroy(opt)

	if code := b.bindings.netLoadParam(net, byteSliceCStringPointer(paramCString)); code != 0 {
		return 0, fmt.Errorf("failed to load NCNN param from %s: %d", paramPath, code)
	}
	if code := b.bindings.netLoadModel(net, byteSliceCStringPointer(modelCString)); code != 0 {
		return 0, fmt.Errorf("failed to load NCNN model from %s: %d", modelPath, code)
	}
	cleanupNet = false
	return net, nil
}

func (b *nativeEmbeddingBackend) configureLoadOption(opt uintptr, options nativeEmbeddingLoadOptions) {
	if opt == 0 {
		return
	}
	if options.threadLimit > 0 {
		b.bindings.optionSetNumThreads(opt, int32(options.threadLimit))
	}
	b.bindings.optionSetUseFP16Packed(opt, boolToCInt(options.useFP16Packed))
	b.bindings.optionSetUseFP16Storage(opt, boolToCInt(options.useFP16Storage))
	b.bindings.optionSetUseFP16Arithmetic(opt, boolToCInt(options.useFP16Arithmetic))
	b.bindings.optionSetUseINT8Packed(opt, boolToCInt(options.useINT8Packed))
	b.bindings.optionSetUseINT8Storage(opt, boolToCInt(options.useINT8Storage))
	b.bindings.optionSetUseINT8Arithmetic(opt, boolToCInt(options.useINT8Arithmetic))
	b.bindings.optionSetUsePackingLayout(opt, boolToCInt(options.usePackingLayout))
}

func nativeVisionLoadOptions(options nativeEmbeddingLoadOptions, profile nativeVisionProfile) nativeEmbeddingLoadOptions {
	if profile.faceBundle {
		options.usePackingLayout = false
	}
	return options
}

func (b *nativeEmbeddingBackend) configureExtractorOption(opt uintptr, threadLimit int, model *nativeEmbeddingModel) {
	if opt == 0 || model == nil {
		return
	}
	if threadLimit > 0 {
		b.bindings.optionSetNumThreads(opt, int32(threadLimit))
	}
	b.bindings.optionSetUseFP16Packed(opt, boolToCInt(model.useFP16Packed))
	b.bindings.optionSetUseFP16Storage(opt, boolToCInt(model.useFP16Storage))
	b.bindings.optionSetUseFP16Arithmetic(opt, boolToCInt(model.useFP16Arithmetic))
	b.bindings.optionSetUseINT8Packed(opt, boolToCInt(model.useINT8Packed))
	b.bindings.optionSetUseINT8Storage(opt, boolToCInt(model.useINT8Storage))
	b.bindings.optionSetUseINT8Arithmetic(opt, boolToCInt(model.useINT8Arithmetic))
	b.bindings.optionSetUsePackingLayout(opt, boolToCInt(model.usePackingLayout))
}

func (r *nativeEmbeddingRuntime) infer(modelClass string, inputs nativePreparedEmbeddingInputs, threadLimit int) ([]float64, error) {
	if r == nil || r.base == nil {
		return nil, fmt.Errorf("native embedding backend unavailable")
	}
	model, unlockModel := r.lockLoadedModelForInfer(modelClass)
	if unlockModel != nil {
		defer unlockModel()
	}
	if model == nil || model.net == 0 {
		return nil, fmt.Errorf("native embedding model class %s is not loaded", strings.TrimSpace(modelClass))
	}

	int32IDs := make([]int32, len(inputs.inputIDs))
	for i, value := range inputs.inputIDs {
		int32IDs[i] = int32(value)
	}
	idMatExternal := r.base.bindings.matCreateExternal1DElem(int32(len(int32IDs)), unsafe.Pointer(&int32IDs[0]), 4, 1, 0)
	if idMatExternal == 0 {
		return nil, fmt.Errorf("failed to create NCNN external input mat for input_ids")
	}
	defer r.base.bindings.matDestroy(idMatExternal)
	idMat := r.base.bindings.matClone(idMatExternal, 0)
	if idMat == 0 {
		return nil, fmt.Errorf("failed to clone NCNN input_ids mat")
	}
	defer r.base.bindings.matDestroy(idMat)

	float32Mask := make([]float32, len(inputs.attentionMask))
	for i, value := range inputs.attentionMask {
		float32Mask[i] = float32(value)
	}
	maskMatExternal := r.base.bindings.matCreateExternal1DElem(int32(len(float32Mask)), unsafe.Pointer(&float32Mask[0]), 4, 1, 0)
	if maskMatExternal == 0 {
		return nil, fmt.Errorf("failed to create NCNN external input mat for attention_mask")
	}
	defer r.base.bindings.matDestroy(maskMatExternal)
	maskMat := r.base.bindings.matClone(maskMatExternal, 0)
	if maskMat == 0 {
		return nil, fmt.Errorf("failed to clone NCNN attention_mask mat")
	}
	defer r.base.bindings.matDestroy(maskMat)

	effectiveThreadLimit := threadLimit
	if effectiveThreadLimit <= 0 {
		effectiveThreadLimit = model.threadLimit
	}
	if model.splitHeadNet != 0 {
		return r.inferSplitEmbedding(model, idMat, maskMat, int32IDs, float32Mask, effectiveThreadLimit)
	}

	extractor, err := r.createExtractor(model.net, effectiveThreadLimit, model)
	if err != nil {
		return nil, err
	}
	defer r.base.bindings.extractorDestroy(extractor)

	in0 := []byte("in0\x00")
	if code := r.base.bindings.extractorInput(extractor, byteSliceCStringPointer(in0), idMat); code != 0 {
		return nil, fmt.Errorf("failed to bind NCNN input in0: %d", code)
	}
	in1 := []byte("in1\x00")
	if code := r.base.bindings.extractorInput(extractor, byteSliceCStringPointer(in1), maskMat); code != 0 {
		return nil, fmt.Errorf("failed to bind NCNN input in1: %d", code)
	}

	out0 := []byte("out0\x00")
	var outputMat uintptr
	if code := r.base.bindings.extractorExtract(extractor, byteSliceCStringPointer(out0), &outputMat); code != 0 {
		return nil, fmt.Errorf("failed to extract NCNN output out0: %d", code)
	}
	if outputMat == 0 {
		return nil, fmt.Errorf("native NCNN extractor returned nil output mat")
	}
	defer r.base.bindings.matDestroy(outputMat)

	values, err := nativeFloatValuesFromMat(r.base.bindings, outputMat)
	if err != nil {
		return nil, err
	}
	result := make([]float64, len(values))
	for i, value := range values {
		result[i] = float64(value)
	}
	runtime.KeepAlive(int32IDs)
	runtime.KeepAlive(float32Mask)
	return result, nil
}

func (r *nativeEmbeddingRuntime) lockLoadedModelForInfer(modelClass string) (*nativeEmbeddingModel, func()) {
	if r == nil {
		return nil, nil
	}
	r.mu.Lock()
	model := r.loaded[strings.TrimSpace(modelClass)]
	if model != nil {
		model.lifecycleMu.RLock()
	}
	r.mu.Unlock()
	if model == nil {
		return nil, nil
	}
	return model, model.lifecycleMu.RUnlock
}

func (r *nativeEmbeddingRuntime) inferSplitEmbedding(model *nativeEmbeddingModel, idMat, maskMat uintptr, int32IDs []int32, float32Mask []float32, effectiveThreadLimit int) ([]float64, error) {
	if model == nil || model.net == 0 || model.splitHeadNet == 0 {
		return nil, fmt.Errorf("native split embedding model is not loaded")
	}
	if strings.TrimSpace(model.splitFeatureBlob) == "" {
		return nil, fmt.Errorf("native split embedding backbone feature blob is required")
	}
	if strings.TrimSpace(model.splitHeadInput) == "" || strings.TrimSpace(model.splitHeadOutput) == "" {
		return nil, fmt.Errorf("native split embedding head io names are required")
	}

	backboneExtractor, err := r.createExtractor(model.net, effectiveThreadLimit, model)
	if err != nil {
		return nil, err
	}
	defer r.base.bindings.extractorDestroy(backboneExtractor)

	in0 := []byte("in0\x00")
	if code := r.base.bindings.extractorInput(backboneExtractor, byteSliceCStringPointer(in0), idMat); code != 0 {
		return nil, fmt.Errorf("failed to bind NCNN input in0: %d", code)
	}
	in1 := []byte("in1\x00")
	if code := r.base.bindings.extractorInput(backboneExtractor, byteSliceCStringPointer(in1), maskMat); code != 0 {
		return nil, fmt.Errorf("failed to bind NCNN input in1: %d", code)
	}

	featureBlob := append([]byte(strings.TrimSpace(model.splitFeatureBlob)), 0)
	var featureMat uintptr
	if code := r.base.bindings.extractorExtract(backboneExtractor, byteSliceCStringPointer(featureBlob), &featureMat); code != 0 {
		return nil, fmt.Errorf("failed to extract NCNN backbone feature %s: %d", strings.TrimSpace(model.splitFeatureBlob), code)
	}
	if featureMat == 0 {
		return nil, fmt.Errorf("native NCNN backbone extractor returned nil feature mat")
	}
	defer r.base.bindings.matDestroy(featureMat)

	headExtractor, err := r.createExtractor(model.splitHeadNet, effectiveThreadLimit, model)
	if err != nil {
		return nil, err
	}
	defer r.base.bindings.extractorDestroy(headExtractor)

	headInput := append([]byte(strings.TrimSpace(model.splitHeadInput)), 0)
	if code := r.base.bindings.extractorInput(headExtractor, byteSliceCStringPointer(headInput), featureMat); code != 0 {
		return nil, fmt.Errorf("failed to bind NCNN head input %s: %d", strings.TrimSpace(model.splitHeadInput), code)
	}

	headOutput := append([]byte(strings.TrimSpace(model.splitHeadOutput)), 0)
	var outputMat uintptr
	if code := r.base.bindings.extractorExtract(headExtractor, byteSliceCStringPointer(headOutput), &outputMat); code != 0 {
		return nil, fmt.Errorf("failed to extract NCNN head output %s: %d", strings.TrimSpace(model.splitHeadOutput), code)
	}
	if outputMat == 0 {
		return nil, fmt.Errorf("native NCNN head extractor returned nil output mat")
	}
	defer r.base.bindings.matDestroy(outputMat)

	values, err := nativeFloatValuesFromMat(r.base.bindings, outputMat)
	if err != nil {
		return nil, err
	}
	result := make([]float64, len(values))
	for i, value := range values {
		result[i] = float64(value)
	}
	result = postprocessNativeEmbeddingOutput(result, model.splitPostprocess)
	runtime.KeepAlive(int32IDs)
	runtime.KeepAlive(float32Mask)
	return result, nil
}

func (r *nativeEmbeddingRuntime) createExtractor(net uintptr, effectiveThreadLimit int, model *nativeEmbeddingModel) (uintptr, error) {
	extractor := r.base.bindings.extractorCreate(net)
	if extractor == 0 {
		return 0, fmt.Errorf("failed to create NCNN extractor")
	}
	if effectiveThreadLimit > 0 {
		extractorOpt := r.base.bindings.optionCreate()
		if extractorOpt != 0 {
			r.base.configureExtractorOption(extractorOpt, effectiveThreadLimit, model)
			r.base.bindings.extractorSetOption(extractor, extractorOpt)
			r.base.bindings.optionDestroy(extractorOpt)
		}
	}
	return extractor, nil
}

func nativeFloatValuesFromMat(bindings nativeNCNNBindings, mat uintptr) ([]float32, error) {
	total := nativeMatElementCount(bindings, mat)
	if total <= 0 {
		return nil, fmt.Errorf("native NCNN output mat was empty")
	}
	data := bindings.matGetData(mat)
	if data == nil {
		return nil, fmt.Errorf("native NCNN output mat data pointer was nil")
	}
	values := unsafe.Slice((*float32)(data), total)
	for index, value := range values {
		if !nativeFloat32IsFinite(value) {
			return nil, fmt.Errorf("native NCNN output contains non-finite value at index %d", index)
		}
	}
	return values, nil
}

func nativeFloat32IsFinite(value float32) bool {
	converted := float64(value)
	return !math.IsNaN(converted) && !math.IsInf(converted, 0)
}

func postprocessNativeEmbeddingOutput(values []float64, postprocess string) []float64 {
	if !strings.EqualFold(strings.TrimSpace(postprocess), nativeEmbeddingPostprocessL2Normalize) {
		return values
	}
	var norm float64
	for _, value := range values {
		norm += value * value
	}
	if norm <= 0 {
		return values
	}
	scale := 1.0 / math.Sqrt(norm)
	result := make([]float64, len(values))
	for i, value := range values {
		result[i] = value * scale
	}
	return result
}

func (r *nativeEmbeddingRuntime) unload(modelClass string) {
	if r == nil || r.base == nil {
		return
	}
	r.mu.Lock()
	retired := make([]*nativeEmbeddingModel, 0, len(r.loaded))
	modelClass = strings.TrimSpace(modelClass)
	if modelClass == "" {
		for _, model := range r.loaded {
			retired = append(retired, model)
		}
		r.loaded = make(map[string]*nativeEmbeddingModel)
	} else {
		for key, model := range r.loaded {
			if !modelClassMatchesUnload(key, modelClass) {
				continue
			}
			retired = append(retired, model)
			delete(r.loaded, key)
		}
	}
	r.mu.Unlock()
	for _, model := range retired {
		r.destroyNativeEmbeddingModel(model)
	}
}

func (r *nativeEmbeddingRuntime) destroyNativeEmbeddingModel(model *nativeEmbeddingModel) {
	if r == nil || r.base == nil || model == nil {
		return
	}
	model.lifecycleMu.Lock()
	defer model.lifecycleMu.Unlock()
	if model.net != 0 {
		r.base.bindings.netDestroy(model.net)
		model.net = 0
	}
	if model.splitHeadNet != 0 {
		r.base.bindings.netDestroy(model.splitHeadNet)
		model.splitHeadNet = 0
	}
	if model.faceEmbeddingNet != 0 {
		r.base.bindings.netDestroy(model.faceEmbeddingNet)
		model.faceEmbeddingNet = 0
	}
}

func resolveNativeEmbeddingLoadOptions(metadata map[string]interface{}, threadLimit int) nativeEmbeddingLoadOptions {
	options := nativeEmbeddingLoadOptions{
		threadLimit:       threadLimit,
		useFP16Packed:     true,
		useFP16Storage:    true,
		useFP16Arithmetic: true,
		useINT8Packed:     true,
		useINT8Storage:    true,
		useINT8Arithmetic: true,
		usePackingLayout:  true,
	}
	if nested, ok := metadata["ncnn_runtime"].(map[string]interface{}); ok {
		if value, ok := boolValue(nested["use_fp16_packed"]); ok {
			options.useFP16Packed = value
		}
		if value, ok := boolValue(nested["use_fp16_storage"]); ok {
			options.useFP16Storage = value
		}
		if value, ok := boolValue(nested["use_fp16_arithmetic"]); ok {
			options.useFP16Arithmetic = value
		}
	}
	if value, ok := boolValue(metadata["use_fp16_packed"]); ok {
		options.useFP16Packed = value
	}
	if value, ok := boolValue(metadata["use_fp16_storage"]); ok {
		options.useFP16Storage = value
	}
	if value, ok := boolValue(metadata["use_fp16_arithmetic"]); ok {
		options.useFP16Arithmetic = value
	}
	return options
}

func mergeBundleLoadMetadataForNativeRuntime(bundleDir string, explicit map[string]interface{}) map[string]interface{} {
	bundleMetadata := readBundleMetadataForNativeRuntime(bundleDir)
	if len(bundleMetadata) == 0 && len(explicit) == 0 {
		return nil
	}
	return mergeMetadataMapForNativeRuntime(bundleMetadata, explicit)
}

func resolveNativeEmbeddingBundleLayout(bundleDir string) (nativeEmbeddingBundleLayout, error) {
	bundleDir = strings.TrimSpace(bundleDir)
	if bundleDir == "" {
		return nativeEmbeddingBundleLayout{}, fmt.Errorf("native embedding bundle directory is required")
	}
	metadata := readBundleMetadataForNativeRuntime(bundleDir)
	if strings.EqualFold(stringValue(metadata["runtime_kind"]), nativeEmbeddingRuntimeKindSplitNCNN) {
		backbone, ok := metadata["backbone"].(map[string]interface{})
		if !ok {
			return nativeEmbeddingBundleLayout{}, fmt.Errorf("split NCNN backbone metadata is required")
		}
		head, ok := metadata["head"].(map[string]interface{})
		if !ok {
			return nativeEmbeddingBundleLayout{}, fmt.Errorf("split NCNN head metadata is required")
		}
		backboneParamPath, err := resolveNativeEmbeddingBundleFilePath(bundleDir, "backbone param", stringValue(backbone["param"]))
		if err != nil {
			return nativeEmbeddingBundleLayout{}, err
		}
		backboneModelPath, err := resolveNativeEmbeddingBundleFilePath(bundleDir, "backbone bin", stringValue(backbone["bin"]))
		if err != nil {
			return nativeEmbeddingBundleLayout{}, err
		}
		headParamPath, err := resolveNativeEmbeddingBundleFilePath(bundleDir, "head param", stringValue(head["param"]))
		if err != nil {
			return nativeEmbeddingBundleLayout{}, err
		}
		headModelPath, err := resolveNativeEmbeddingBundleFilePath(bundleDir, "head bin", stringValue(head["bin"]))
		if err != nil {
			return nativeEmbeddingBundleLayout{}, err
		}
		layout := nativeEmbeddingBundleLayout{
			runtimeKind:         nativeEmbeddingRuntimeKindSplitNCNN,
			backboneParamPath:   backboneParamPath,
			backboneModelPath:   backboneModelPath,
			backboneFeatureBlob: strings.TrimSpace(stringValue(backbone["feature_blob"])),
			headParamPath:       headParamPath,
			headModelPath:       headModelPath,
			headInputName:       strings.TrimSpace(stringValue(head["input_name"])),
			headOutputName:      strings.TrimSpace(stringValue(head["output_name"])),
			headPostprocess:     strings.TrimSpace(stringValue(head["postprocess"])),
		}
		for field, path := range map[string]string{
			"backbone param": layout.backboneParamPath,
			"backbone bin":   layout.backboneModelPath,
			"head param":     layout.headParamPath,
			"head bin":       layout.headModelPath,
		} {
			if strings.TrimSpace(path) == "" {
				return nativeEmbeddingBundleLayout{}, fmt.Errorf("split NCNN %s path is required", field)
			}
			if info, err := os.Stat(path); err != nil || info.IsDir() {
				return nativeEmbeddingBundleLayout{}, fmt.Errorf("split NCNN %s missing: %s", field, path)
			}
		}
		if layout.backboneFeatureBlob == "" {
			return nativeEmbeddingBundleLayout{}, fmt.Errorf("split NCNN backbone feature blob is required")
		}
		if layout.headInputName == "" || layout.headOutputName == "" {
			return nativeEmbeddingBundleLayout{}, fmt.Errorf("split NCNN head input and output names are required")
		}
		return layout, nil
	}
	layout := nativeEmbeddingBundleLayout{
		rootParamPath: filepath.Join(bundleDir, "model.param"),
		rootModelPath: filepath.Join(bundleDir, "model.bin"),
	}
	for field, path := range map[string]string{
		"root param": layout.rootParamPath,
		"root bin":   layout.rootModelPath,
	} {
		if info, err := os.Stat(path); err != nil || info.IsDir() {
			return nativeEmbeddingBundleLayout{}, fmt.Errorf("native embedding %s missing: %s", field, path)
		}
	}
	return layout, nil
}

func resolveNativeEmbeddingBundleFilePath(bundleDir, field, configuredPath string) (string, error) {
	configuredPath = strings.TrimSpace(configuredPath)
	if configuredPath == "" {
		return "", fmt.Errorf("split NCNN %s path is required", field)
	}
	if filepath.IsAbs(configuredPath) {
		return "", fmt.Errorf("split NCNN %s path must stay within native embedding bundle: %s", field, configuredPath)
	}
	bundleRoot, err := filepath.Abs(strings.TrimSpace(bundleDir))
	if err != nil {
		return "", fmt.Errorf("resolve native embedding bundle directory: %w", err)
	}
	resolvedPath := filepath.Join(bundleRoot, configuredPath)
	relativePath, err := filepath.Rel(bundleRoot, resolvedPath)
	if err != nil || relativePath == ".." || strings.HasPrefix(relativePath, ".."+string(filepath.Separator)) {
		return "", fmt.Errorf("split NCNN %s path must stay within native embedding bundle: %s", field, configuredPath)
	}
	return resolvedPath, nil
}

func readBundleMetadataForNativeRuntime(bundleDir string) map[string]interface{} {
	bundleDir = strings.TrimSpace(bundleDir)
	if bundleDir == "" {
		return nil
	}
	data, err := os.ReadFile(filepath.Join(bundleDir, "metadata.json"))
	if err != nil {
		return nil
	}
	var payload map[string]interface{}
	if err := json.Unmarshal(data, &payload); err != nil {
		return nil
	}
	return cloneMetadataMapForNativeRuntime(payload)
}

func mergeMetadataMapForNativeRuntime(base, override map[string]interface{}) map[string]interface{} {
	if len(base) == 0 && len(override) == 0 {
		return nil
	}
	merged := cloneMetadataMapForNativeRuntime(base)
	if merged == nil {
		merged = make(map[string]interface{}, len(override))
	}
	for key, value := range override {
		existing, existingOK := merged[key].(map[string]interface{})
		overrideMap, overrideOK := value.(map[string]interface{})
		if existingOK && overrideOK {
			merged[key] = mergeMetadataMapForNativeRuntime(existing, overrideMap)
			continue
		}
		merged[key] = cloneMetadataValueForNativeRuntime(value)
	}
	return merged
}

func cloneMetadataMapForNativeRuntime(values map[string]interface{}) map[string]interface{} {
	if len(values) == 0 {
		return nil
	}
	cloned := make(map[string]interface{}, len(values))
	for key, value := range values {
		cloned[key] = cloneMetadataValueForNativeRuntime(value)
	}
	return cloned
}

func cloneMetadataValueForNativeRuntime(value interface{}) interface{} {
	switch typed := value.(type) {
	case map[string]interface{}:
		return cloneMetadataMapForNativeRuntime(typed)
	case []interface{}:
		cloned := make([]interface{}, len(typed))
		for i, item := range typed {
			cloned[i] = cloneMetadataValueForNativeRuntime(item)
		}
		return cloned
	default:
		return typed
	}
}

func boolValue(raw interface{}) (bool, bool) {
	typed, ok := raw.(bool)
	if !ok {
		return false, false
	}
	return typed, true
}

func stringValue(raw interface{}) string {
	if typed, ok := raw.(string); ok {
		return typed
	}
	return ""
}

func nativeMatElementCount(bindings nativeNCNNBindings, mat uintptr) int {
	if mat == 0 {
		return 0
	}
	dims := int(bindings.matGetDims(mat))
	w := int(bindings.matGetW(mat))
	h := int(bindings.matGetH(mat))
	d := int(bindings.matGetD(mat))
	c := int(bindings.matGetC(mat))
	switch dims {
	case 1:
		return maxNativeCount(w, 0)
	case 2:
		return maxNativeCount(w*h, 0)
	case 3:
		return maxNativeCount(w*h*c, 0)
	case 4:
		return maxNativeCount(w*h*d*c, 0)
	default:
		if w > 0 {
			return w
		}
		return 0
	}
}

func maxNativeCount(value, fallback int) int {
	if value > 0 {
		return value
	}
	return fallback
}

func boolToCInt(value bool) int32 {
	if value {
		return 1
	}
	return 0
}

func byteSliceCStringPointer(value []byte) *byte {
	if len(value) == 0 {
		return nil
	}
	return &value[0]
}
