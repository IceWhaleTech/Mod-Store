package main

import (
	"encoding/json"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
	"unsafe"
)

func TestResolveNativeEmbeddingLoadOptionsEnablesINT8ByDefault(t *testing.T) {
	options := resolveNativeEmbeddingLoadOptions(nil, 1)
	if !options.useINT8Packed || !options.useINT8Storage || !options.useINT8Arithmetic {
		t.Fatalf("INT8 options = packed:%t storage:%t arithmetic:%t, want all enabled", options.useINT8Packed, options.useINT8Storage, options.useINT8Arithmetic)
	}
}

func TestNativeFaceLoadOptionsDisablePackingLayout(t *testing.T) {
	options := nativeVisionLoadOptions(nativeEmbeddingLoadOptions{usePackingLayout: true}, nativeVisionProfile{faceBundle: true})
	if options.usePackingLayout {
		t.Fatal("face load options keep packing layout enabled, want disabled to avoid retained packed weights")
	}
}

func TestResolveNativeEmbeddingBundleLayoutRecognizesSplitNCNNBundle(t *testing.T) {
	bundleDir := writeNativeSplitEmbeddingBundleForTest(t)

	layout, err := resolveNativeEmbeddingBundleLayout(bundleDir)
	if err != nil {
		t.Fatalf("resolveNativeEmbeddingBundleLayout() error = %v", err)
	}
	if layout.runtimeKind != nativeEmbeddingRuntimeKindSplitNCNN {
		t.Fatalf("layout.runtimeKind = %q, want %q", layout.runtimeKind, nativeEmbeddingRuntimeKindSplitNCNN)
	}
	if got, want := filepath.Base(layout.backboneParamPath), "backbone.param"; got != want {
		t.Fatalf("backbone param = %q, want %q", got, want)
	}
	if got, want := filepath.Base(layout.backboneModelPath), "backbone.bin"; got != want {
		t.Fatalf("backbone model = %q, want %q", got, want)
	}
	if layout.backboneFeatureBlob != "136" {
		t.Fatalf("backboneFeatureBlob = %q, want 136", layout.backboneFeatureBlob)
	}
	if got, want := filepath.Base(layout.headParamPath), "projection.param"; got != want {
		t.Fatalf("head param = %q, want %q", got, want)
	}
	if got, want := filepath.Base(layout.headModelPath), "projection.bin"; got != want {
		t.Fatalf("head model = %q, want %q", got, want)
	}
	if layout.headInputName != "in0" {
		t.Fatalf("headInputName = %q, want in0", layout.headInputName)
	}
	if layout.headOutputName != "out0" {
		t.Fatalf("headOutputName = %q, want out0", layout.headOutputName)
	}
	if layout.headPostprocess != nativeEmbeddingPostprocessL2Normalize {
		t.Fatalf("headPostprocess = %q, want %q", layout.headPostprocess, nativeEmbeddingPostprocessL2Normalize)
	}
}

func TestMustMarshalReturnsErrorJSONInsteadOfPanicking(t *testing.T) {
	defer func() {
		if recovered := recover(); recovered != nil {
			t.Fatalf("mustMarshal() panicked: %v", recovered)
		}
	}()

	payload := mustMarshal(map[string]interface{}{"embedding": []float64{math.NaN()}})
	var result map[string]interface{}
	if err := json.Unmarshal(payload, &result); err != nil {
		t.Fatalf("json.Unmarshal() error = %v, payload = %q", err, payload)
	}
	if got := result["error"]; got != "json_marshal_failed" {
		t.Fatalf("error = %#v, want json_marshal_failed", got)
	}
}

func TestNativeFloatValuesFromMatRejectsNonFiniteValues(t *testing.T) {
	value := float32(math.Inf(1))
	_, err := nativeFloatValuesFromMat(nativeNCNNBindings{
		matGetDims: func(uintptr) int32 { return 1 },
		matGetW:    func(uintptr) int32 { return 1 },
		matGetH:    func(uintptr) int32 { return 1 },
		matGetD:    func(uintptr) int32 { return 1 },
		matGetC:    func(uintptr) int32 { return 1 },
		matGetData: func(uintptr) unsafe.Pointer { return unsafe.Pointer(&value) },
	}, 1)
	if err == nil || !strings.Contains(err.Error(), "non-finite") {
		t.Fatalf("nativeFloatValuesFromMat() error = %v, want non-finite rejection", err)
	}
}

func TestResolveNativeEmbeddingBundleLayoutRejectsSplitPathsOutsideBundle(t *testing.T) {
	fields := []struct {
		section string
		key     string
	}{
		{section: "backbone", key: "param"},
		{section: "backbone", key: "bin"},
		{section: "head", key: "param"},
		{section: "head", key: "bin"},
	}
	for _, field := range fields {
		for _, pathKind := range []string{"absolute", "parent"} {
			t.Run(field.section+"_"+field.key+"_"+pathKind, func(t *testing.T) {
				bundleDir := writeNativeSplitEmbeddingBundleForTest(t)
				outsideName := fmt.Sprintf("outside-%s-%s", field.section, field.key)
				outsidePath := filepath.Join(t.TempDir(), outsideName)
				metadataPath := outsidePath
				if pathKind == "parent" {
					outsidePath = filepath.Join(filepath.Dir(bundleDir), outsideName)
					metadataPath = filepath.Join("..", outsideName)
				}
				if err := os.WriteFile(outsidePath, []byte(outsideName), 0o644); err != nil {
					t.Fatalf("WriteFile(%s) error = %v", outsidePath, err)
				}

				metadata := readBundleMetadataForNativeRuntime(bundleDir)
				section, ok := metadata[field.section].(map[string]interface{})
				if !ok {
					t.Fatalf("metadata[%s] = %#v, want map", field.section, metadata[field.section])
				}
				section[field.key] = metadataPath
				writeNativeRuntimeJSONFileForTest(t, filepath.Join(bundleDir, "metadata.json"), metadata)

				_, err := resolveNativeEmbeddingBundleLayout(bundleDir)
				if err == nil {
					t.Fatal("resolveNativeEmbeddingBundleLayout() error = nil, want bundle escape rejection")
				}
				if !strings.Contains(err.Error(), "must stay within native embedding bundle") {
					t.Fatalf("resolveNativeEmbeddingBundleLayout() error = %v, want bundle escape rejection", err)
				}
			})
		}
	}
}

func TestNativeEmbeddingRuntimeInferRunsSplitNCNNTwoStageBundle(t *testing.T) {
	bundleDir := writeNativeSplitEmbeddingBundleForTest(t)
	fake := newFakeNativeNCNNBindingsForTest()
	fake.backboneFeature = []float32{3, 4}
	fake.headOutput = []float32{6, 8}
	runtime := &nativeEmbeddingRuntime{
		base:   &nativeEmbeddingBackend{bindings: fake.bindings()},
		loaded: make(map[string]*nativeEmbeddingModel),
	}

	if err := runtime.load(modelClassEmbedding, bundleDir, nativeEmbeddingLoadOptions{threadLimit: 2}); err != nil {
		t.Fatalf("load() error = %v", err)
	}
	if got, want := fake.netLoadParamPaths, []string{"backbone.param", "projection.param"}; len(got) != len(want) {
		t.Fatalf("netLoadParamPaths len = %d, want %d (%v)", len(got), len(want), got)
	} else {
		for i := range want {
			if filepath.Base(got[i]) != want[i] {
				t.Fatalf("netLoadParamPaths[%d] = %q, want %q", i, filepath.Base(got[i]), want[i])
			}
		}
	}

	embedding, err := runtime.infer(modelClassEmbedding, nativePreparedEmbeddingInputs{
		profile:       nativeEmbeddingProfileSentencePiece,
		inputIDs:      []int{101, 102, 103},
		attentionMask: []float64{1, 1, 1},
	}, 0)
	if err != nil {
		t.Fatalf("infer() error = %v", err)
	}
	if got, want := fake.lastHeadInput, []float32{3, 4}; len(got) != len(want) {
		t.Fatalf("lastHeadInput len = %d, want %d (%v)", len(got), len(want), got)
	} else {
		for i := range want {
			if got[i] != want[i] {
				t.Fatalf("lastHeadInput[%d] = %v, want %v", i, got[i], want[i])
			}
		}
	}
	if len(embedding) != 2 {
		t.Fatalf("len(embedding) = %d, want 2", len(embedding))
	}
	if math.Abs(embedding[0]-0.6) > 1e-9 || math.Abs(embedding[1]-0.8) > 1e-9 {
		t.Fatalf("embedding = %#v, want normalized [0.6 0.8]", embedding)
	}
}

func TestNativeEmbeddingRuntimeDefersDestroyWhileInferIsInFlight(t *testing.T) {
	for _, testCase := range []struct {
		name   string
		reload bool
	}{
		{name: "unload"},
		{name: "reload", reload: true},
	} {
		t.Run(testCase.name, func(t *testing.T) {
			harness := newNativeEmbeddingLifecycleHarnessForTest()
			oldModel := &nativeEmbeddingModel{
				net:     harness.oldNet,
				profile: nativeEmbeddingProfileSentencePiece,
			}
			runtimeValue := &nativeEmbeddingRuntime{
				base: &nativeEmbeddingBackend{bindings: harness.bindings()},
				loaded: map[string]*nativeEmbeddingModel{
					modelClassEmbedding: oldModel,
				},
			}

			var bundleDir string
			if testCase.reload {
				bundleDir = writeNativeRootEmbeddingBundleForTest(t)
			}

			inferDone := make(chan error, 1)
			go func() {
				_, err := runtimeValue.infer(modelClassEmbedding, nativePreparedEmbeddingInputs{
					profile:       nativeEmbeddingProfileSentencePiece,
					inputIDs:      []int{101},
					attentionMask: []float64{1},
				}, 0)
				inferDone <- err
			}()

			select {
			case <-harness.inferStarted:
			case <-time.After(2 * time.Second):
				t.Fatal("infer did not reach extractorExtract")
			}

			mutationDone := make(chan error, 1)
			go func() {
				if testCase.reload {
					mutationDone <- runtimeValue.load(modelClassEmbedding, bundleDir, nativeEmbeddingLoadOptions{})
					return
				}
				runtimeValue.unload(modelClassEmbedding)
				mutationDone <- nil
			}()

			prematureDestroy, mutationObservedErr := waitForNativeEmbeddingMutationForTest(
				runtimeValue,
				modelClassEmbedding,
				oldModel,
				testCase.reload,
				harness.destroyed,
			)
			close(harness.allowInfer)

			select {
			case err := <-inferDone:
				if err != nil {
					t.Errorf("infer() error = %v", err)
				}
			case <-time.After(2 * time.Second):
				t.Error("infer did not finish after release")
			}
			select {
			case err := <-mutationDone:
				if err != nil {
					t.Errorf("%s error = %v", testCase.name, err)
				}
			case <-time.After(2 * time.Second):
				t.Errorf("%s did not finish after infer completed", testCase.name)
			}

			if mutationObservedErr != nil {
				t.Error(mutationObservedErr)
			}
			if prematureDestroy != 0 {
				t.Errorf("netDestroy(%d) ran before in-flight infer completed", prematureDestroy)
			}
			destroyedNet := prematureDestroy
			if destroyedNet == 0 {
				select {
				case destroyedNet = <-harness.destroyed:
				case <-time.After(2 * time.Second):
					t.Fatal("old model net was not destroyed after infer completed")
				}
			}
			if destroyedNet != harness.oldNet {
				t.Fatalf("destroyed net = %d, want old net %d", destroyedNet, harness.oldNet)
			}
		})
	}
}

func TestPrepareNativeEmbeddingInputsRejectsInputIDsWithoutAttentionMaskForSentencePieceBundle(t *testing.T) {
	bundleDir := writeNativeSentencePieceTokenizerBundleForTest(t)

	_, err := prepareNativeEmbeddingInputs(bundleDir, map[string]interface{}{
		"input_ids": []int{1, 2, 3},
	})
	if err == nil {
		t.Fatal("prepareNativeEmbeddingInputs() error = nil, want missing attention_mask error")
	}
	if !strings.Contains(err.Error(), "input_ids and attention_mask must both be provided") {
		t.Fatalf("prepareNativeEmbeddingInputs() error = %v, want missing attention_mask message", err)
	}
}

func TestMergeBundleLoadMetadataForNativeRuntimeKeepsExplicitMetadataWhenBundleMetadataMissing(t *testing.T) {
	bundleDir := t.TempDir()

	merged := mergeBundleLoadMetadataForNativeRuntime(bundleDir, map[string]interface{}{
		"ncnn_runtime": map[string]interface{}{
			"use_fp16_packed": false,
		},
	})
	if merged == nil {
		t.Fatal("mergeBundleLoadMetadataForNativeRuntime() = nil, want explicit metadata preserved")
	}
	nested, ok := merged["ncnn_runtime"].(map[string]interface{})
	if !ok {
		t.Fatalf("merged[ncnn_runtime] = %#v, want map", merged["ncnn_runtime"])
	}
	if got, _ := nested["use_fp16_packed"].(bool); got {
		t.Fatalf("use_fp16_packed = %v, want false", got)
	}
}

func writeNativeSentencePieceTokenizerBundleForTest(t *testing.T) string {
	t.Helper()

	bundleDir := t.TempDir()
	if err := os.WriteFile(filepath.Join(bundleDir, "sentencepiece.bpe.model"), []byte("spm"), 0o644); err != nil {
		t.Fatalf("WriteFile(sentencepiece.bpe.model) error = %v", err)
	}
	writeNativeRuntimeJSONFileForTest(t, filepath.Join(bundleDir, "tokenizer.json"), map[string]interface{}{
		"model": map[string]interface{}{
			"vocab": []interface{}{
				[]interface{}{"<s>", 0.0},
				[]interface{}{"</s>", 0.0},
				[]interface{}{"hello", 0.0},
			},
		},
	})
	writeNativeRuntimeJSONFileForTest(t, filepath.Join(bundleDir, "metadata.json"), map[string]interface{}{})
	return bundleDir
}

func writeNativeSplitEmbeddingBundleForTest(t *testing.T) string {
	t.Helper()

	bundleDir := writeNativeSentencePieceTokenizerBundleForTest(t)
	writeNativeRuntimeJSONFileForTest(t, filepath.Join(bundleDir, "metadata.json"), map[string]interface{}{
		"runtime_kind": nativeEmbeddingRuntimeKindSplitNCNN,
		"backbone": map[string]interface{}{
			"param":        "backbone.param",
			"bin":          "backbone.bin",
			"feature_blob": "136",
		},
		"head": map[string]interface{}{
			"param":       "projection.param",
			"bin":         "projection.bin",
			"input_name":  "in0",
			"output_name": "out0",
			"postprocess": nativeEmbeddingPostprocessL2Normalize,
		},
	})
	for _, name := range []string{"backbone.param", "backbone.bin", "projection.param", "projection.bin"} {
		if err := os.WriteFile(filepath.Join(bundleDir, name), []byte(name), 0o644); err != nil {
			t.Fatalf("WriteFile(%s) error = %v", name, err)
		}
	}
	return bundleDir
}

func writeNativeRootEmbeddingBundleForTest(t *testing.T) string {
	t.Helper()

	bundleDir := writeNativeSentencePieceTokenizerBundleForTest(t)
	for _, name := range []string{"model.param", "model.bin"} {
		if err := os.WriteFile(filepath.Join(bundleDir, name), []byte(name), 0o644); err != nil {
			t.Fatalf("WriteFile(%s) error = %v", name, err)
		}
	}
	return bundleDir
}

type nativeEmbeddingLifecycleHarnessForTest struct {
	oldNet       uintptr
	newNet       uintptr
	outputMat    uintptr
	output       []float32
	inferStarted chan struct{}
	allowInfer   chan struct{}
	destroyed    chan uintptr
}

func newNativeEmbeddingLifecycleHarnessForTest() *nativeEmbeddingLifecycleHarnessForTest {
	return &nativeEmbeddingLifecycleHarnessForTest{
		oldNet:       1,
		newNet:       2,
		outputMat:    3,
		output:       []float32{1},
		inferStarted: make(chan struct{}),
		allowInfer:   make(chan struct{}),
		destroyed:    make(chan uintptr, 4),
	}
}

func (h *nativeEmbeddingLifecycleHarnessForTest) bindings() nativeNCNNBindings {
	return nativeNCNNBindings{
		netCreate: func() uintptr { return h.newNet },
		netDestroy: func(net uintptr) {
			h.destroyed <- net
		},
		netSetOption:               func(uintptr, uintptr) {},
		netLoadParam:               func(uintptr, *byte) int32 { return 0 },
		netLoadModel:               func(uintptr, *byte) int32 { return 0 },
		optionCreate:               func() uintptr { return 1 },
		optionDestroy:              func(uintptr) {},
		optionSetNumThreads:        func(uintptr, int32) {},
		optionSetUseFP16Packed:     func(uintptr, int32) {},
		optionSetUseFP16Storage:    func(uintptr, int32) {},
		optionSetUseFP16Arithmetic: func(uintptr, int32) {},
		optionSetUseINT8Packed:     func(uintptr, int32) {},
		optionSetUseINT8Storage:    func(uintptr, int32) {},
		optionSetUseINT8Arithmetic: func(uintptr, int32) {},
		optionSetUsePackingLayout:  func(uintptr, int32) {},
		extractorCreate:            func(uintptr) uintptr { return 1 },
		extractorDestroy:           func(uintptr) {},
		extractorSetOption:         func(uintptr, uintptr) {},
		extractorInput:             func(uintptr, *byte, uintptr) int32 { return 0 },
		extractorExtract: func(_ uintptr, _ *byte, output *uintptr) int32 {
			close(h.inferStarted)
			<-h.allowInfer
			*output = h.outputMat
			return 0
		},
		matCreateExternal1DElem: func(int32, unsafe.Pointer, uintptr, int32, uintptr) uintptr { return 1 },
		matClone:                func(uintptr, uintptr) uintptr { return 1 },
		matDestroy:              func(uintptr) {},
		matGetDims:              func(uintptr) int32 { return 1 },
		matGetW:                 func(uintptr) int32 { return 1 },
		matGetH:                 func(uintptr) int32 { return 1 },
		matGetD:                 func(uintptr) int32 { return 1 },
		matGetC:                 func(uintptr) int32 { return 1 },
		matGetData: func(uintptr) unsafe.Pointer {
			return unsafe.Pointer(&h.output[0])
		},
	}
}

func waitForNativeEmbeddingMutationForTest(runtimeValue *nativeEmbeddingRuntime, modelClass string, oldModel *nativeEmbeddingModel, reload bool, destroyed <-chan uintptr) (uintptr, error) {
	deadline := time.NewTimer(2 * time.Second)
	defer deadline.Stop()
	ticker := time.NewTicker(time.Millisecond)
	defer ticker.Stop()

	for {
		loadedModel := make(chan *nativeEmbeddingModel, 1)
		go func() {
			runtimeValue.mu.Lock()
			current := runtimeValue.loaded[modelClass]
			runtimeValue.mu.Unlock()
			loadedModel <- current
		}()
		select {
		case current := <-loadedModel:
			mutationObserved := current == nil
			if reload {
				mutationObserved = current != nil && current != oldModel
			}
			if mutationObserved {
				select {
				case net := <-destroyed:
					return net, nil
				default:
					return 0, nil
				}
			}
		case net := <-destroyed:
			return net, nil
		case <-deadline.C:
			return 0, fmt.Errorf("timed out waiting for %s model map mutation", map[bool]string{false: "unload", true: "reload"}[reload])
		}
		select {
		case net := <-destroyed:
			return net, nil
		case <-ticker.C:
		case <-deadline.C:
			return 0, fmt.Errorf("timed out waiting for %s model map mutation", map[bool]string{false: "unload", true: "reload"}[reload])
		}
	}
}

type fakeNativeNCNNBindingsForTest struct {
	nextHandle        uintptr
	netRoles          map[uintptr]string
	extractors        map[uintptr]*fakeNativeExtractorForTest
	mats              map[uintptr]*fakeNativeMatForTest
	netLoadParamPaths []string
	netLoadModelPaths []string
	backboneFeature   []float32
	headOutput        []float32
	lastHeadInput     []float32
}

type fakeNativeExtractorForTest struct {
	net    uintptr
	inputs map[string]uintptr
}

type fakeNativeMatForTest struct {
	dims      int32
	w         int32
	h         int32
	d         int32
	c         int32
	floatData []float32
	intData   []int32
}

func newFakeNativeNCNNBindingsForTest() *fakeNativeNCNNBindingsForTest {
	return &fakeNativeNCNNBindingsForTest{
		nextHandle: 1,
		netRoles:   make(map[uintptr]string),
		extractors: make(map[uintptr]*fakeNativeExtractorForTest),
		mats:       make(map[uintptr]*fakeNativeMatForTest),
	}
}

func (f *fakeNativeNCNNBindingsForTest) bindings() nativeNCNNBindings {
	return nativeNCNNBindings{
		netCreate: func() uintptr {
			return f.newHandle()
		},
		netDestroy:   func(uintptr) {},
		netSetOption: func(uintptr, uintptr) {},
		netLoadParam: func(net uintptr, path *byte) int32 {
			resolved := fakeNativeCStringToString(path)
			f.netLoadParamPaths = append(f.netLoadParamPaths, resolved)
			f.netRoles[net] = strings.TrimSuffix(filepath.Base(resolved), filepath.Ext(resolved))
			return 0
		},
		netLoadModel: func(net uintptr, path *byte) int32 {
			f.netLoadModelPaths = append(f.netLoadModelPaths, fakeNativeCStringToString(path))
			if _, ok := f.netRoles[net]; !ok {
				f.netRoles[net] = "model"
			}
			return 0
		},
		optionCreate: func() uintptr {
			return f.newHandle()
		},
		optionDestroy:              func(uintptr) {},
		optionSetNumThreads:        func(uintptr, int32) {},
		optionSetUseFP16Packed:     func(uintptr, int32) {},
		optionSetUseFP16Storage:    func(uintptr, int32) {},
		optionSetUseFP16Arithmetic: func(uintptr, int32) {},
		optionSetUseINT8Packed:     func(uintptr, int32) {},
		optionSetUseINT8Storage:    func(uintptr, int32) {},
		optionSetUseINT8Arithmetic: func(uintptr, int32) {},
		optionSetUsePackingLayout:  func(uintptr, int32) {},
		extractorCreate: func(net uintptr) uintptr {
			handle := f.newHandle()
			f.extractors[handle] = &fakeNativeExtractorForTest{net: net, inputs: make(map[string]uintptr)}
			return handle
		},
		extractorDestroy: func(handle uintptr) {
			delete(f.extractors, handle)
		},
		extractorSetOption: func(uintptr, uintptr) {},
		extractorInput: func(handle uintptr, name *byte, mat uintptr) int32 {
			extractor := f.extractors[handle]
			if extractor == nil {
				return -1
			}
			extractor.inputs[fakeNativeCStringToString(name)] = mat
			return 0
		},
		extractorExtract: func(handle uintptr, name *byte, out *uintptr) int32 {
			extractor := f.extractors[handle]
			if extractor == nil {
				return -1
			}
			blob := fakeNativeCStringToString(name)
			role := f.netRoles[extractor.net]
			switch {
			case role == "backbone" && blob == "136":
				*out = f.newFloatMat(f.backboneFeature)
				return 0
			case role == "projection" && blob == "out0":
				mat := f.mats[extractor.inputs["in0"]]
				if mat != nil {
					f.lastHeadInput = append([]float32(nil), mat.floatData...)
				}
				*out = f.newFloatMat(f.headOutput)
				return 0
			default:
				return -1
			}
		},
		matFromPixels: func(*byte, int32, int32, int32, int32, uintptr) uintptr { return 0 },
		matCreateExternal1DElem: func(length int32, data unsafe.Pointer, elemSize uintptr, _ int32, _ uintptr) uintptr {
			handle := f.newHandle()
			mat := &fakeNativeMatForTest{dims: 1, w: length, h: 1, d: 1, c: 1}
			switch elemSize {
			case 4:
				words := unsafe.Slice((*uint32)(data), int(length))
				mat.intData = make([]int32, len(words))
				for i, word := range words {
					mat.intData[i] = int32(word)
				}
			}
			f.mats[handle] = mat
			return handle
		},
		matClone: func(mat uintptr, _ uintptr) uintptr {
			src := f.mats[mat]
			if src == nil {
				return 0
			}
			handle := f.newHandle()
			clone := &fakeNativeMatForTest{dims: src.dims, w: src.w, h: src.h, d: src.d, c: src.c}
			clone.floatData = append([]float32(nil), src.floatData...)
			clone.intData = append([]int32(nil), src.intData...)
			f.mats[handle] = clone
			return handle
		},
		matDestroy: func(handle uintptr) {
			delete(f.mats, handle)
		},
		matGetDims: func(handle uintptr) int32 {
			if mat := f.mats[handle]; mat != nil {
				return mat.dims
			}
			return 0
		},
		matGetW: func(handle uintptr) int32 {
			if mat := f.mats[handle]; mat != nil {
				return mat.w
			}
			return 0
		},
		matGetH: func(handle uintptr) int32 {
			if mat := f.mats[handle]; mat != nil {
				return mat.h
			}
			return 0
		},
		matGetD: func(handle uintptr) int32 {
			if mat := f.mats[handle]; mat != nil {
				return mat.d
			}
			return 0
		},
		matGetC: func(handle uintptr) int32 {
			if mat := f.mats[handle]; mat != nil {
				return mat.c
			}
			return 0
		},
		matGetData: func(handle uintptr) unsafe.Pointer {
			if mat := f.mats[handle]; mat != nil && len(mat.floatData) > 0 {
				return unsafe.Pointer(&mat.floatData[0])
			}
			return nil
		},
		matSubstractMeanNormalize: func(uintptr, *float32, *float32) {},
	}
}

func (f *fakeNativeNCNNBindingsForTest) newHandle() uintptr {
	handle := f.nextHandle
	f.nextHandle++
	return handle
}

func (f *fakeNativeNCNNBindingsForTest) newFloatMat(values []float32) uintptr {
	handle := f.newHandle()
	f.mats[handle] = &fakeNativeMatForTest{
		dims:      1,
		w:         int32(len(values)),
		h:         1,
		d:         1,
		c:         1,
		floatData: append([]float32(nil), values...),
	}
	return handle
}

func fakeNativeCStringToString(ptr *byte) string {
	if ptr == nil {
		return ""
	}
	bytes := make([]byte, 0, 32)
	for offset := uintptr(0); ; offset++ {
		value := *(*byte)(unsafe.Pointer(uintptr(unsafe.Pointer(ptr)) + offset))
		if value == 0 {
			return string(bytes)
		}
		bytes = append(bytes, value)
	}
}

func writeNativeRuntimeJSONFileForTest(t *testing.T, path string, value interface{}) {
	t.Helper()

	raw, err := json.Marshal(value)
	if err != nil {
		t.Fatalf("json.Marshal(%s) error = %v", filepath.Base(path), err)
	}
	if err := os.WriteFile(path, raw, 0o644); err != nil {
		t.Fatalf("WriteFile(%s) error = %v", path, err)
	}
}
