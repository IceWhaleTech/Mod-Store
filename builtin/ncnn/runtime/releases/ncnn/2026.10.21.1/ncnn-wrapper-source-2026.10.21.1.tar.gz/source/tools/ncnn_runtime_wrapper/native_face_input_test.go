package main

import (
	"reflect"
	"testing"
)

func TestNativeFaceEmbedInputSkipsDetectorPreparation(t *testing.T) {
	bundleDir := writeNativeSplitFaceBundleForTest(t)
	profile, ok, err := detectNativeVisionProfile(bundleDir)
	if err != nil || !ok {
		t.Fatalf("face profile: ok=%v err=%v", ok, err)
	}
	input := map[string]interface{}{"image": writeNativeVisionSourceImageForTest(t)}
	detector, err := prepareNativeVisionImageInput(bundleDir, input)
	if err != nil {
		t.Fatal(err)
	}
	for _, task := range []string{"face_embed", " FACE_EMBED "} {
		prepared, err := prepareNativeVisionImageInputForTask(profile, input, task)
		if err != nil {
			t.Fatal(err)
		}
		if len(prepared.pixels) != 0 || prepared.width != 0 || prepared.height != 0 {
			t.Fatalf("%q prepared an unused detector tensor: %dx%d, %d bytes", task, prepared.width, prepared.height, len(prepared.pixels))
		}
		if prepared.sourceImage == nil || prepared.sourceWidth != detector.sourceWidth || prepared.sourceHeight != detector.sourceHeight || !reflect.DeepEqual(prepared.profile, detector.profile) {
			t.Fatalf("%q lost source or embedding profile", task)
		}
		face := nativePerformanceFace()
		got, _, _, err := nativeFaceEmbeddingPixelsForFace(prepared.sourceImage, prepared.profile, face)
		if err != nil {
			t.Fatal(err)
		}
		want, _, _, err := nativeFaceEmbeddingPixelsForFace(detector.sourceImage, detector.profile, face)
		if err != nil || !reflect.DeepEqual(got, want) {
			t.Fatalf("%q changed embedding tensor: %v", task, err)
		}
	}
	for _, task := range []string{"", "face", "face_detect", "detect"} {
		prepared, err := prepareNativeVisionImageInputForTask(profile, input, task)
		if err != nil || !reflect.DeepEqual(prepared.pixels, detector.pixels) || prepared.scale != detector.scale || prepared.padX != detector.padX || prepared.padY != detector.padY {
			t.Fatalf("%q changed detector preparation: %v", task, err)
		}
	}
	profile.faceBundle = false
	prepared, err := prepareNativeVisionImageInputForTask(profile, input, "face_embed")
	if err != nil || len(prepared.pixels) == 0 {
		t.Fatalf("non-face bundle unexpectedly skipped preparation: %v", err)
	}
	for _, invalid := range []map[string]interface{}{nil, {"image": "/does/not/exist.jpg"}} {
		if _, err := prepareNativeVisionImageInputForTask(detector.profile, invalid, "face_embed"); err == nil {
			t.Fatal("face_embed accepted an invalid source")
		}
	}
}
