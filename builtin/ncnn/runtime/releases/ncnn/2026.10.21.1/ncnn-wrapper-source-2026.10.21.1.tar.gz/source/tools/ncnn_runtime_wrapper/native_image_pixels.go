package main

import (
	"bytes"
	"image"
	"image/color"
)

// The resized detector image is already NRGBA. Write its visible RGB directly
// into the padded tensor, avoiding two full four-channel intermediate canvases.
func nativeImageRGBPixelsPadded(src *image.NRGBA, width, height int, position image.Point, padding byte) []byte {
	if width <= 0 || height <= 0 {
		return nil
	}
	pixels := bytes.Repeat([]byte{padding}, width*height*3)
	paste := image.Rectangle{Min: position, Max: position.Add(src.Bounds().Size())}
	visible := paste.Intersect(image.Rect(0, 0, width, height))
	for y := visible.Min.Y; y < visible.Max.Y; y++ {
		xSource := src.Rect.Min.X + visible.Min.X - position.X
		ySource := src.Rect.Min.Y + y - position.Y
		start := src.PixOffset(xSource, ySource)
		row := src.Pix[start : start+4*visible.Dx()]
		dstStart := (y*width + visible.Min.X) * 3
		dst := pixels[dstStart : dstStart+3*visible.Dx()]
		for x, offset := 0, 0; x < len(row); x, offset = x+4, offset+3 {
			dst[offset], dst[offset+1], dst[offset+2] = row[x], row[x+1], row[x+2]
		}
	}
	return pixels
}

func nativeImageRGBPixels(src image.Image, bgr bool) []byte {
	bounds := src.Bounds()
	width, height := bounds.Dx(), bounds.Dy()
	pixels := make([]byte, width*height*3)
	first, last := 0, 2
	if bgr {
		first, last = 2, 0
	}
	if img, ok := src.(*image.NRGBA); ok {
		// Resizing, OCR crops and aligned faces already produce NRGBA. Pack its
		// visible rows directly; At would box one color object for every pixel.
		for y := 0; y < height; y++ {
			start := img.PixOffset(bounds.Min.X, bounds.Min.Y+y)
			row := img.Pix[start : start+4*width]
			dst := pixels[y*3*width : (y+1)*3*width]
			for x, offset := 0, 0; x < len(row); x, offset = x+4, offset+3 {
				dst[offset+first], dst[offset+1], dst[offset+last] = row[x], row[x+1], row[x+2]
			}
		}
		return pixels
	}
	offset := 0
	for y := bounds.Min.Y; y < bounds.Max.Y; y++ {
		for x := bounds.Min.X; x < bounds.Max.X; x++ {
			c := nativeImageNRGBAAt(src, x, y)
			pixels[offset+first], pixels[offset+1], pixels[offset+last] = c.R, c.G, c.B
			offset += 3
		}
	}
	return pixels
}

func nativeImageNRGBAAt(src image.Image, x, y int) color.NRGBA {
	var r, g, b, a uint32
	switch img := src.(type) {
	case *image.NRGBA:
		return img.NRGBAAt(x, y)
	case *image.RGBA:
		value := img.RGBAAt(x, y)
		r, g, b, a = value.RGBA()
	case *image.YCbCr:
		value := img.YCbCrAt(x, y)
		r, g, b, a = value.RGBA()
	case *image.Gray:
		value := img.GrayAt(x, y).Y
		return color.NRGBA{R: value, G: value, B: value, A: 255}
	default:
		return color.NRGBAModel.Convert(src.At(x, y)).(color.NRGBA)
	}
	// Match color.NRGBAModel's 16-bit unpremultiplication and rounding exactly.
	// YCbCr.RGBA also retains its original fixed-point conversion semantics.
	if a == 0 {
		return color.NRGBA{}
	}
	if a != 0xffff {
		r, g, b = r*0xffff/a, g*0xffff/a, b*0xffff/a
	}
	return color.NRGBA{R: uint8(r >> 8), G: uint8(g >> 8), B: uint8(b >> 8), A: uint8(a >> 8)}
}
