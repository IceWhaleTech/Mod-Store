package main

import (
	"bytes"
	"image"
	"image/color"
	"math"
	"testing"
)

type nativePixelFallbackImage struct{ image.Image }

func nativePixelReference(src image.Image, bgr bool) []byte {
	bounds := src.Bounds()
	pixels := make([]byte, bounds.Dx()*bounds.Dy()*3)
	i := 0
	for y := bounds.Min.Y; y < bounds.Max.Y; y++ {
		for x := bounds.Min.X; x < bounds.Max.X; x++ {
			c := color.NRGBAModel.Convert(src.At(x, y)).(color.NRGBA)
			if bgr {
				pixels[i], pixels[i+1], pixels[i+2] = c.B, c.G, c.R
			} else {
				pixels[i], pixels[i+1], pixels[i+2] = c.R, c.G, c.B
			}
			i += 3
		}
	}
	return pixels
}

func nativePixelTestSources() []image.Image {
	parent := image.NewNRGBA(image.Rect(-9, -11, 35, 33))
	for i := 0; i < len(parent.Pix); i += 4 {
		parent.Pix[i], parent.Pix[i+1], parent.Pix[i+2], parent.Pix[i+3] = byte(i*17), byte(i*19), byte(i*23), byte(i/4)
	}
	rect := image.Rect(-3, -5, 19, 16)
	nrgba := parent.SubImage(rect).(*image.NRGBA)
	rgba := image.NewRGBA(rect.Inset(-3))
	for y := rect.Min.Y; y < rect.Max.Y; y++ {
		for x := rect.Min.X; x < rect.Max.X; x++ {
			rgba.Set(x, y, nrgba.At(x, y))
		}
	}
	sources := []image.Image{nrgba, rgba.SubImage(rect), image.NewGray(rect), image.NewNRGBA64(rect), nativePixelFallbackImage{nrgba}}
	for _, ratio := range []image.YCbCrSubsampleRatio{
		image.YCbCrSubsampleRatio444, image.YCbCrSubsampleRatio422,
		image.YCbCrSubsampleRatio420, image.YCbCrSubsampleRatio440,
		image.YCbCrSubsampleRatio411, image.YCbCrSubsampleRatio410,
	} {
		src := image.NewYCbCr(rect.Inset(-3), ratio)
		for _, plane := range [][]byte{src.Y, src.Cb, src.Cr} {
			for i := range plane {
				plane[i] = byte(i * 43)
			}
		}
		sources = append(sources, src.SubImage(rect))
	}
	return sources
}

func TestNativePixelPackingAllocatesOnlyOutput(t *testing.T) {
	src := nativePerformanceImage(64, 43)
	for _, run := range []func() []byte{
		func() []byte { return nativeVisionRGBPixels(src) },
		func() []byte { return rapidOCRPixels(src, false) },
		func() []byte { return rapidOCRPixels(src, true) },
	} {
		allocs := testing.AllocsPerRun(5, func() {
			if len(run()) != 64*43*3 {
				t.Fatal("invalid RGB output")
			}
		})
		if allocs > 1 {
			t.Fatalf("pixel packing still allocates per-pixel color objects: %.0f allocations", allocs)
		}
	}
}

func TestNativePixelPackingPreservesChannelsAlphaBoundsAndOwnership(t *testing.T) {
	for _, src := range nativePixelTestSources() {
		for _, bgr := range []bool{false, true} {
			want := nativePixelReference(src, bgr)
			got := rapidOCRPixels(src, bgr)
			if !bytes.Equal(got, want) {
				t.Fatalf("%T bounds=%s bgr=%t: packed pixels changed", src, src.Bounds(), bgr)
			}
			if !bgr && !bytes.Equal(nativeVisionRGBPixels(src), want) {
				t.Fatalf("%T: vision RGB differs from original conversion", src)
			}
			if len(got) > 0 {
				got[0] ^= 0xff
				if !bytes.Equal(rapidOCRPixels(src, bgr), want) {
					t.Fatal("packed output aliases source pixels")
				}
			}
		}
	}
}

func TestNativeBilinearSamplingDoesNotAllocateColors(t *testing.T) {
	sources := nativePixelTestSources()
	for _, src := range []image.Image{sources[0], sources[1], sources[5]} {
		for _, sample := range []func(image.Image, float64, float64) color.NRGBA{nativeFaceBilinearSample, rapidOCRBilinearSample} {
			allocs := testing.AllocsPerRun(10, func() { sample(src, 2.25, 3.75) })
			if allocs != 0 {
				t.Fatalf("%T: bilinear sampling still allocates colors: %.0f", src, allocs)
			}
		}
	}
}

// This preserves the two original interpolation formulas independently. Face
// alignment pads outside the source with opaque black; OCR clamps to its edge.
func nativeBilinearReference(src image.Image, x, y float64, face bool) color.NRGBA {
	bounds := src.Bounds()
	if face && (x < float64(bounds.Min.X) || y < float64(bounds.Min.Y) || x > float64(bounds.Max.X-1) || y > float64(bounds.Max.Y-1)) {
		return color.NRGBA{A: 255}
	}
	if !face {
		x = math.Max(float64(bounds.Min.X), math.Min(x, float64(bounds.Max.X-1)))
		y = math.Max(float64(bounds.Min.Y), math.Min(y, float64(bounds.Max.Y-1)))
	}
	x0, y0 := int(math.Floor(x)), int(math.Floor(y))
	x1, y1 := min(x0+1, bounds.Max.X-1), min(y0+1, bounds.Max.Y-1)
	wx, wy := x-float64(x0), y-float64(y0)
	colors := [4]color.NRGBA{
		color.NRGBAModel.Convert(src.At(x0, y0)).(color.NRGBA), color.NRGBAModel.Convert(src.At(x1, y0)).(color.NRGBA),
		color.NRGBAModel.Convert(src.At(x0, y1)).(color.NRGBA), color.NRGBAModel.Convert(src.At(x1, y1)).(color.NRGBA),
	}
	channel := func(a, b, c, d uint8) uint8 {
		if face {
			top := float64(a)*(1-wx) + float64(b)*wx
			bottom := float64(c)*(1-wx) + float64(d)*wx
			return uint8(math.Round(top*(1-wy) + bottom*wy))
		}
		top := float64(a) + (float64(b)-float64(a))*wx
		bottom := float64(c) + (float64(d)-float64(c))*wx
		return uint8(math.Round(top + (bottom-top)*wy))
	}
	alpha := uint8(255)
	if !face {
		alpha = channel(colors[0].A, colors[1].A, colors[2].A, colors[3].A)
	}
	return color.NRGBA{
		R: channel(colors[0].R, colors[1].R, colors[2].R, colors[3].R),
		G: channel(colors[0].G, colors[1].G, colors[2].G, colors[3].G),
		B: channel(colors[0].B, colors[1].B, colors[2].B, colors[3].B), A: alpha,
	}
}

func TestNativeBilinearSamplingPreservesInterpolationAndBorders(t *testing.T) {
	for _, src := range nativePixelTestSources() {
		for y := -7.25; y < 18; y += 1.17 {
			for x := -5.5; x < 21; x += 1.13 {
				if got, want := nativeFaceBilinearSample(src, x, y), nativeBilinearReference(src, x, y, true); got != want {
					t.Fatalf("face %T at %.2f,%.2f: %v want %v", src, x, y, got, want)
				}
				if got, want := rapidOCRBilinearSample(src, x, y), nativeBilinearReference(src, x, y, false); got != want {
					t.Fatalf("OCR %T at %.2f,%.2f: %v want %v", src, x, y, got, want)
				}
			}
		}
	}
}
