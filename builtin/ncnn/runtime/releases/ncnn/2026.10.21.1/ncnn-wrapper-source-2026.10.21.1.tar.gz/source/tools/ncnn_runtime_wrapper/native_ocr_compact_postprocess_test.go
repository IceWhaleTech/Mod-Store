package main

import (
	"math"
	"math/rand"
	"reflect"
	"runtime"
	"testing"
)

func TestNativeOCRBlankPostprocessAvoidsAllocation(t *testing.T) {
	values, width, height := nativeOCRProbabilityMap("blank")
	allocations := testing.AllocsPerRun(8, func() {
		boxes := nativeOCRPostprocess(values, width, height)
		if boxes == nil || len(boxes) != 0 {
			t.Fatal("empty valid probability map must return a non-nil empty result")
		}
	})
	if allocations != 0 {
		t.Fatalf("blank map allocates %.0f times/image, want 0", allocations)
	}
}

func TestNativeOCRCompactPostprocessAllocationBudget(t *testing.T) {
	for _, tc := range []struct {
		kind  string
		limit uint64
	}{{"text", 200_000}, {"many", 400_000}} {
		t.Run(tc.kind, func(t *testing.T) {
			values, width, height := nativeOCRProbabilityMap(tc.kind)
			runtime.GC()
			var before, after runtime.MemStats
			runtime.ReadMemStats(&before)
			for i := 0; i < 3; i++ {
				if len(nativeOCRPostprocess(values, width, height)) == 0 {
					t.Fatal("missing boxes")
				}
			}
			runtime.ReadMemStats(&after)
			if allocated := (after.TotalAlloc - before.TotalAlloc) / 3; allocated > tc.limit {
				t.Fatalf("postprocess allocates %d bytes/image, budget %d", allocated, tc.limit)
			}
		})
	}
}

func TestNativeOCROrderedRectPointsAvoidsAllocation(t *testing.T) {
	rect := rapidOCRRotatedRect{center: rapidOCRPoint{x: 5, y: 7}, axisWidth: rapidOCRPoint{x: 1}, axisHeight: rapidOCRPoint{y: 1}, halfWidth: 3, halfHeight: 2}
	allocations := testing.AllocsPerRun(10, func() {
		if points := rapidOCROrderedRectPoints(rect); points[0].x != 2 || points[0].y != 5 {
			t.Fatal("invalid ordered rectangle")
		}
	})
	if allocations != 0 {
		t.Fatalf("corner ordering allocates %.0f times/box, want 0", allocations)
	}
}

func TestNativeOCROrderedRectPointsMatchesFrozenImplementation(t *testing.T) {
	rng := rand.New(rand.NewSource(132026))
	var rectangles []rapidOCRRotatedRect
	for _, angle := range []float64{0, math.Pi / 4, math.Pi / 2, math.Pi, -math.Pi / 4} {
		for _, size := range []float64{0, 1, -1, 1e-10, 1e10} {
			rectangles = append(rectangles, rapidOCRRotatedRect{center: rapidOCRPoint{x: -3, y: 4}, axisWidth: rapidOCRPoint{x: math.Cos(angle), y: math.Sin(angle)}, axisHeight: rapidOCRPoint{x: -math.Sin(angle), y: math.Cos(angle)}, halfWidth: size, halfHeight: size})
		}
	}
	for _, value := range []float64{math.Copysign(0, -1), math.NaN(), math.Inf(1), math.Inf(-1)} {
		rectangles = append(rectangles, rapidOCRRotatedRect{center: rapidOCRPoint{x: value, y: value}, axisWidth: rapidOCRPoint{x: 1}, axisHeight: rapidOCRPoint{y: 1}, halfWidth: 3, halfHeight: 2})
	}
	for i := 0; i < 1000; i++ {
		angle := rng.Float64() * 2 * math.Pi
		rectangles = append(rectangles, rapidOCRRotatedRect{center: rapidOCRPoint{x: rng.Float64() * 1000, y: rng.Float64() * 1000}, axisWidth: rapidOCRPoint{x: math.Cos(angle), y: math.Sin(angle)}, axisHeight: rapidOCRPoint{x: -math.Sin(angle), y: math.Cos(angle)}, halfWidth: rng.Float64() * 100, halfHeight: rng.Float64() * 100})
	}
	for i, rect := range rectangles {
		got, want := rapidOCROrderedRectPoints(rect), referenceRapidOCROrderedRectPoints(rect)
		for j := range got {
			if nativeOCRPointBits(got[j]) != nativeOCRPointBits(want[j]) {
				t.Fatalf("rectangle %d point %d changed: %#v != %#v", i, j, got[j], want[j])
			}
		}
	}
}

func TestNativeOCRVisitedAcrossWordAndRowBoundaries(t *testing.T) {
	for _, width := range []int{1, 2, 63, 64, 65, 127, 129} {
		const height = 65
		values := make([]float32, width*height)
		for i := range values {
			if i%5 != 2 {
				values[i] = .75
			}
		}
		gotVisited, wantVisited := make([]uint64, (len(values)+63)/64), make([]bool, len(values))
		var component []int
		for start := range values {
			if wantVisited[start] || values[start] <= .5 {
				continue
			}
			component = rapidOCRDetectorComponent(values, width, height, start, .5, gotVisited, component)
			want := referenceRapidOCRDetectorComponent(values, width, height, start, .5, wantVisited)
			if !reflect.DeepEqual(component, want) {
				t.Fatalf("width %d: BFS order changed", width)
			}
		}
		for index, want := range wantVisited {
			if got := gotVisited[index>>6]&(uint64(1)<<(index&63)) != 0; got != want {
				t.Fatalf("width %d: visited pixel %d changed", width, index)
			}
		}
	}
}
