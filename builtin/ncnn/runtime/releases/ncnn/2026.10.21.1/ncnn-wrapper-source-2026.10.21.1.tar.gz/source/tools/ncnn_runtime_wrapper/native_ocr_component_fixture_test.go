package main

// Legacy full-component helpers only construct existing geometry/traversal
// fixtures. Production uses the streaming frontier tested independently.
func rapidOCRDetectorComponent(probabilities []float32, width, height, start int, threshold float64, visited []uint64, component []int) []int {
	// The queue already contains every component pixel in BFS order.
	component = append(component[:0], start)
	visited[start>>6] |= uint64(1) << (start & 63)
	for head := 0; head < len(component); head++ {
		index := component[head]
		x, y := index%width, index/width
		for offsetY := -1; offsetY <= 1; offsetY++ {
			for offsetX := -1; offsetX <= 1; offsetX++ {
				if offsetX == 0 && offsetY == 0 {
					continue
				}
				nextX, nextY := x+offsetX, y+offsetY
				if nextX < 0 || nextX >= width || nextY < 0 || nextY >= height {
					continue
				}
				next := nextY*width + nextX
				mask := uint64(1) << (next & 63)
				if visited[next>>6]&mask != 0 || float64(probabilities[next]) <= threshold {
					continue
				}
				visited[next>>6] |= mask
				component = append(component, next)
			}
		}
	}
	return component
}

func rapidOCRComponentBoundary(component []int, probabilities []float32, width, height int, threshold float64, points []rapidOCRPoint) []rapidOCRPoint {
	// Interior pixels contribute no corners; grow only for actual boundary
	// points instead of reserving one point for every component pixel.
	points = points[:0]
	for _, index := range component {
		x, y := index%width, index/width
		boundary := x == 0 || x == width-1 || y == 0 || y == height-1
		if !boundary {
			for _, neighbor := range []int{index - 1, index + 1, index - width, index + width} {
				if float64(probabilities[neighbor]) <= threshold {
					boundary = true
					break
				}
			}
		}
		if boundary {
			points = append(points,
				rapidOCRPoint{x: float64(x), y: float64(y)},
				rapidOCRPoint{x: float64(x + 1), y: float64(y)},
				rapidOCRPoint{x: float64(x + 1), y: float64(y + 1)},
				rapidOCRPoint{x: float64(x), y: float64(y + 1)},
			)
		}
	}
	return points
}
