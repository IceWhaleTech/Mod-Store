package main

import (
	"bytes"
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"math"
	"math/rand"
	"runtime"
	"sync"
	"testing"
)

// Freeze the pre-optimization geometry, generic color conversion and rotation.
// Keep the oracle independent of the production interpolation helpers.
func referenceRapidOCRCrop(source image.Image, box rapidOCRDetBox) (*image.NRGBA, error) {
	if source == nil || source.Bounds().Dx() <= 0 || source.Bounds().Dy() <= 0 {
		return nil, fmt.Errorf("rapidocr crop source image is empty")
	}
	points := box.points
	width := int(math.Round(math.Max(math.Hypot(points[1].x-points[0].x, points[1].y-points[0].y), math.Hypot(points[2].x-points[3].x, points[2].y-points[3].y))))
	height := int(math.Round(math.Max(math.Hypot(points[3].x-points[0].x, points[3].y-points[0].y), math.Hypot(points[2].x-points[1].x, points[2].y-points[1].y))))
	if width <= 0 || height <= 0 {
		return nil, fmt.Errorf("rapidocr crop box has zero area")
	}
	lerp := func(first, second rapidOCRPoint, amount float64) rapidOCRPoint {
		return rapidOCRPoint{x: first.x + (second.x-first.x)*amount, y: first.y + (second.y-first.y)*amount}
	}
	crop := image.NewNRGBA(image.Rect(0, 0, width, height))
	for y := 0; y < height; y++ {
		v := 0.0
		if height > 1 {
			v = float64(y) / float64(height-1)
		}
		for x := 0; x < width; x++ {
			u := 0.0
			if width > 1 {
				u = float64(x) / float64(width-1)
			}
			top := lerp(points[0], points[1], u)
			bottom := lerp(points[3], points[2], u)
			p := lerp(top, bottom, v)
			crop.SetNRGBA(x, y, referenceRapidOCRSample(source, p.x, p.y))
		}
	}
	if float64(height) >= float64(width)*1.5 {
		rotated := image.NewNRGBA(image.Rect(0, 0, height, width))
		for y := 0; y < height; y++ {
			for x := 0; x < width; x++ {
				rotated.SetNRGBA(height-1-y, x, crop.NRGBAAt(x, y))
			}
		}
		return rotated, nil
	}
	return crop, nil
}

func referenceRapidOCRSample(source image.Image, x, y float64) color.NRGBA {
	bounds := source.Bounds()
	x = math.Max(float64(bounds.Min.X), math.Min(x, float64(bounds.Max.X-1)))
	y = math.Max(float64(bounds.Min.Y), math.Min(y, float64(bounds.Max.Y-1)))
	x0, y0 := int(math.Floor(x)), int(math.Floor(y))
	x1, y1 := min(x0+1, bounds.Max.X-1), min(y0+1, bounds.Max.Y-1)
	xWeight, yWeight := x-float64(x0), y-float64(y0)
	values := [4]color.NRGBA{
		color.NRGBAModel.Convert(source.At(x0, y0)).(color.NRGBA),
		color.NRGBAModel.Convert(source.At(x1, y0)).(color.NRGBA),
		color.NRGBAModel.Convert(source.At(x0, y1)).(color.NRGBA),
		color.NRGBAModel.Convert(source.At(x1, y1)).(color.NRGBA),
	}
	interpolate := func(first, second uint8, weight float64) float64 {
		return float64(first) + (float64(second)-float64(first))*weight
	}
	channel := func(index func(color.NRGBA) uint8) uint8 {
		top := interpolate(index(values[0]), index(values[1]), xWeight)
		bottom := interpolate(index(values[2]), index(values[3]), xWeight)
		return uint8(math.Round(top + (bottom-top)*yWeight))
	}
	return color.NRGBA{
		R: channel(func(c color.NRGBA) uint8 { return c.R }),
		G: channel(func(c color.NRGBA) uint8 { return c.G }),
		B: channel(func(c color.NRGBA) uint8 { return c.B }),
		A: channel(func(c color.NRGBA) uint8 { return c.A }),
	}
}

func nativeOCRCropSources() []image.Image {
	base := image.NewNRGBA(image.Rect(-15, -12, 55, 60))
	for i := range base.Pix {
		base.Pix[i] = byte((i*83 + i/7) % 256)
	}
	sub := base.SubImage(image.Rect(-9, -7, 39, 41)).(*image.NRGBA)
	rgba := image.NewRGBA(base.Rect)
	gray := image.NewGray(base.Rect)
	nrgba64 := image.NewNRGBA64(base.Rect)
	ycbcr := image.NewYCbCr(base.Rect, image.YCbCrSubsampleRatio420)
	for i := range ycbcr.Y {
		ycbcr.Y[i] = byte(i * 31)
	}
	for i := range ycbcr.Cb {
		ycbcr.Cb[i], ycbcr.Cr[i] = byte(i*53), byte(i*71)
	}
	for _, dst := range []draw.Image{rgba, gray, nrgba64} {
		draw.Draw(dst, dst.Bounds(), base, base.Rect.Min, draw.Src)
	}
	// Hide the concrete type to exercise the generic image.Image fallback.
	return []image.Image{base, sub, rgba, gray, nrgba64, ycbcr, struct{ image.Image }{sub}, image.NewNRGBA(image.Rect(7, 9, 8, 10))}
}

func TestNativeOCRCropExactPixels(t *testing.T) {
	boxes := []rapidOCRDetBox{
		{points: [4]rapidOCRPoint{{0, 0}, {20, 0}, {20, 14}, {0, 14}}},
		{points: [4]rapidOCRPoint{{-6, -5}, {9.4, -3}, {7.7, 29.3}, {-8.2, 24}}},
		{points: [4]rapidOCRPoint{{-50, -40}, {75, -30}, {60, 70}, {-40, 80}}},
		{points: [4]rapidOCRPoint{{2, 3}, {3, 3}, {3, 23}, {2, 23}}},
		{points: [4]rapidOCRPoint{{2, 3}, {22, 3}, {22, 4}, {2, 4}}},
		{points: [4]rapidOCRPoint{{2, 3}, {3, 3}, {3, 4}, {2, 4}}},
		{points: [4]rapidOCRPoint{{0, 0}, {10, 0}, {10, 14}, {0, 14}}},
		{points: [4]rapidOCRPoint{{0, 0}, {10, 0}, {10, 15}, {0, 15}}},
		{points: [4]rapidOCRPoint{{0, 0}, {10, 0}, {10, 16}, {0, 16}}},
	}
	random := rand.New(rand.NewSource(14))
	for i := 0; i < 80; i++ {
		var box rapidOCRDetBox
		for j := range box.points {
			box.points[j] = rapidOCRPoint{x: random.Float64()*80 - 25, y: random.Float64()*80 - 25}
		}
		boxes = append(boxes, box)
	}
	for _, source := range nativeOCRCropSources() {
		for index, box := range boxes {
			got, err := rapidOCRCropImage(source, box)
			want, wantErr := referenceRapidOCRCrop(source, box)
			if err != nil || wantErr != nil || got.Rect != want.Rect || got.Stride != want.Stride || !bytes.Equal(got.Pix, want.Pix) {
				t.Fatalf("source=%T bounds=%s box=%d: exact crop mismatch, errors %v / %v", source, source.Bounds(), index, err, wantErr)
			}
		}
	}
}

func TestNativeOCRBilinearSampleEdgeCoordinates(t *testing.T) {
	coordinates := [][2]float64{
		{0, 0}, {0.5, 0.5}, {-8.5, -6.5}, {38.9999999, 40.9999999},
		{math.NaN(), 0}, {0, math.NaN()}, {math.Inf(-1), math.Inf(1)},
		{math.Inf(1), math.Inf(-1)}, {math.Copysign(0, -1), 0},
	}
	sources := append(nativeOCRCropSources(), image.NewNRGBA(image.Rectangle{}))
	for sourceIndex, source := range sources {
		for index, point := range coordinates {
			t.Run(fmt.Sprintf("source%d/coordinate%d", sourceIndex, index), func(t *testing.T) {
				got := rapidOCRBilinearSample(source, point[0], point[1])
				want := referenceRapidOCRSample(source, point[0], point[1])
				if got != want {
					t.Fatalf("sample %v: got %v, want %v", point, got, want)
				}
			})
		}
	}
}

func TestNativeOCRCropTallAllocatesSingleCanvas(t *testing.T) {
	src := nativePerformanceImage(512, 512)
	box := rapidOCRDetBox{points: [4]rapidOCRPoint{{40, 40}, {120, 40}, {120, 360}, {40, 360}}}
	var result *image.NRGBA
	var cropErr error
	allocs := testing.AllocsPerRun(10, func() { result, cropErr = rapidOCRCropImage(src, box) })
	if cropErr != nil || result.Rect != image.Rect(0, 0, 320, 80) {
		t.Fatalf("tall crop: %v, result %v", cropErr, result)
	}
	if allocs > 2 {
		t.Errorf("tall crop allocates a temporary canvas: %.0f allocations, want at most 2", allocs)
	}
	runtime.GC()
	var before, after runtime.MemStats
	runtime.ReadMemStats(&before)
	for i := 0; i < 10; i++ {
		result, cropErr = rapidOCRCropImage(src, box)
		if cropErr != nil {
			t.Fatal(cropErr)
		}
	}
	runtime.ReadMemStats(&after)
	if allocated := (after.TotalAlloc - before.TotalAlloc) / 10; allocated > uint64(len(result.Pix)+16*1024) {
		t.Errorf("tall crop allocated %d bytes/image for %d output bytes", allocated, len(result.Pix))
	}
}

func TestNativeOCRCropErrorsAndOwnership(t *testing.T) {
	box := rapidOCRDetBox{points: [4]rapidOCRPoint{{2, 3}, {8, 3}, {8, 20}, {2, 20}}}
	for _, source := range []image.Image{nil, image.NewNRGBA(image.Rectangle{})} {
		if _, err := rapidOCRCropImage(source, box); err == nil {
			t.Fatal("empty source accepted")
		}
	}
	src := nativePerformanceImage(48, 48)
	if _, err := rapidOCRCropImage(src, rapidOCRDetBox{}); err == nil {
		t.Fatal("zero-area box accepted")
	}
	before := append([]byte(nil), src.Pix...)
	want, err := referenceRapidOCRCrop(src, box)
	if err != nil {
		t.Fatal(err)
	}
	var pending sync.WaitGroup
	for i := 0; i < 8; i++ {
		pending.Add(1)
		go func() {
			defer pending.Done()
			got, err := rapidOCRCropImage(src, box)
			if err != nil || !bytes.Equal(got.Pix, want.Pix) {
				t.Error("concurrent crop changed result", err)
				return
			}
			got.Pix[0] ^= 255
		}()
	}
	pending.Wait()
	if !bytes.Equal(src.Pix, before) {
		t.Fatal("crop mutated source")
	}
}

func BenchmarkNativeOCRCropSingleRegion(b *testing.B) {
	_, jpegSource := nativePerformanceJPEG(b, 512, 512)
	for _, kind := range []string{"nrgba", "jpeg"} {
		var source image.Image = nativePerformanceImage(512, 512)
		if kind == "jpeg" {
			source = jpegSource
		}
		for _, orientation := range []string{"horizontal", "vertical"} {
			box := rapidOCRDetBox{points: [4]rapidOCRPoint{{40, 40}, {360, 50}, {355, 130}, {35, 120}}}
			if orientation == "vertical" {
				box = rapidOCRDetBox{points: [4]rapidOCRPoint{{40, 40}, {120, 45}, {130, 365}, {50, 360}}}
			}
			b.Run(kind+"/"+orientation, func(b *testing.B) {
				b.ReportAllocs()
				for i := 0; i < b.N; i++ {
					if _, err := rapidOCRCropImage(source, box); err != nil {
						b.Fatal(err)
					}
				}
			})
		}
	}
}
