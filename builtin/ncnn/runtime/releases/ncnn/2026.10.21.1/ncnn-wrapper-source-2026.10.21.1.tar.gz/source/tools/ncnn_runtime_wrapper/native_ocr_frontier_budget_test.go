package main

import (
	"runtime"
	"testing"
)

func TestNativeOCRFrontierPostprocessAllocationBudget(t *testing.T) {
	for _, tc := range []struct {
		kind  string
		limit uint64
	}{{"text", 105_000}, {"dense", 2_000_000}} {
		t.Run(tc.kind, func(t *testing.T) {
			values, width, height := nativeOCRProbabilityMap(tc.kind)
			runtime.GC()
			var before, after runtime.MemStats
			runtime.ReadMemStats(&before)
			for i := 0; i < 3; i++ {
				if len(nativeOCRPostprocess(values, width, height)) == 0 {
					t.Fatal("missing boxes")
				}
			}
			runtime.ReadMemStats(&after)
			if allocated := (after.TotalAlloc - before.TotalAlloc) / 3; allocated > tc.limit {
				t.Fatalf("retaining the full component costs %d bytes/image, budget %d", allocated, tc.limit)
			}
		})
	}
}
