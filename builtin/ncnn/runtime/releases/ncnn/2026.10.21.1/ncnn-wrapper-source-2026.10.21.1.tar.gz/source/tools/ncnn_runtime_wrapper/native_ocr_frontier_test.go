package main

import (
	"math"
	"math/rand"
	"reflect"
	"testing"
)

func TestNativeOCRFrontierFIFO(t *testing.T) {
	var scratch rapidOCRComponentScratch
	for i := 0; i < 64; i++ {
		scratch.push(i)
	}
	for i := 0; i < 48; i++ {
		if got := scratch.pop(); got != i {
			t.Fatalf("initial pop %d != %d", got, i)
		}
	}
	// Grow a full wrapped buffer: both occupied spans must retain FIFO order.
	for i := 64; i <= 112; i++ {
		scratch.push(i)
	}
	for i := 48; i <= 112; i++ {
		if got := scratch.pop(); got != i {
			t.Fatalf("wrapped pop %d != %d", got, i)
		}
	}
	var want []int
	head := 0
	random := rand.New(rand.NewSource(162026))
	for i := 0; i < 20_000; i++ {
		if head == len(want) || random.Intn(5) < 3 {
			scratch.push(i)
			want = append(want, i)
		} else {
			if got := scratch.pop(); got != want[head] {
				t.Fatalf("random pop %d != %d", got, want[head])
			}
			head++
		}
		if scratch.pending != len(want)-head {
			t.Fatal("pending count changed")
		}
	}
	for ; head < len(want); head++ {
		if got := scratch.pop(); got != want[head] {
			t.Fatal("drain order changed")
		}
	}
	if scratch.pending != 0 {
		t.Fatal("frontier did not drain")
	}
	if allocs := testing.AllocsPerRun(10, func() {
		for i := 0; i < 4096; i++ {
			scratch.push(i)
		}
		for i := 0; i < 4096; i++ {
			if scratch.pop() != i {
				t.Fatal("reused queue changed order")
			}
		}
	}); allocs != 0 {
		t.Fatalf("warm frontier allocates %.0f times", allocs)
	}
}

func TestNativeOCRTraceComponentMatchesFrozenTraversal(t *testing.T) {
	var scratch rapidOCRComponentScratch
	check := func(values []float32, width, height int, threshold float64) {
		t.Helper()
		visited := make([]uint64, (len(values)+63)/64)
		wantVisited := make([]bool, len(values))
		before := make([]uint32, len(values))
		for i, value := range values {
			before[i] = math.Float32bits(value)
		}
		for start, value := range values {
			if float64(value) <= threshold || wantVisited[start] {
				continue
			}
			component := referenceRapidOCRDetectorComponent(values, width, height, start, threshold, wantVisited)
			wantBoundary := referenceRapidOCRComponentBoundary(component, values, width, height, threshold)
			var wantScore float64
			for _, index := range component {
				wantScore += float64(values[index])
			}
			count, score := rapidOCRTraceComponent(values, width, height, start, threshold, visited, &scratch)
			if count != len(component) || math.Float64bits(score) != math.Float64bits(wantScore) || !reflect.DeepEqual(scratch.boundary, wantBoundary) {
				t.Fatalf("%dx%d start=%d: count %d/%d, score bits %x/%x, boundary equal=%t", width, height, start, count, len(component), math.Float64bits(score), math.Float64bits(wantScore), reflect.DeepEqual(scratch.boundary, wantBoundary))
			}
			if scratch.pending != 0 {
				t.Fatal("tracing left pending pixels")
			}
			for index, want := range wantVisited {
				if got := visited[index>>6]&(uint64(1)<<(index&63)) != 0; got != want {
					t.Fatalf("visited pixel %d changed", index)
				}
			}
		}
		for i, value := range values {
			if math.Float32bits(value) != before[i] {
				t.Fatal("source probability changed")
			}
		}
	}
	for _, width := range []int{1, 2, 63, 64, 65, 127, 129} {
		const height = 65
		for pattern := 0; pattern < 4; pattern++ {
			values := make([]float32, width*height)
			random := rand.New(rand.NewSource(int64(width*16 + pattern)))
			for y := 0; y < height; y++ {
				for x := 0; x < width; x++ {
					active := pattern == 0 || pattern == 1 && (y%7 == 0 || x%11 == 0) || pattern == 2 && (x == y || x == width-1) || pattern == 3 && random.Intn(5) > 1
					if active {
						values[y*width+x] = .5 + float32(random.Intn(4096))/8192
					}
				}
			}
			check(values, width, height, .3)
		}
	}
	values := []float32{.5, 1e30, .5, 0, .25, .75, .5, 0, float32(math.NaN()), float32(math.Inf(1)), .75, 0}
	for _, threshold := range []float64{.3, .5, math.NaN(), math.Inf(1)} {
		check(values, 4, 3, threshold)
	}
	values, width, height := nativeOCRProbabilityMap("dense")
	visited := make([]uint64, (len(values)+63)/64)
	count, _ := rapidOCRTraceComponent(values, width, height, 0, .3, visited, &scratch)
	if count != len(values) || len(scratch.queue) > 8*width || len(scratch.queue) >= len(values)/8 {
		t.Fatalf("dense map retained component-sized queue: %d slots for %d pixels", len(scratch.queue), count)
	}
}
