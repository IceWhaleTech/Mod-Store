package main

import (
	"bytes"
	"fmt"
	"image"
	"image/color"
	"runtime"
	"sync"
	"testing"
	"unsafe"

	"github.com/disintegration/imaging"
)

func nativeOCRFusedDetectorRuntime(values []float32, width, height int, modern bool) *nativeEmbeddingRuntime {
	r := nativeOCROutputRuntime(values, width, height, func(uintptr) {})
	r.loaded = map[string]*nativeEmbeddingModel{modelClassOCR: {net: 7, splitHeadNet: 8, ocrProfile: rapidOCRBundleLayout{modern: modern}}}
	return r
}

func referenceNativeOCRDetectorInput(source image.Image, config rapidOCRInferConfig) (*image.NRGBA, rapidOCRDetectorScale) {
	p := max(config.padding, 0)
	bounds := source.Bounds()
	padded := imaging.Paste(imaging.New(bounds.Dx()+2*p, bounds.Dy()+2*p, color.NRGBA{255, 255, 255, 255}), source, image.Pt(p, p))
	side := config.maxSideLen
	if side <= 0 || side > max(bounds.Dx(), bounds.Dy()) {
		side = max(bounds.Dx(), bounds.Dy())
	}
	side += 2 * p
	ratio := float64(side) / float64(max(padded.Rect.Dx(), padded.Rect.Dy()))
	width := max(32, int(float64(padded.Rect.Dx())*ratio)/32*32)
	height := max(32, int(float64(padded.Rect.Dy())*ratio)/32*32)
	prepared := imaging.Resize(padded, width, height, imaging.Linear)
	return prepared, rapidOCRDetectorScale{sourceWidth: padded.Rect.Dx(), sourceHeight: padded.Rect.Dy(), ratioWidth: float64(width) / float64(padded.Rect.Dx()), ratioHeight: float64(height) / float64(padded.Rect.Dy())}
}

func TestNativeOCRFusedDetectorAllocationBudget(t *testing.T) {
	previous := runtime.GOMAXPROCS(1)
	defer runtime.GOMAXPROCS(previous)
	_, jpeg := nativePerformanceJPEG(t, 768, 512)
	for _, src := range []image.Image{nativePerformanceImage(768, 512), jpeg, nativePerformanceImage(1536, 1024)} {
		t.Run(fmt.Sprintf("%T/%v", src, src.Bounds().Size()), func(t *testing.T) {
			config := rapidOCRInferConfig{padding: 50, maxSideLen: 960, boxThresh: .3, boxScoreThresh: .6, unclipRatio: 1.6, detOnly: true}
			want, _ := referenceNativeOCRDetectorInput(src, config)
			r := nativeOCRFusedDetectorRuntime([]float32{0}, 1, 1, false)
			runtime.GC()
			var before, after runtime.MemStats
			runtime.ReadMemStats(&before)
			for i := 0; i < 3; i++ {
				boxes, lines, err := r.inferRapidOCR(modelClassOCR, src, config)
				if err != nil || len(boxes) != 0 || lines != nil {
					t.Fatalf("invalid detector result: %v %v %v", boxes, lines, err)
				}
			}
			runtime.ReadMemStats(&after)
			limit := uint64(len(want.Pix) + 512*1024)
			if got := (after.TotalAlloc - before.TotalAlloc) / 3; got > limit {
				t.Fatalf("detector allocated %d bytes/image, budget %d; full padded canvas remains", got, limit)
			}
		})
	}
}

func TestNativeOCRFusedDetectorMatchesOriginalInput(t *testing.T) {
	defer runtime.GOMAXPROCS(runtime.GOMAXPROCS(0))
	sources := append(nativePixelTestSources(), nativePerformanceImage(1, 1), nativePerformanceImage(71, 45), nativePerformanceImage(768, 512), nativePerformanceImage(764, 508))
	configCases := []rapidOCRInferConfig{
		{padding: -1, maxSideLen: 0}, {padding: 0, maxSideLen: 32}, {padding: 1, maxSideLen: 63},
		{padding: 50, maxSideLen: 960}, {padding: 50, maxSideLen: 1280}, {padding: 3, maxSideLen: 17},
	}
	probabilities, width, height := nativeOCRProbabilityMap("text")
	for _, procs := range []int{1, 4} {
		runtime.GOMAXPROCS(procs)
		for _, src := range sources {
			before := imaging.Clone(src)
			for _, config := range configCases {
				want, scale := referenceNativeOCRDetectorInput(src, config)
				scale.ratioWidth = float64(width) / float64(scale.sourceWidth)
				scale.ratioHeight = float64(height) / float64(scale.sourceHeight)
				config.detOnly, config.boxThresh, config.boxScoreThresh, config.unclipRatio = true, .3, .6, 1.6
				wantBoxes := referenceRapidOCRBoxesFromProbabilityMap(probabilities, width, height, scale, config.boxScoreThresh, config.boxThresh, config.unclipRatio)
				for _, modern := range []bool{false, true} {
					r := nativeOCRFusedDetectorRuntime(probabilities, width, height, modern)
					calls := 0
					r.base.bindings.matFromPixels = func(pixels *byte, pixelType, w, h, stride int32, _ uintptr) uintptr {
						calls++
						wantType := nativeMatPixelRGBA2RGB
						if modern {
							wantType = nativeMatPixelRGBA2BGR
						}
						if pixelType != wantType || int(w) != want.Rect.Dx() || int(h) != want.Rect.Dy() || int(stride) != want.Stride {
							t.Errorf("%T cpu=%d: dimensions/channel changed", src, procs)
							return 1
						}
						if !bytes.Equal(unsafe.Slice(pixels, len(want.Pix)), want.Pix) {
							t.Errorf("%T bounds=%v padding=%d max=%d: pixels changed", src, src.Bounds(), config.padding, config.maxSideLen)
						}
						return 1
					}
					got, lines, err := r.inferRapidOCR(modelClassOCR, src, config)
					if err != nil || calls != 1 || lines != nil {
						t.Fatalf("error=%v calls=%d lines=%v", err, calls, lines)
					}
					assertNativeOCRBoxesEqual(t, got, wantBoxes)
				}
				if !bytes.Equal(imaging.Clone(src).Pix, before.Pix) {
					t.Fatal("source changed")
				}
			}
		}
	}
}

func TestNativeOCRFusedDetectorConcurrentOwnership(t *testing.T) {
	_, src := nativePerformanceJPEG(t, 193, 129)
	config := rapidOCRInferConfig{padding: 50, maxSideLen: 1280, detOnly: true, boxThresh: .3}
	before := imaging.Clone(src)
	want, _ := referenceNativeOCRDetectorInput(src, config)
	var wg sync.WaitGroup
	for i := 0; i < 8; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			r := nativeOCRFusedDetectorRuntime([]float32{0}, 1, 1, false)
			r.base.bindings.matFromPixels = func(p *byte, _ int32, w, h, stride int32, _ uintptr) uintptr {
				if int(w) != want.Rect.Dx() || int(h) != want.Rect.Dy() || int(stride) != want.Stride || !bytes.Equal(unsafe.Slice(p, len(want.Pix)), want.Pix) {
					t.Error("concurrent tensor differs")
				}
				return 1
			}
			if _, _, err := r.inferRapidOCR(modelClassOCR, src, config); err != nil {
				t.Error(err)
			}
		}()
	}
	wg.Wait()
	if !bytes.Equal(imaging.Clone(src).Pix, before.Pix) {
		t.Fatal("concurrent source changed")
	}
}

func TestNativeOCRFusedDetectorPreservesOverflowedSizeError(t *testing.T) {
	r := nativeOCRFusedDetectorRuntime([]float32{0}, 1, 1, false)
	padding := int(^uint(0)>>1)/2 + 1
	_, _, err := r.inferRapidOCR(modelClassOCR, nativePerformanceImage(2, 2), rapidOCRInferConfig{padding: padding, detOnly: true})
	if err == nil || err.Error() != "rapidocr detector source image is empty" {
		t.Fatalf("overflowed padded dimensions lost original error: %v", err)
	}
}

func BenchmarkNativeOCRFusedDetector(b *testing.B) {
	_, jpeg := nativePerformanceJPEG(b, 768, 512)
	_, large := nativePerformanceJPEG(b, 1536, 1024)
	_, aligned := nativePerformanceJPEG(b, 764, 508)
	for _, tc := range []struct {
		name    string
		src     image.Image
		detOnly bool
	}{
		{"nrgba", nativePerformanceImage(768, 512), true}, {"jpeg", jpeg, true}, {"large-jpeg", large, true},
		{"aligned-jpeg-control", aligned, true}, {"full-jpeg-control", jpeg, false},
	} {
		b.Run(tc.name, func(b *testing.B) {
			r := nativeOCRFusedDetectorRuntime([]float32{0}, 1, 1, false)
			config := rapidOCRInferConfig{padding: 50, maxSideLen: 960, detOnly: tc.detOnly, boxThresh: .3, boxScoreThresh: .6, unclipRatio: 1.6}
			b.ReportAllocs()
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				boxes, lines, err := r.inferRapidOCR(modelClassOCR, tc.src, config)
				if err != nil || len(boxes) != 0 || lines != nil {
					b.Fatal("invalid detector output", err)
				}
			}
		})
	}
}
