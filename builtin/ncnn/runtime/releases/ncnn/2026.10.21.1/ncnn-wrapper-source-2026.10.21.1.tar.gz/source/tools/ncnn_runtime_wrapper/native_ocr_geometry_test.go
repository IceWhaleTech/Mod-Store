package main

import (
	"math"
	"math/rand"
	"runtime"
	"testing"
)

func TestNativeOCRGeometryAvoidsPerComponentAllocation(t *testing.T) {
	values, width, height := nativeOCRProbabilityMap("text")
	visited := make([]uint64, (len(values)+63)/64)
	start := 8*width + 8
	component := rapidOCRDetectorComponent(values, width, height, start, .3, visited, nil)
	points := rapidOCRComponentBoundary(component, values, width, height, .3, nil)
	work := append([]rapidOCRPoint(nil), points...)
	var scratch rapidOCRGeometryScratch
	allocations := testing.AllocsPerRun(10, func() {
		copy(work, points)
		if _, ok := rapidOCRMinimumAreaRect(work, &scratch); !ok {
			t.Fatal("missing rectangle")
		}
	})
	if allocations != 0 {
		t.Fatalf("geometry allocates %.0f times/component after warmup, want 0", allocations)
	}
}

func TestNativeOCRGeometryPostprocessAllocationBudget(t *testing.T) {
	for _, kind := range []string{"text", "many"} {
		t.Run(kind, func(t *testing.T) {
			values, width, height := nativeOCRProbabilityMap(kind)
			runtime.GC()
			var before, after runtime.MemStats
			runtime.ReadMemStats(&before)
			for i := 0; i < 3; i++ {
				if len(nativeOCRPostprocess(values, width, height)) == 0 {
					t.Fatal("missing boxes")
				}
			}
			runtime.ReadMemStats(&after)
			if allocated := (after.TotalAlloc - before.TotalAlloc) / 3; allocated > 900_000 {
				t.Fatalf("geometry scratch not reused: %d bytes/image, budget 900000", allocated)
			}
		})
	}
}

func TestNativeOCRGeometryMatchesFrozenImplementation(t *testing.T) {
	negativeZero := math.Copysign(0, -1)
	cases := [][]rapidOCRPoint{
		nil, {}, {{x: 1, y: 2}},
		{{x: 1, y: 2}, {x: 1, y: 2}},
		{{x: 1, y: 2}, {x: 2, y: 4}, {x: 3, y: 6}, {x: 1, y: 2}},
		{{x: 0, y: 0}, {x: 5, y: 0}, {x: 5, y: 3}, {x: 0, y: 3}, {x: 3, y: 1}},
		{{x: 0, y: 2}, {x: 2, y: 0}, {x: 4, y: 2}, {x: 2, y: 4}, {x: 2, y: 2}},
		{{x: negativeZero, y: 0}, {x: 0, y: negativeZero}, {x: 2, y: 0}, {x: 2, y: 2}, {x: 0, y: 2}},
		{{x: 0, y: 0}, {x: 1e-10, y: 4}, {x: 1e-10, y: 10}, {x: 0, y: 8}},
		{{x: 1e10, y: 1e10}, {x: 1e10 + 4, y: 1e10}, {x: 1e10 + 4, y: 1e10 + 8}, {x: 1e10, y: 1e10 + 8}},
	}
	// Every point lies on the hull, exercising growth of the combined chain.
	var circle []rapidOCRPoint
	for i := 0; i < 128; i++ {
		angle := 2 * math.Pi * float64(i) / 128
		circle = append(circle, rapidOCRPoint{x: 100 * math.Cos(angle), y: 100 * math.Sin(angle)})
	}
	cases = append(cases, circle)
	rng := rand.New(rand.NewSource(122026))
	for i := 0; i < 100; i++ {
		points := make([]rapidOCRPoint, rng.Intn(512))
		for j := range points {
			points[j] = rapidOCRPoint{x: float64(rng.Intn(100)-50) / 3, y: float64(rng.Intn(60)-30) / 7}
		}
		cases = append(cases, points)
	}
	var scratch rapidOCRGeometryScratch
	for index, points := range cases {
		work := append([]rapidOCRPoint(nil), points...)
		gotHull := rapidOCRConvexHull(work, &scratch)
		wantHull := referenceRapidOCRConvexHull(points)
		if len(gotHull) != len(wantHull) {
			t.Fatalf("case %d: hull length %d != %d", index, len(gotHull), len(wantHull))
		}
		for j := range gotHull {
			if nativeOCRPointBits(gotHull[j]) != nativeOCRPointBits(wantHull[j]) {
				t.Fatalf("case %d: hull point %d changed: %#v != %#v", index, j, gotHull[j], wantHull[j])
			}
		}
		copy(work, points)
		got, gotOK := rapidOCRMinimumAreaRect(work, &scratch)
		want, wantOK := referenceRapidOCRMinimumAreaRect(points)
		if gotOK != wantOK || nativeOCRRectBits(got) != nativeOCRRectBits(want) {
			t.Fatalf("case %d: rectangle changed: %#v/%t != %#v/%t", index, got, gotOK, want, wantOK)
		}
	}
}

func nativeOCRPointBits(point rapidOCRPoint) [2]uint64 {
	return [2]uint64{math.Float64bits(point.x), math.Float64bits(point.y)}
}

func nativeOCRRectBits(rect rapidOCRRotatedRect) [8]uint64 {
	return [8]uint64{
		math.Float64bits(rect.center.x), math.Float64bits(rect.center.y),
		math.Float64bits(rect.axisWidth.x), math.Float64bits(rect.axisWidth.y),
		math.Float64bits(rect.axisHeight.x), math.Float64bits(rect.axisHeight.y),
		math.Float64bits(rect.halfWidth), math.Float64bits(rect.halfHeight),
	}
}
