package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"image"
	"math"
	"os"
	"path/filepath"
	"reflect"
	"runtime"
	"strings"
	"testing"
	"unsafe"

	"github.com/disintegration/imaging"
)

func nativeOCRIdentityInput(mode string, subimage bool) *image.NRGBA {
	width, height := 768, 512
	if mode == "recognize" {
		width, height = 480, 48
	}
	border := 0
	if subimage {
		border = 32
	}
	src := image.NewNRGBA(image.Rect(0, 0, width+border, height+border))
	for i := range src.Pix {
		src.Pix[i] = byte(i*31 + i/101)
	}
	if subimage {
		return src.SubImage(image.Rect(11, 13, 11+width, 13+height)).(*image.NRGBA)
	}
	return src
}

func runNativeOCRPrepared(r *nativeEmbeddingRuntime, model *nativeEmbeddingModel, src image.Image, mode string) error {
	if mode == "recognize" {
		_, err := r.recognizeRapidOCR(model, src, 0)
		return err
	}
	_, err := r.detectRapidOCR(model, src, rapidOCRInferConfig{})
	return err
}

func TestNativeOCRIdentityInputAvoidsClone(t *testing.T) {
	for _, mode := range []string{"detect", "recognize"} {
		t.Run(mode, func(t *testing.T) {
			src := nativeOCRIdentityInput(mode, false)
			r := nativeOCROutputRuntime([]float32{0}, 1, 1, func(uintptr) {})
			model := &nativeEmbeddingModel{net: 7, splitHeadNet: 8, ocrKeys: []string{"#", "A"}}
			runtime.GC()
			var before, after runtime.MemStats
			runtime.ReadMemStats(&before)
			for i := 0; i < 8; i++ {
				if err := runNativeOCRPrepared(r, model, src, mode); err != nil {
					t.Fatal(err)
				}
			}
			runtime.ReadMemStats(&after)
			if allocated := (after.TotalAlloc - before.TotalAlloc) / 8; allocated > 16*1024 {
				t.Fatalf("same-size %s input still clones pixels: %d bytes/call", mode, allocated)
			}
		})
	}
}

func TestNativeOCRIdentityInputBorrowsVisiblePixels(t *testing.T) {
	for _, mode := range []string{"detect", "recognize"} {
		for _, subimage := range []bool{false, true} {
			for _, modern := range []bool{false, true} {
				t.Run(fmt.Sprintf("%s/subimage=%t/modern=%t", mode, subimage, modern), func(t *testing.T) {
					src := nativeOCRIdentityInput(mode, subimage)
					before := append([]byte(nil), src.Pix...)
					want := imaging.Resize(src, src.Rect.Dx(), src.Rect.Dy(), imaging.Linear)
					r := nativeOCROutputRuntime([]float32{0}, 1, 1, func(uintptr) {})
					model := &nativeEmbeddingModel{net: 7, splitHeadNet: 8, ocrKeys: []string{"#", "A"}, ocrProfile: rapidOCRBundleLayout{modern: modern}}
					calls := 0
					r.base.bindings.matFromPixels = func(pixels *byte, pixelType, width, height, stride int32, _ uintptr) uintptr {
						calls++
						wantType := nativeMatPixelRGBA2RGB
						if modern {
							wantType = nativeMatPixelRGBA2BGR
						}
						if pixels != &src.Pix[0] || pixelType != wantType || int(width) != src.Rect.Dx() || int(height) != src.Rect.Dy() || int(stride) != src.Stride {
							t.Error("same-size input did not borrow the source pointer, stride or pixel format")
						}
						visible := unsafe.Slice(pixels, int(height-1)*int(stride)+int(width)*4)
						for y := 0; y < int(height); y++ {
							if !bytes.Equal(visible[y*int(stride):y*int(stride)+int(width)*4], want.Pix[y*want.Stride:(y+1)*want.Stride]) {
								t.Error("borrowed input differs from the old resize bytes")
								break
							}
						}
						return 1
					}
					if err := runNativeOCRPrepared(r, model, src, mode); err != nil || calls != 1 || !bytes.Equal(src.Pix, before) {
						t.Fatalf("input err=%v calls=%d source changed=%t", err, calls, !bytes.Equal(src.Pix, before))
					}
				})
			}
		}
	}
}

func TestNativeOCRDetectorResizeMatchesReference(t *testing.T) {
	sources := append(nativeOCRCropSources(), nativeOCRIdentityInput("detect", false), nativeOCRIdentityInput("detect", true))
	sources = append(sources, struct{ image.Image }{nativeOCRIdentityInput("detect", true)})
	for _, src := range sources {
		for _, target := range []int{0, 32, 64, 317} {
			got, scale, err := prepareRapidOCRDetectorImage(src, target)
			if err != nil {
				t.Fatal(err)
			}
			bounds := src.Bounds()
			maxSide := target
			if maxSide <= 0 {
				maxSide = max(bounds.Dx(), bounds.Dy())
			}
			ratio := float64(maxSide) / float64(max(bounds.Dx(), bounds.Dy()))
			width, height := max(32, int(float64(bounds.Dx())*ratio)/32*32), max(32, int(float64(bounds.Dy())*ratio)/32*32)
			want := imaging.Resize(src, width, height, imaging.Linear)
			wantScale := rapidOCRDetectorScale{sourceWidth: bounds.Dx(), sourceHeight: bounds.Dy(), ratioWidth: float64(width) / float64(bounds.Dx()), ratioHeight: float64(height) / float64(bounds.Dy())}
			if got.Rect != want.Rect || scale != wantScale {
				t.Fatalf("%T target=%d: different shape or projection", src, target)
			}
			for y := 0; y < height; y++ {
				if !bytes.Equal(got.Pix[y*got.Stride:y*got.Stride+width*4], want.Pix[y*want.Stride:(y+1)*want.Stride]) {
					t.Fatalf("%T target=%d row=%d: different pixels", src, target, y)
				}
			}
		}
	}
}

func TestNativeOCRIdentityInputNativeTensorParity(t *testing.T) {
	if os.Getenv(envNativeLibraryPath) == "" {
		t.Skip("set local NCNN library for identity input tensor equality")
	}
	backend, err := openNativeEmbeddingBackend()
	if err != nil {
		t.Fatal(err)
	}
	for _, mode := range []string{"detect", "recognize"} {
		for _, modern := range []bool{false, true} {
			t.Run(fmt.Sprintf("%s/modern=%t", mode, modern), func(t *testing.T) {
				src := nativeOCRIdentityInput(mode, true)
				before := append([]byte(nil), src.Pix...)
				want := imaging.Resize(src, src.Rect.Dx(), src.Rect.Dy(), imaging.Linear)
				r := nativeOCROutputRuntime([]float32{0}, 1, 1, func(uintptr) {})
				model := &nativeEmbeddingModel{net: 7, splitHeadNet: 8, ocrKeys: []string{"#", "A"}, ocrProfile: rapidOCRBundleLayout{modern: modern}}
				var inputMat, referenceMat uintptr
				r.base.bindings.matFromPixels = func(pixels *byte, pixelType, width, height, stride int32, allocator uintptr) uintptr {
					inputMat = backend.bindings.matFromPixels(pixels, pixelType, width, height, stride, allocator)
					referenceMat = backend.bindings.matFromPixels(&want.Pix[0], pixelType, width, height, int32(want.Stride), allocator)
					if inputMat == 0 || referenceMat == 0 {
						t.Fatal("create input/reference Mat")
					}
					return inputMat
				}
				r.base.bindings.matSubstractMeanNormalize = func(mat uintptr, mean, norm *float32) {
					backend.bindings.matSubstractMeanNormalize(mat, mean, norm)
					backend.bindings.matSubstractMeanNormalize(referenceMat, mean, norm)
					got, gotErr := nativeFloatValuesFromMat(backend.bindings, mat)
					wantValues, wantErr := nativeFloatValuesFromMat(backend.bindings, referenceMat)
					if gotErr != nil || wantErr != nil || !reflect.DeepEqual(got, wantValues) {
						t.Errorf("normalized tensor differs: %v / %v", gotErr, wantErr)
					}
				}
				r.base.bindings.matDestroy = func(mat uintptr) {
					if mat == inputMat {
						backend.bindings.matDestroy(inputMat)
						backend.bindings.matDestroy(referenceMat)
					}
				}
				if err := runNativeOCRPrepared(r, model, src, mode); err != nil {
					t.Fatal(err)
				}
				if !bytes.Equal(src.Pix, before) {
					t.Fatal("native normalization modified borrowed source pixels")
				}
				runtime.KeepAlive(want)
			})
		}
	}
}

func BenchmarkNativeOCRResizeInput(b *testing.B) {
	for _, mode := range []string{"detect", "recognize"} {
		for _, sameSize := range []bool{true, false} {
			name := "resize"
			if sameSize {
				name = "identity"
			}
			b.Run(mode+"/"+name, func(b *testing.B) {
				var src image.Image = nativeOCRIdentityInput(mode, false)
				if !sameSize {
					if mode == "detect" {
						src = nativePerformanceImage(768, 500)
					} else {
						src = nativePerformanceImage(480, 72)
					}
				}
				r := nativeOCROutputRuntime([]float32{0}, 1, 1, func(uintptr) {})
				model := &nativeEmbeddingModel{net: 7, splitHeadNet: 8, ocrKeys: []string{"#", "A"}, ocrProfile: rapidOCRBundleLayout{modern: true}}
				b.ReportAllocs()
				b.ResetTimer()
				for i := 0; i < b.N; i++ {
					if err := runNativeOCRPrepared(r, model, src, mode); err != nil {
						b.Fatal(err)
					}
				}
			})
		}
	}
}

func nativeOCRIdentityBenchmarkRuntime(t testing.TB, mode string) (*nativeEmbeddingRuntime, *wrapperRuntimeState, inferRequest) {
	t.Helper()
	r, state, request := nativeOCRBenchmarkRuntime(t, mode)
	if mode == "recognize" {
		params := request.Input["params"].(map[string]interface{})
		params["det_boxes"] = []map[string]interface{}{{"points": []map[string]float64{
			{"x": 90, "y": 100}, {"x": 540, "y": 100}, {"x": 540, "y": 148}, {"x": 90, "y": 148},
		}}}
		return r, state, request
	}
	src, err := imaging.Open(request.Input["image"].(string))
	if err != nil {
		t.Fatal(err)
	}
	// With the unchanged 50px border, 764x508 becomes aligned 864x608.
	resized := imaging.Resize(src, 764, 508, imaging.NearestNeighbor)
	path := filepath.Join(t.TempDir(), "synthetic-aligned.jpg")
	if err := imaging.Save(resized, path, imaging.JPEGQuality(95)); err != nil {
		t.Fatal(err)
	}
	request.Input["image"] = path
	return r, state, request
}

func BenchmarkNativeOCRIdentitySingleImage(b *testing.B) {
	for _, mode := range []string{"detect", "recognize", "full"} {
		b.Run(mode, func(b *testing.B) {
			r, state, request := nativeOCRIdentityBenchmarkRuntime(b, mode)
			b.ReportAllocs()
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				result, handled := tryNativeOCRInfer(state, nativeEmbeddingSpec{backend: r}, request)
				if !handled || result.Output["ok"] != true {
					b.Fatalf("identity-size single OCR image: %#v", result.Output)
				}
			}
		})
	}
}

func TestNativeOCRIdentitySingleImageParity(t *testing.T) {
	outputDir := os.Getenv("ZIMAOS_NCNN_OCR_IDENTITY_PARITY_OUTPUT_DIR")
	if outputDir == "" {
		t.Skip("set identity OCR parity output directory and benchmark bundle")
	}
	if err := os.MkdirAll(outputDir, 0o700); err != nil {
		t.Fatal(err)
	}
	for _, mode := range []string{"detect", "recognize", "full"} {
		t.Run(mode, func(t *testing.T) {
			r, state, request := nativeOCRIdentityBenchmarkRuntime(t, mode)
			result, handled := tryNativeOCRInfer(state, nativeEmbeddingSpec{backend: r}, request)
			if !handled || result.Output["ok"] != true {
				t.Fatalf("OCR parity: %#v", result.Output)
			}
			if mode != "detect" && !strings.Contains(fmt.Sprint(result.Output["text"]), "PHOTO CPU 2026") {
				t.Fatalf("expected synthetic text not recognized: %#v", result.Output)
			}
			src, err := imaging.Open(request.Input["image"].(string))
			if err != nil {
				t.Fatal(err)
			}
			digest := sha256.Sum256(rapidOCRPadImage(src, 50).Pix)
			body, err := json.MarshalIndent(map[string]interface{}{"padded_sha256": hex.EncodeToString(digest[:]), "output": result.Output}, "", "  ")
			if err != nil {
				t.Fatal(err)
			}
			if err := os.WriteFile(filepath.Join(outputDir, mode+".json"), body, 0o600); err != nil {
				t.Fatal(err)
			}
		})
	}
}

// Keep the width formula visible in the tests: identity recognition is only
// possible at height 48, while other heights retain the original resize.
func TestNativeOCRRecognitionResizeFormula(t *testing.T) {
	for _, height := range []int{1, 47, 48, 49, 72} {
		src := nativePerformanceImage(57, height)
		wantWidth := max(1, int(math.Round(float64(57)*48/float64(height))))
		want := imaging.Resize(src, wantWidth, 48, imaging.Linear)
		r := nativeOCROutputRuntime([]float32{0}, 1, 1, func(uintptr) {})
		r.base.bindings.matFromPixels = func(pixels *byte, _ int32, width, height, stride int32, _ uintptr) uintptr {
			if int(width) != wantWidth || height != 48 {
				t.Error("recognition target dimensions changed")
			}
			visible := unsafe.Slice(pixels, int(height-1)*int(stride)+int(width)*4)
			for y := 0; y < int(height); y++ {
				if !bytes.Equal(visible[y*int(stride):y*int(stride)+int(width)*4], want.Pix[y*want.Stride:(y+1)*want.Stride]) {
					t.Error("recognition resize pixels changed")
					break
				}
			}
			return 1
		}
		if err := runNativeOCRPrepared(r, &nativeEmbeddingModel{net: 7, splitHeadNet: 8, ocrKeys: []string{"#", "A"}}, src, "recognize"); err != nil {
			t.Fatal(err)
		}
	}
}
