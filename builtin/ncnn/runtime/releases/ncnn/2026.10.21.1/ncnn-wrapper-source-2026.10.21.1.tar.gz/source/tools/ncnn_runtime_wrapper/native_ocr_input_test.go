package main

import (
	"bytes"
	"fmt"
	"image"
	"os"
	"reflect"
	"runtime"
	"testing"
	"unsafe"

	"github.com/disintegration/imaging"
)

func nativeOCRPreparedInputCase(t testing.TB, mode string, modern bool) (*nativeEmbeddingRuntime, func() error, *image.NRGBA) {
	t.Helper()
	width, height := 768, 512
	if mode == "recognize" {
		width, height = 480, 48
	}
	src := nativePerformanceImage(width, height)
	r := nativeOCROutputRuntime([]float32{0}, 1, 1, func(uintptr) {})
	model := &nativeEmbeddingModel{net: 7, splitHeadNet: 8, ocrKeys: []string{"#", "A"}, ocrProfile: rapidOCRBundleLayout{modern: modern}}
	run := func() error {
		if mode == "recognize" {
			_, err := r.recognizeRapidOCR(model, src, 0)
			return err
		}
		_, err := r.detectRapidOCR(model, src, rapidOCRInferConfig{})
		return err
	}
	return r, run, src
}

func TestNativeOCRPreparedInputDoesNotAllocatePackedRGB(t *testing.T) {
	for _, mode := range []string{"detect", "recognize"} {
		for _, modern := range []bool{false, true} {
			t.Run(fmt.Sprintf("%s/modern=%t", mode, modern), func(t *testing.T) {
				_, run, src := nativeOCRPreparedInputCase(t, mode, modern)
				runtime.GC()
				var before, after runtime.MemStats
				runtime.ReadMemStats(&before)
				for i := 0; i < 8; i++ {
					if err := run(); err != nil {
						t.Fatal(err)
					}
				}
				runtime.ReadMemStats(&after)
				if allocated := (after.TotalAlloc - before.TotalAlloc) / 8; allocated > uint64(src.Rect.Dx()*src.Rect.Dy()*5+16*1024) {
					t.Fatalf("OCR input still allocates a packed RGB copy: %d bytes/image", allocated)
				}
			})
		}
	}
}

func TestNativeOCRPreparedInputPassesOriginalNRGBA(t *testing.T) {
	for _, mode := range []string{"detect", "recognize"} {
		for _, modern := range []bool{false, true} {
			t.Run(fmt.Sprintf("%s/modern=%t", mode, modern), func(t *testing.T) {
				r, run, src := nativeOCRPreparedInputCase(t, mode, modern)
				var want *image.NRGBA
				if mode == "recognize" {
					want = imaging.Resize(src, src.Rect.Dx(), 48, imaging.Linear)
				} else {
					var err error
					want, _, err = prepareRapidOCRDetectorImage(src, src.Rect.Dx())
					if err != nil {
						t.Fatal(err)
					}
				}
				before := append([]byte(nil), src.Pix...)
				calls := 0
				r.base.bindings.matFromPixels = func(pixels *byte, pixelType, width, height, stride int32, _ uintptr) uintptr {
					calls++
					// NCNN mat.h: RGBA=4, RGB=1, BGR=2, conversion shift=16.
					wantType := int32(4 | (1 << 16))
					if modern {
						wantType = 4 | (2 << 16)
					}
					if pixelType != wantType || int(stride) != want.Stride || int(width) != want.Rect.Dx() || int(height) != want.Rect.Dy() {
						t.Errorf("input type=%d stride=%d dimensions=%dx%d, want type=%d stride=%d dimensions=%s", pixelType, stride, width, height, wantType, want.Stride, want.Rect.Size())
						return 1
					}
					if !bytes.Equal(unsafe.Slice(pixels, len(want.Pix)), want.Pix) {
						t.Error("NCNN received different NRGBA bytes")
					}
					return 1
				}
				if err := run(); err != nil || calls != 1 || !bytes.Equal(src.Pix, before) {
					t.Fatalf("input error=%v calls=%d source changed=%t", err, calls, !bytes.Equal(src.Pix, before))
				}
			})
		}
	}
}

func TestNativeOCRInputConversionMatchesPackedTensor(t *testing.T) {
	if os.Getenv(envNativeLibraryPath) == "" {
		t.Skip("set local NCNN library for native tensor equality")
	}
	backend, err := openNativeEmbeddingBackend()
	if err != nil {
		t.Fatal(err)
	}
	for _, mode := range []string{"detect", "recognize"} {
		for _, modern := range []bool{false, true} {
			t.Run(fmt.Sprintf("%s/modern=%t", mode, modern), func(t *testing.T) {
				r, run, _ := nativeOCRPreparedInputCase(t, mode, modern)
				var inputMat, referenceMat uintptr
				r.base.bindings.matFromPixels = func(pixels *byte, pixelType, width, height, stride int32, allocator uintptr) uintptr {
					inputMat = backend.bindings.matFromPixels(pixels, pixelType, width, height, stride, allocator)
					if inputMat == 0 {
						t.Fatal("create native input Mat")
					}
					var source *image.NRGBA
					_, _, src := nativeOCRPreparedInputCase(t, mode, modern)
					if mode == "recognize" {
						source = imaging.Resize(src, int(width), int(height), imaging.Linear)
					} else {
						source, _, err = prepareRapidOCRDetectorImage(src, src.Rect.Dx())
						if err != nil {
							t.Fatal(err)
						}
					}
					packed := rapidOCRPixels(source, modern)
					legacyType := nativeMatPixelRGB
					if modern {
						legacyType = nativeMatPixelBGR
					}
					referenceMat = backend.bindings.matFromPixels(&packed[0], legacyType, width, height, width*3, 0)
					runtime.KeepAlive(packed)
					return inputMat
				}
				r.base.bindings.matSubstractMeanNormalize = func(mat uintptr, mean, norm *float32) {
					backend.bindings.matSubstractMeanNormalize(mat, mean, norm)
					backend.bindings.matSubstractMeanNormalize(referenceMat, mean, norm)
					got, gotErr := nativeFloatValuesFromMat(backend.bindings, mat)
					want, wantErr := nativeFloatValuesFromMat(backend.bindings, referenceMat)
					if gotErr != nil || wantErr != nil || !reflect.DeepEqual(got, want) {
						t.Errorf("normalized input tensor differs: %v / %v", gotErr, wantErr)
					}
				}
				r.base.bindings.matDestroy = func(mat uintptr) {
					if mat == inputMat {
						backend.bindings.matDestroy(inputMat)
						backend.bindings.matDestroy(referenceMat)
					}
				}
				if err := run(); err != nil {
					t.Fatal(err)
				}
			})
		}
	}
}

// Includes Go resize/clone, input preparation and simulated net/decoder work.
// Native conversion and graph execution are measured by the real-model benchmark.
func BenchmarkNativeOCRPreparedInput(b *testing.B) {
	for _, mode := range []string{"detect", "recognize"} {
		for _, modern := range []bool{false, true} {
			b.Run(fmt.Sprintf("%s/modern=%t", mode, modern), func(b *testing.B) {
				_, run, _ := nativeOCRPreparedInputCase(b, mode, modern)
				b.ReportAllocs()
				b.ResetTimer()
				for i := 0; i < b.N; i++ {
					if err := run(); err != nil {
						b.Fatal(err)
					}
				}
			})
		}
	}
}
