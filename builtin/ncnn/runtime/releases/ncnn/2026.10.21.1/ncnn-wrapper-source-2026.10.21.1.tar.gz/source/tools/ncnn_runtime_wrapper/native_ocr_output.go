package main

import (
	"fmt"
	"runtime"
	"strings"
)

// withRapidOCRNetOutput retains the native Mat and extractor while decode reads
// the validated output. The callback must return owned results and must not
// retain values after it returns.
func (r *nativeEmbeddingRuntime) withRapidOCRNetOutput(
	model *nativeEmbeddingModel,
	net uintptr,
	pixels []byte,
	width, height, stride int,
	pixelType int32,
	inputName, outputName string,
	meanValues, normValues []float32,
	threadLimit int,
	decode func([]float32, int, int) error,
) error {
	if len(pixels) == 0 || width <= 0 || height <= 0 {
		return fmt.Errorf("rapidocr NCNN input is empty")
	}
	defer func() {
		runtime.KeepAlive(pixels)
		runtime.KeepAlive(meanValues)
		runtime.KeepAlive(normValues)
	}()
	// Input pixels may belong to a resized image or an unchanged NRGBA source.
	// NCNN synchronously copies and deinterleaves the visible strided pixels
	// into its own Mat; the borrowed source stays read-only and alive here.
	mat := r.base.bindings.matFromPixels(byteSliceCStringPointer(pixels), pixelType, int32(width), int32(height), int32(stride), 0)
	if mat == 0 {
		return fmt.Errorf("failed to create rapidocr NCNN input mat")
	}
	defer r.base.bindings.matDestroy(mat)

	var meanPtr *float32
	if len(meanValues) > 0 {
		meanPtr = &meanValues[0]
	}
	var normPtr *float32
	if len(normValues) > 0 {
		normPtr = &normValues[0]
	}
	r.base.bindings.matSubstractMeanNormalize(mat, meanPtr, normPtr)

	effectiveThreadLimit := threadLimit
	if effectiveThreadLimit <= 0 {
		effectiveThreadLimit = model.threadLimit
	}
	extractor, err := r.createExtractor(net, effectiveThreadLimit, model)
	if err != nil {
		return err
	}
	defer r.base.bindings.extractorDestroy(extractor)

	inputCString := append([]byte(strings.TrimSpace(inputName)), 0)
	if code := r.base.bindings.extractorInput(extractor, byteSliceCStringPointer(inputCString), mat); code != 0 {
		return fmt.Errorf("failed to bind rapidocr input %s: %d", inputName, code)
	}
	outputCString := append([]byte(strings.TrimSpace(outputName)), 0)
	var outputMat uintptr
	code := r.base.bindings.extractorExtract(extractor, byteSliceCStringPointer(outputCString), &outputMat)
	if outputMat != 0 {
		defer r.base.bindings.matDestroy(outputMat)
	}
	if code != 0 {
		return fmt.Errorf("failed to extract rapidocr output %s: %d", outputName, code)
	}
	if outputMat == 0 {
		return fmt.Errorf("rapidocr NCNN extractor returned nil output mat")
	}
	values, err := nativeFloatValuesFromMat(r.base.bindings, outputMat)
	if err != nil {
		return err
	}
	outputWidth := int(r.base.bindings.matGetW(outputMat))
	outputHeight := int(r.base.bindings.matGetH(outputMat))
	return decode(values, outputWidth, outputHeight)
}
