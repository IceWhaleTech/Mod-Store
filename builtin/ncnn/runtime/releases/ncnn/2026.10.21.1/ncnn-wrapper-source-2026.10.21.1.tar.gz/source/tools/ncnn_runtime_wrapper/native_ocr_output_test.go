package main

import (
	"errors"
	"math"
	"reflect"
	"runtime"
	"testing"
	"unsafe"
)

// Input Mat 1, extractor 2 and output Mat 3 have distinct lifetimes.
func nativeOCROutputRuntime(values []float32, width, height int, destroy func(uintptr)) *nativeEmbeddingRuntime {
	return &nativeEmbeddingRuntime{base: &nativeEmbeddingBackend{bindings: nativeNCNNBindings{
		matFromPixels:             func(*byte, int32, int32, int32, int32, uintptr) uintptr { return 1 },
		matSubstractMeanNormalize: func(uintptr, *float32, *float32) {},
		extractorCreate:           func(uintptr) uintptr { return 2 },
		extractorInput:            func(uintptr, *byte, uintptr) int32 { return 0 },
		extractorExtract:          func(_ uintptr, _ *byte, output *uintptr) int32 { *output = 3; return 0 },
		matGetDims:                func(uintptr) int32 { return 2 },
		matGetW:                   func(uintptr) int32 { return int32(width) },
		matGetH:                   func(uintptr) int32 { return int32(height) },
		matGetD:                   func(uintptr) int32 { return 0 },
		matGetC:                   func(uintptr) int32 { return 0 },
		matGetData:                func(uintptr) unsafe.Pointer { return unsafe.Pointer(unsafe.SliceData(values)) },
		matDestroy:                destroy,
		extractorDestroy:          destroy,
	}}}
}

func TestNativeOCROutputDecodesTheLiveMatAndOwnsResults(t *testing.T) {
	values := []float32{.1, .9, .2, .1, .1, .8}
	var destroyed []uintptr
	r := nativeOCROutputRuntime(values, 3, 2, func(mat uintptr) {
		destroyed = append(destroyed, mat)
		if mat == 3 {
			for i := range values {
				values[i] = float32(math.NaN())
			}
		}
	})
	var text string
	var scores []float32
	err := r.withRapidOCRNetOutput(&nativeEmbeddingModel{}, 7, []byte{1, 2, 3}, 1, 1, 3, nativeMatPixelRGB,
		"input", "output", nil, nil, 0, func(output []float32, width, height int) error {
			if len(destroyed) != 0 || width != 3 || height != 2 {
				t.Errorf("decoder ran after native cleanup or with incorrect shape: %v %dx%d", destroyed, width, height)
			}
			if &output[0] != &values[0] {
				t.Error("OCR output copied the entire native tensor")
			}
			text, scores = rapidOCRDecodeCTCWithScores(output, height, width, []string{"#", "A", "B"}, false)
			return nil
		})
	if err != nil || !reflect.DeepEqual(destroyed, []uintptr{3, 2, 1}) {
		t.Fatalf("cleanup order: %v, error: %v", destroyed, err)
	}
	if text != "AB" || !reflect.DeepEqual(scores, []float32{.9, .8}) {
		t.Fatalf("decoded result did not survive native release: %q %v", text, scores)
	}
}

func TestNativeOCROutputFailureCleanup(t *testing.T) {
	decoderErr := errors.New("decode failed")
	for _, stage := range []string{"input", "input_mat", "extractor", "bind", "extract", "extract_owned", "nil_output", "empty", "nil_data", "nonfinite", "infinity", "decode"} {
		t.Run(stage, func(t *testing.T) {
			values := []float32{.1, .9}
			var destroyed []uintptr
			r := nativeOCROutputRuntime(values, 2, 1, func(mat uintptr) { destroyed = append(destroyed, mat) })
			bindings := &r.base.bindings
			pixels := []byte{1, 2, 3}
			wantDestroyed := []uintptr{3, 2, 1}
			switch stage {
			case "input":
				pixels, wantDestroyed = nil, nil
			case "input_mat":
				bindings.matFromPixels = func(*byte, int32, int32, int32, int32, uintptr) uintptr { return 0 }
				wantDestroyed = nil
			case "extractor":
				bindings.extractorCreate = func(uintptr) uintptr { return 0 }
				wantDestroyed = []uintptr{1}
			case "bind":
				bindings.extractorInput = func(uintptr, *byte, uintptr) int32 { return -1 }
				wantDestroyed = []uintptr{2, 1}
			case "extract":
				bindings.extractorExtract = func(uintptr, *byte, *uintptr) int32 { return -1 }
				wantDestroyed = []uintptr{2, 1}
			case "nil_output":
				bindings.extractorExtract = func(uintptr, *byte, *uintptr) int32 { return 0 }
				wantDestroyed = []uintptr{2, 1}
			case "extract_owned":
				bindings.extractorExtract = func(_ uintptr, _ *byte, output *uintptr) int32 { *output = 3; return -1 }
			case "empty":
				bindings.matGetW = func(uintptr) int32 { return 0 }
			case "nil_data":
				bindings.matGetData = func(uintptr) unsafe.Pointer { return nil }
			case "nonfinite":
				values[1] = float32(math.NaN())
			case "infinity":
				values[1] = float32(math.Inf(1))
			}
			decoded := false
			err := r.withRapidOCRNetOutput(&nativeEmbeddingModel{}, 7, pixels, 1, 1, 3, nativeMatPixelRGB,
				"input", "output", nil, nil, 0, func([]float32, int, int) error { decoded = true; return decoderErr })
			if err == nil || !reflect.DeepEqual(destroyed, wantDestroyed) || decoded != (stage == "decode") {
				t.Fatalf("err=%v destroyed=%v want=%v decoded=%v", err, destroyed, wantDestroyed, decoded)
			}
			if stage == "decode" && !errors.Is(err, decoderErr) {
				t.Fatalf("decoder error was lost: %v", err)
			}
		})
	}
}

func nativeOCRRecognitionOutput(t testing.TB) (*nativeEmbeddingRuntime, []byte, func([]float32, int, int) error) {
	t.Helper()
	values := make([]float32, 64*6625)
	for row := 0; row < 64; row += 4 {
		values[row*6625+1] = .9
	}
	r := nativeOCROutputRuntime(values, 6625, 64, func(uintptr) {})
	return r, []byte{1, 2, 3}, func(output []float32, width, height int) error {
		text, scores := rapidOCRDecodeCTCWithScores(output, height, width, []string{"#", "A"}, false)
		if len(text) != 16 || len(scores) != 16 {
			t.Fatal("invalid recognition output")
		}
		return nil
	}
}

func TestNativeOCROutputDoesNotCopyRecognitionTensor(t *testing.T) {
	r, pixels, decode := nativeOCRRecognitionOutput(t)
	runtime.GC()
	var before, after runtime.MemStats
	runtime.ReadMemStats(&before)
	for i := 0; i < 8; i++ {
		if err := r.withRapidOCRNetOutput(&nativeEmbeddingModel{}, 7, pixels, 1, 1, 3, nativeMatPixelRGB, "input", "output", nil, nil, 0, decode); err != nil {
			t.Fatal(err)
		}
	}
	runtime.ReadMemStats(&after)
	if allocated := (after.TotalAlloc - before.TotalAlloc) / 8; allocated > 64*1024 {
		t.Fatalf("recognition still copies the 64x6625 output: %d bytes/image", allocated)
	}
}

func BenchmarkNativeOCRRecognitionOutput(b *testing.B) {
	r, pixels, decode := nativeOCRRecognitionOutput(b)
	model := &nativeEmbeddingModel{}
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		if err := r.withRapidOCRNetOutput(model, 7, pixels, 1, 1, 3, nativeMatPixelRGB, "input", "output", nil, nil, 0, decode); err != nil {
			b.Fatal(err)
		}
	}
}
