package main

import (
	"bytes"
	"fmt"
	"image"
	"image/color"
	"runtime"
	"testing"

	"github.com/disintegration/imaging"
)

func TestNativeOCRPaddingDoesNotAllocateTwoCanvases(t *testing.T) {
	_, jpeg := nativePerformanceJPEG(t, 768, 512)
	for _, src := range []image.Image{nativePerformanceImage(768, 512), jpeg} {
		t.Run(fmt.Sprintf("%T", src), func(t *testing.T) {
			runtime.GC()
			var before, after runtime.MemStats
			runtime.ReadMemStats(&before)
			for i := 0; i < 8; i++ {
				if rapidOCRPadImage(src, 50).Bounds().Dx() != 868 {
					t.Fatal("invalid padding")
				}
			}
			runtime.ReadMemStats(&after)
			if allocated := (after.TotalAlloc - before.TotalAlloc) / 8; allocated > 868*612*6 {
				t.Fatalf("OCR padding still allocates two full canvases: %d bytes/image", allocated)
			}
		})
	}
}

func TestNativeOCRPaddingMatchesOriginalAndOwnsPixels(t *testing.T) {
	sources := append(nativePixelTestSources(), nativePerformanceImage(1, 1), nativePerformanceImage(71, 45))
	rect := image.Rect(-3, -2, 14, 11)
	nrgba64, rgba64, gray16 := image.NewNRGBA64(rect), image.NewRGBA64(rect), image.NewGray16(rect)
	for y := rect.Min.Y; y < rect.Max.Y; y++ {
		for x := rect.Min.X; x < rect.Max.X; x++ {
			c := color.NRGBA64{R: uint16(x * 9781), G: uint16(y * 7567), B: uint16(x * y * 5317), A: uint16((x + y) * 3751)}
			nrgba64.SetNRGBA64(x, y, c)
			rgba64.Set(x, y, c)
			gray16.SetGray16(x, y, color.Gray16{Y: c.R})
		}
	}
	sources = append(sources, nrgba64, rgba64, gray16)
	for _, src := range sources {
		before := imaging.Clone(src)
		for _, padding := range []int{-1, 0, 1, 50} {
			p := max(padding, 0)
			bounds := src.Bounds()
			want := imaging.Paste(imaging.New(bounds.Dx()+2*p, bounds.Dy()+2*p, color.NRGBA{R: 255, G: 255, B: 255, A: 255}), src, image.Pt(p, p))
			got := rapidOCRPadImage(src, padding)
			if got.Bounds() != want.Bounds() || !bytes.Equal(got.Pix, want.Pix) {
				t.Fatalf("%T bounds=%s padding=%d: pixels changed", src, bounds, padding)
			}
			got.Pix[0] ^= 0xff
			if !bytes.Equal(imaging.Clone(src).Pix, before.Pix) {
				t.Fatal("padding changed source pixels")
			}
		}
	}
}
