package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"image/jpeg"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/disintegration/imaging"
	"golang.org/x/image/font"
	"golang.org/x/image/font/basicfont"
	"golang.org/x/image/math/fixed"
)

func BenchmarkNativeOCRPadding(b *testing.B) {
	for _, size := range [][2]int{{768, 512}, {1536, 1024}} {
		_, decoded := nativePerformanceJPEG(b, size[0], size[1])
		for _, kind := range []string{"nrgba", "jpeg"} {
			var src image.Image = nativePerformanceImage(size[0], size[1])
			if kind == "jpeg" {
				src = decoded
			}
			b.Run(fmt.Sprintf("%dx%d/%s", size[0], size[1], kind), func(b *testing.B) {
				b.ReportAllocs()
				for i := 0; i < b.N; i++ {
					padded := rapidOCRPadImage(src, 50)
					if padded.Bounds().Dx() != size[0]+100 || padded.Bounds().Dy() != size[1]+100 {
						b.Fatal("invalid padded dimensions")
					}
				}
			})
		}
	}
}

func nativeOCRBenchmarkSource(t testing.TB) string {
	t.Helper()
	small := image.NewRGBA(image.Rect(0, 0, 192, 128))
	draw.Draw(small, small.Bounds(), image.White, image.Point{}, draw.Src)
	drawer := font.Drawer{Dst: small, Src: image.NewUniform(color.Black), Face: basicfont.Face7x13}
	for i, line := range []string{"PHOTO CPU 2026", "TEST IMAGE 123"} {
		drawer.Dot = fixed.P(12, 24+i*34)
		drawer.DrawString(line)
	}
	src := imaging.Resize(small, 768, 512, imaging.NearestNeighbor)
	var body bytes.Buffer
	if err := jpeg.Encode(&body, src, &jpeg.Options{Quality: 95}); err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(t.TempDir(), "synthetic-text.jpg")
	if err := os.WriteFile(path, body.Bytes(), 0o600); err != nil {
		t.Fatal(err)
	}
	return path
}

func nativeOCRBenchmarkRuntime(t testing.TB, mode string) (*nativeEmbeddingRuntime, *wrapperRuntimeState, inferRequest) {
	t.Helper()
	bundleDir := os.Getenv("ZIMAOS_NCNN_BENCHMARK_OCR_BUNDLE")
	if bundleDir == "" || os.Getenv(envNativeLibraryPath) == "" {
		t.Skip("set local NCNN library and existing OCR benchmark bundle")
	}
	backend, err := openNativeEmbeddingBackend()
	if err != nil {
		t.Fatal(err)
	}
	r := &nativeEmbeddingRuntime{base: backend, loaded: make(map[string]*nativeEmbeddingModel)}
	if err := r.load(modelClassOCR, bundleDir, nativeEmbeddingLoadOptions{threadLimit: 4}); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { r.unload(modelClassOCR) })
	state := &wrapperRuntimeState{loadedBundles: make(map[string]string), loadedBundleIDs: make(map[string]string)}
	state.rememberLoad(modelClassOCR, []string{"cpu"}, bundleDir, "benchmark-ocr")
	params := map[string]interface{}{}
	if mode == "detect" {
		params["det_only"] = true
	} else if mode == "recognize" {
		params["skip_det"] = true
		params["det_boxes"] = []map[string]interface{}{{"points": []map[string]float64{
			{"x": 90, "y": 85}, {"x": 540, "y": 85}, {"x": 540, "y": 160}, {"x": 90, "y": 160},
		}}}
	}
	return r, state, inferRequest{ModelClass: modelClassOCR, Task: "ocr", ThreadLimit: 4, Input: map[string]interface{}{"image": nativeOCRBenchmarkSource(t), "params": params}}
}

func BenchmarkNativeOCRSingleImage(b *testing.B) {
	for _, mode := range []string{"detect", "recognize", "full"} {
		b.Run(mode, func(b *testing.B) {
			r, state, request := nativeOCRBenchmarkRuntime(b, mode)
			b.ReportAllocs()
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				result, handled := tryNativeOCRInfer(state, nativeEmbeddingSpec{backend: r}, request)
				if !handled || result.Output["ok"] != true {
					b.Fatalf("single OCR image: %#v", result.Output)
				}
			}
		})
	}
}

func TestNativeOCRSingleImageParity(t *testing.T) {
	outputDir := os.Getenv("ZIMAOS_NCNN_OCR_PARITY_OUTPUT_DIR")
	if outputDir == "" {
		t.Skip("set OCR parity output directory and benchmark bundle")
	}
	if err := os.MkdirAll(outputDir, 0o700); err != nil {
		t.Fatal(err)
	}
	for _, mode := range []string{"detect", "recognize", "full"} {
		t.Run(mode, func(t *testing.T) {
			r, state, request := nativeOCRBenchmarkRuntime(t, mode)
			result, handled := tryNativeOCRInfer(state, nativeEmbeddingSpec{backend: r}, request)
			if !handled || result.Output["ok"] != true {
				t.Fatalf("OCR parity: %#v", result.Output)
			}
			if mode != "detect" && !strings.Contains(fmt.Sprint(result.Output["text"]), "PHOTO CPU 2026") {
				t.Fatalf("expected synthetic text was not recognized: %#v", result.Output)
			}
			src, err := imaging.Open(request.Input["image"].(string))
			if err != nil {
				t.Fatal(err)
			}
			digest := sha256.Sum256(rapidOCRPadImage(src, 50).Pix)
			body, err := json.MarshalIndent(map[string]interface{}{"padded_sha256": hex.EncodeToString(digest[:]), "output": result.Output}, "", "  ")
			if err != nil {
				t.Fatal(err)
			}
			if err := os.WriteFile(filepath.Join(outputDir, mode+".json"), body, 0o600); err != nil {
				t.Fatal(err)
			}
		})
	}
}
