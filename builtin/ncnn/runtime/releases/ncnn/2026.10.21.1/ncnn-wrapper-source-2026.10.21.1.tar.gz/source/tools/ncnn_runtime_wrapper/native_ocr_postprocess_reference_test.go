package main

import (
	"math"
	"sort"
)

// Frozen pre-round-11 decoder, pre-round-12 geometry, and pre-round-13 corner ordering.
func referenceRapidOCRBoxesFromProbabilityMap(
	probabilities []float32,
	width, height int,
	scale rapidOCRDetectorScale,
	boxScoreThresh, boxThresh, unclipRatio float64,
) []rapidOCRDetBox {
	if width <= 0 || height <= 0 || len(probabilities) < width*height ||
		scale.sourceWidth <= 0 || scale.sourceHeight <= 0 || scale.ratioWidth <= 0 || scale.ratioHeight <= 0 {
		return nil
	}
	visited := make([]bool, width*height)
	boxes := make([]rapidOCRDetBox, 0)
	componentCount := 0
	for start := 0; start < width*height && componentCount < 1000; start++ {
		if visited[start] || float64(probabilities[start]) <= boxThresh {
			continue
		}
		componentCount++
		component := referenceRapidOCRDetectorComponent(probabilities, width, height, start, boxThresh, visited)
		if len(component) <= 2 {
			continue
		}
		boundary := referenceRapidOCRComponentBoundary(component, probabilities, width, height, boxThresh)
		rect, ok := referenceRapidOCRMinimumAreaRect(boundary)
		if !ok || max(rect.halfWidth*2, rect.halfHeight*2) < 3 {
			continue
		}
		var score float64
		for _, index := range component {
			score += float64(probabilities[index])
		}
		score /= float64(len(component))
		if score < boxScoreThresh {
			continue
		}
		rect = rapidOCRUnclipRect(rect, unclipRatio)
		if max(rect.halfWidth*2, rect.halfHeight*2) < 5 {
			continue
		}
		points := referenceRapidOCROrderedRectPoints(rect)
		for index, point := range points {
			points[index] = rapidOCRPoint{
				x: rapidOCRClamp(math.Trunc(point.x/scale.ratioWidth), 0, float64(scale.sourceWidth-1)),
				y: rapidOCRClamp(math.Trunc(point.y/scale.ratioHeight), 0, float64(scale.sourceHeight-1)),
			}
		}
		boxes = append(boxes, rapidOCRDetBox{confidence: score, points: points})
	}
	sort.SliceStable(boxes, func(i, j int) bool {
		iy, ix := rapidOCRBoxTopLeft(boxes[i])
		jy, jx := rapidOCRBoxTopLeft(boxes[j])
		if math.Abs(iy-jy) > 1 {
			return iy < jy
		}
		return ix < jx
	})
	return boxes
}

func referenceRapidOCRDetectorComponent(probabilities []float32, width, height, start int, threshold float64, visited []bool) []int {
	queue := []int{start}
	visited[start] = true
	component := make([]int, 0, 64)
	for head := 0; head < len(queue); head++ {
		index := queue[head]
		component = append(component, index)
		x, y := index%width, index/width
		for offsetY := -1; offsetY <= 1; offsetY++ {
			for offsetX := -1; offsetX <= 1; offsetX++ {
				if offsetX == 0 && offsetY == 0 {
					continue
				}
				nextX, nextY := x+offsetX, y+offsetY
				if nextX < 0 || nextX >= width || nextY < 0 || nextY >= height {
					continue
				}
				next := nextY*width + nextX
				if visited[next] || float64(probabilities[next]) <= threshold {
					continue
				}
				visited[next] = true
				queue = append(queue, next)
			}
		}
	}
	return component
}

func referenceRapidOCRComponentBoundary(component []int, probabilities []float32, width, height int, threshold float64) []rapidOCRPoint {
	points := make([]rapidOCRPoint, 0, len(component))
	for _, index := range component {
		x, y := index%width, index/width
		boundary := x == 0 || x == width-1 || y == 0 || y == height-1
		if !boundary {
			for _, neighbor := range []int{index - 1, index + 1, index - width, index + width} {
				if float64(probabilities[neighbor]) <= threshold {
					boundary = true
					break
				}
			}
		}
		if boundary {
			points = append(points,
				rapidOCRPoint{x: float64(x), y: float64(y)},
				rapidOCRPoint{x: float64(x + 1), y: float64(y)},
				rapidOCRPoint{x: float64(x + 1), y: float64(y + 1)},
				rapidOCRPoint{x: float64(x), y: float64(y + 1)},
			)
		}
	}
	return points
}

func referenceRapidOCRMinimumAreaRect(points []rapidOCRPoint) (rapidOCRRotatedRect, bool) {
	hull := referenceRapidOCRConvexHull(points)
	if len(hull) < 3 {
		return rapidOCRRotatedRect{}, false
	}
	bestArea := math.Inf(1)
	var best rapidOCRRotatedRect
	for index, point := range hull {
		next := hull[(index+1)%len(hull)]
		dx, dy := next.x-point.x, next.y-point.y
		length := math.Hypot(dx, dy)
		if length <= 0 {
			continue
		}
		axisWidth := rapidOCRPoint{x: dx / length, y: dy / length}
		axisHeight := rapidOCRPoint{x: -axisWidth.y, y: axisWidth.x}
		minWidth, maxWidth := math.Inf(1), math.Inf(-1)
		minHeight, maxHeight := math.Inf(1), math.Inf(-1)
		for _, candidate := range hull {
			widthProjection := candidate.x*axisWidth.x + candidate.y*axisWidth.y
			heightProjection := candidate.x*axisHeight.x + candidate.y*axisHeight.y
			minWidth = math.Min(minWidth, widthProjection)
			maxWidth = math.Max(maxWidth, widthProjection)
			minHeight = math.Min(minHeight, heightProjection)
			maxHeight = math.Max(maxHeight, heightProjection)
		}
		area := (maxWidth - minWidth) * (maxHeight - minHeight)
		if area >= bestArea {
			continue
		}
		centerWidth := (minWidth + maxWidth) / 2
		centerHeight := (minHeight + maxHeight) / 2
		bestArea = area
		best = rapidOCRRotatedRect{
			center: rapidOCRPoint{
				x: axisWidth.x*centerWidth + axisHeight.x*centerHeight,
				y: axisWidth.y*centerWidth + axisHeight.y*centerHeight,
			},
			axisWidth:  axisWidth,
			axisHeight: axisHeight,
			halfWidth:  (maxWidth - minWidth) / 2,
			halfHeight: (maxHeight - minHeight) / 2,
		}
	}
	return best, !math.IsInf(bestArea, 1)
}

func referenceRapidOCRConvexHull(points []rapidOCRPoint) []rapidOCRPoint {
	if len(points) < 2 {
		return append([]rapidOCRPoint(nil), points...)
	}
	sortedPoints := append([]rapidOCRPoint(nil), points...)
	sort.Slice(sortedPoints, func(i, j int) bool {
		if sortedPoints[i].x == sortedPoints[j].x {
			return sortedPoints[i].y < sortedPoints[j].y
		}
		return sortedPoints[i].x < sortedPoints[j].x
	})
	unique := sortedPoints[:0]
	for _, point := range sortedPoints {
		if len(unique) == 0 || point != unique[len(unique)-1] {
			unique = append(unique, point)
		}
	}
	if len(unique) < 3 {
		return append([]rapidOCRPoint(nil), unique...)
	}
	lower := make([]rapidOCRPoint, 0, len(unique))
	for _, point := range unique {
		for len(lower) >= 2 && rapidOCRCross(lower[len(lower)-2], lower[len(lower)-1], point) <= 0 {
			lower = lower[:len(lower)-1]
		}
		lower = append(lower, point)
	}
	upper := make([]rapidOCRPoint, 0, len(unique))
	for index := len(unique) - 1; index >= 0; index-- {
		point := unique[index]
		for len(upper) >= 2 && rapidOCRCross(upper[len(upper)-2], upper[len(upper)-1], point) <= 0 {
			upper = upper[:len(upper)-1]
		}
		upper = append(upper, point)
	}
	return append(lower[:len(lower)-1], upper[:len(upper)-1]...)
}

func referenceRapidOCROrderedRectPoints(rect rapidOCRRotatedRect) [4]rapidOCRPoint {
	width := rapidOCRPoint{x: rect.axisWidth.x * rect.halfWidth, y: rect.axisWidth.y * rect.halfWidth}
	height := rapidOCRPoint{x: rect.axisHeight.x * rect.halfHeight, y: rect.axisHeight.y * rect.halfHeight}
	points := []rapidOCRPoint{
		{x: rect.center.x - width.x - height.x, y: rect.center.y - width.y - height.y},
		{x: rect.center.x + width.x - height.x, y: rect.center.y + width.y - height.y},
		{x: rect.center.x + width.x + height.x, y: rect.center.y + width.y + height.y},
		{x: rect.center.x - width.x + height.x, y: rect.center.y - width.y + height.y},
	}
	sort.Slice(points, func(i, j int) bool {
		if points[i].x == points[j].x {
			return points[i].y < points[j].y
		}
		return points[i].x < points[j].x
	})
	var ordered [4]rapidOCRPoint
	if points[0].y <= points[1].y {
		ordered[0], ordered[3] = points[0], points[1]
	} else {
		ordered[0], ordered[3] = points[1], points[0]
	}
	if points[2].y <= points[3].y {
		ordered[1], ordered[2] = points[2], points[3]
	} else {
		ordered[1], ordered[2] = points[3], points[2]
	}
	return ordered
}
