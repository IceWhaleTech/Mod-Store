package main

import (
	"fmt"
	"math"
	"math/rand"
	"reflect"
	"runtime"
	"sync"
	"testing"
)

func TestNativeOCRPostprocessAllocationBudget(t *testing.T) {
	for _, tc := range []struct {
		kind  string
		limit uint64
	}{{"text", 5_000_000}, {"many", 3_500_000}, {"dense", 24_000_000}} {
		t.Run(tc.kind, func(t *testing.T) {
			values, width, height := nativeOCRProbabilityMap(tc.kind)
			runtime.GC()
			var before, after runtime.MemStats
			runtime.ReadMemStats(&before)
			for i := 0; i < 3; i++ {
				if len(nativeOCRPostprocess(values, width, height)) == 0 {
					t.Fatal("missing boxes")
				}
			}
			runtime.ReadMemStats(&after)
			if allocated := (after.TotalAlloc - before.TotalAlloc) / 3; allocated > tc.limit {
				t.Fatalf("postprocessing allocates %d bytes/image, budget %d", allocated, tc.limit)
			}
		})
	}
}

func TestNativeOCRPostprocessMatchesFrozenDecoder(t *testing.T) {
	check := func(values []float32, width, height int, score, threshold, unclip float64) {
		t.Helper()
		scale := rapidOCRDetectorScale{sourceWidth: width * 3, sourceHeight: height * 2, ratioWidth: .333, ratioHeight: .5}
		before := append([]float32(nil), values...)
		want := referenceRapidOCRBoxesFromProbabilityMap(values, width, height, scale, score, threshold, unclip)
		got := rapidOCRBoxesFromProbabilityMap(values, width, height, scale, score, threshold, unclip)
		assertNativeOCRBoxesEqual(t, got, want)
		for i, value := range values {
			if math.Float32bits(value) != math.Float32bits(before[i]) {
				t.Fatalf("probability %d was modified", i)
			}
		}
	}
	for _, kind := range []string{"blank", "text", "many", "dense"} {
		t.Run(kind, func(t *testing.T) {
			values, width, height := nativeOCRProbabilityMap(kind)
			check(values, width, height, .6, .3, 2)
		})
	}
	// A ring, diagonals, image edges and a long thin component exercise
	// eight-connected traversal and the four-neighbor boundary rule.
	values := make([]float32, 40*32)
	for y := 0; y < 32; y++ {
		for x := 0; x < 40; x++ {
			if x == y || x == 39 || (x >= 10 && x < 25 && y >= 12 && y < 27 && (x < 12 || x >= 23 || y < 14 || y >= 25)) {
				values[y*40+x] = .9
			}
		}
	}
	check(values, 40, 32, .6, .3, 2)
	// Preserve comparison behavior for exact thresholds and non-finite values.
	values = []float32{.5, .5, .5, 0, 0, 0, 0, 0, float32(math.NaN()), float32(math.Inf(1)), .75, 0}
	for _, threshold := range []float64{.5, math.NaN(), math.Inf(1)} {
		check(values, 4, 3, .5, threshold, 0)
	}
	rng := rand.New(rand.NewSource(112026))
	for i := 0; i < 100; i++ {
		width, height := 1+rng.Intn(64), 1+rng.Intn(48)
		values := make([]float32, width*height)
		for j := range values {
			values[j] = float32(rng.Intn(5)) * .25
		}
		check(values, width, height, float64(i%4)*.25, float64(i%5)*.25, float64(i%4))
	}
}

func assertNativeOCRBoxesEqual(t *testing.T, got, want []rapidOCRDetBox) {
	t.Helper()
	if len(got) != len(want) || (got == nil) != (want == nil) {
		t.Fatalf("box count %d != %d (nil %t/%t)", len(got), len(want), got == nil, want == nil)
	}
	for i := range want {
		if got[i].points != want[i].points || math.Float64bits(got[i].confidence) != math.Float64bits(want[i].confidence) {
			t.Fatalf("box %d changed: %#v != %#v", i, got[i], want[i])
		}
	}
}

func TestNativeOCRComponentMatchesFrozenTraversal(t *testing.T) {
	for _, kind := range []string{"text", "many", "dense"} {
		values, width, height := nativeOCRProbabilityMap(kind)
		gotVisited, wantVisited := make([]uint64, (len(values)+63)/64), make([]bool, len(values))
		start := 0
		for values[start] <= .3 {
			start++
		}
		got := rapidOCRDetectorComponent(values, width, height, start, .3, gotVisited, nil)
		want := referenceRapidOCRDetectorComponent(values, width, height, start, .3, wantVisited)
		if !reflect.DeepEqual(got, want) {
			t.Fatalf("%s: BFS order changed", kind)
		}
		for index, want := range wantVisited {
			if got := gotVisited[index>>6]&(uint64(1)<<(index&63)) != 0; got != want {
				t.Fatalf("%s: visited pixel %d changed", kind, index)
			}
		}
		boundary := rapidOCRComponentBoundary(got, values, width, height, .3, nil)
		wantBoundary := referenceRapidOCRComponentBoundary(want, values, width, height, .3)
		if !reflect.DeepEqual(boundary, wantBoundary) {
			t.Fatalf("%s: boundary corners or order changed", kind)
		}
	}
}

func TestNativeOCRPostprocessKeepsComponentLimit(t *testing.T) {
	const width, height = 360, 360
	values := make([]float32, width*height)
	for y := 0; y < 99; y += 3 {
		for x := 0; x < width; x += 3 {
			values[y*width+x] = .9 // More than 1000 isolated one-pixel components.
		}
	}
	for y := 200; y < 220; y++ {
		for x := 0; x < 100; x++ {
			values[y*width+x] = .9
		}
	}
	if boxes := nativeOCRPostprocess(values, width, height); len(boxes) != 0 {
		t.Fatalf("processed a component beyond the 1000 component limit: %d boxes", len(boxes))
	}
}

func TestNativeOCRPostprocessOwnsResults(t *testing.T) {
	values, width, height := nativeOCRProbabilityMap("text")
	want := nativeOCRPostprocess(values, width, height)
	got := nativeOCRPostprocess(values, width, height)
	var wg sync.WaitGroup
	for i := 0; i < 4; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			boxes := nativeOCRPostprocess(values, width, height)
			if !reflect.DeepEqual(boxes, want) {
				t.Error("concurrent decoder returned different boxes")
			}
			boxes[0].points[0].x = -1
		}()
	}
	wg.Wait()
	assertNativeOCRBoxesEqual(t, got, want)
	clear(values)
	assertNativeOCRBoxesEqual(t, got, want)
}

func nativeOCRProbabilityMap(kind string) ([]float32, int, int) {
	const width, height = 768, 512
	values := make([]float32, width*height)
	for y := 0; y < height; y++ {
		for x := 0; x < width; x++ {
			active := false
			switch kind {
			case "dense":
				active = true
			case "text":
				active = y%48 >= 8 && y%48 < 24 && x%96 >= 8 && x%96 < 72
			case "many":
				active = y%12 < 4 && x%12 < 4
			}
			if active {
				values[y*width+x] = .8 + float32((x+y)%7)*.01
			}
		}
	}
	return values, width, height
}

func nativeOCRPostprocess(values []float32, width, height int) []rapidOCRDetBox {
	return rapidOCRBoxesFromProbabilityMap(values, width, height, rapidOCRDetectorScale{
		sourceWidth: width, sourceHeight: height, ratioWidth: 1, ratioHeight: 1,
	}, .6, .3, 2)
}

func BenchmarkNativeOCRPostprocess(b *testing.B) {
	for _, kind := range []string{"blank", "text", "many", "dense"} {
		values, width, height := nativeOCRProbabilityMap(kind)
		b.Run(fmt.Sprintf("%s/%dx%d", kind, width, height), func(b *testing.B) {
			b.ReportAllocs()
			for i := 0; i < b.N; i++ {
				boxes := nativeOCRPostprocess(values, width, height)
				if kind != "blank" && len(boxes) == 0 {
					b.Fatal("missing boxes")
				}
			}
		})
	}
}
