package main

import (
	"bytes"
	"fmt"
	"image"
	"image/color"
	"math"
	"math/rand"
	"runtime"
	"sync"
	"testing"
	"unsafe"

	"github.com/disintegration/imaging"
)

func nativeOCRRegionBox(x, y, width, height float64) rapidOCRDetBox {
	return rapidOCRDetBox{points: [4]rapidOCRPoint{{x, y}, {x + width, y}, {x + width, y + height}, {x, y + height}}}
}

func TestNativeOCRRegionAllocationBudget(t *testing.T) {
	previous := runtime.GOMAXPROCS(1)
	defer runtime.GOMAXPROCS(previous)
	_, jpeg := nativePerformanceJPEG(t, 768, 512)
	for _, src := range []image.Image{nativePerformanceImage(768, 512), jpeg} {
		for _, mode := range []string{"recognize", "full-empty", "skip-empty", "skip-det-only"} {
			t.Run(fmt.Sprintf("%T/%s", src, mode), func(t *testing.T) {
				config := rapidOCRInferConfig{padding: 50, maxSideLen: 960, boxThresh: .3, skipDet: mode != "full-empty"}
				limit := uint64(512 * 1024)
				if mode == "recognize" || mode == "skip-det-only" {
					config.detBoxes = []rapidOCRDetBox{nativeOCRRegionBox(90, 85, 450, 75)}
				}
				config.detOnly = mode == "skip-det-only"
				if mode == "full-empty" {
					want, _ := referenceNativeOCRDetectorInput(src, config)
					limit += uint64(len(want.Pix))
				}
				r := nativeOCRFusedDetectorRuntime([]float32{0}, 1, 1, false)
				runtime.GC()
				var before, after runtime.MemStats
				runtime.ReadMemStats(&before)
				for i := 0; i < 3; i++ {
					if _, _, err := r.inferRapidOCR(modelClassOCR, src, config); err != nil {
						t.Fatal(err)
					}
				}
				runtime.ReadMemStats(&after)
				if got := (after.TotalAlloc - before.TotalAlloc) / 3; got > limit {
					t.Fatalf("allocated %d bytes/image, budget %d; whole crop canvas remains", got, limit)
				}
			})
		}
	}
}

// Construct the original full white canvas independently, then use the frozen
// generic crop oracle and imaging's original Linear resize for every tensor.
func assertNativeOCRRegionInput(t *testing.T, src image.Image, padding int, boxes []rapidOCRDetBox, modern bool) {
	t.Helper()
	p := max(padding, 0)
	full := imaging.Paste(imaging.New(src.Bounds().Dx()+2*p, src.Bounds().Dy()+2*p, color.White), src, image.Pt(p, p))
	wants := make([]*image.NRGBA, len(boxes))
	for i, box := range boxes {
		crop, err := referenceRapidOCRCrop(full, box)
		if err != nil {
			t.Fatal(err)
		}
		width := max(1, int(math.Round(float64(crop.Rect.Dx())*48/float64(crop.Rect.Dy()))))
		wants[i] = imaging.Resize(crop, width, 48, imaging.Linear)
	}
	r := nativeOCRFusedDetectorRuntime([]float32{0}, 1, 1, modern)
	calls := 0
	r.base.bindings.matFromPixels = func(pixels *byte, kind, w, h, stride int32, _ uintptr) uintptr {
		if calls >= len(wants) {
			t.Error("unexpected recognizer call")
			return 1
		}
		want := wants[calls]
		calls++
		wantKind := nativeMatPixelRGBA2RGB
		if modern {
			wantKind = nativeMatPixelRGBA2BGR
		}
		if kind != wantKind || int(w) != want.Rect.Dx() || int(h) != want.Rect.Dy() || int(stride) != want.Stride || !bytes.Equal(unsafe.Slice(pixels, len(want.Pix)), want.Pix) {
			t.Errorf("%T bounds=%v padding=%d box=%d: recognition tensor changed", src, src.Bounds(), padding, calls-1)
		}
		return 1
	}
	config := rapidOCRInferConfig{padding: padding, skipDet: true, detBoxes: boxes}
	got, lines, err := r.inferRapidOCR(modelClassOCR, src, config)
	if err != nil || calls != len(boxes) || len(lines) != len(boxes) {
		t.Fatalf("error=%v calls=%d lines=%d", err, calls, len(lines))
	}
	assertNativeOCRBoxesEqual(t, got, boxes)
}

func TestNativeOCRRegionMatchesOriginalInput(t *testing.T) {
	previous := runtime.GOMAXPROCS(1)
	defer runtime.GOMAXPROCS(previous)
	random := rand.New(rand.NewSource(20261020))
	for _, src := range append(nativePixelTestSources(), nativePerformanceImage(1, 1), nativePerformanceImage(71, 45)) {
		before := imaging.Clone(src)
		for _, padding := range []int{-1, 0, 1, 50} {
			w, h := float64(src.Bounds().Dx()+2*max(padding, 0)), float64(src.Bounds().Dy()+2*max(padding, 0))
			boxes := []rapidOCRDetBox{
				nativeOCRRegionBox(w*.25, h*.25, max(1, w*.3), max(1, h*.2)),
				nativeOCRRegionBox(-6.5, -4.25, 12.5, 8.75),
				nativeOCRRegionBox(w-2.25, h-3.75, 8.5, 10.25),
				nativeOCRRegionBox(w+4, h+2, 2, 4),
				nativeOCRRegionBox(0, 0, 1, max(2, h-1)),
			}
			for i := 0; i < 5; i++ {
				box := nativeOCRRegionBox(random.Float64()*w-2, random.Float64()*h-2, 2+random.Float64()*w*.5, 2+random.Float64()*h*.5)
				box.points[1].y += 1.25
				box.points[2].x -= .75
				boxes = append(boxes, box)
			}
			for _, modern := range []bool{false, true} {
				// Individual boxes exercise small regions; their union covers the
				// multi-box canvas and both original padded image boundaries.
				for _, box := range boxes {
					assertNativeOCRRegionInput(t, src, padding, []rapidOCRDetBox{box}, modern)
				}
				assertNativeOCRRegionInput(t, src, padding, boxes, modern)
			}
		}
		if !bytes.Equal(imaging.Clone(src).Pix, before.Pix) {
			t.Fatal("source pixels changed")
		}
	}
}

func TestNativeOCRRegionConcurrentOwnership(t *testing.T) {
	_, jpeg := nativePerformanceJPEG(t, 193, 129)
	for _, src := range []image.Image{nativePerformanceImage(193, 129), jpeg} {
		before := imaging.Clone(src)
		var pending sync.WaitGroup
		for i := 0; i < 8; i++ {
			pending.Add(1)
			go func() {
				defer pending.Done()
				assertNativeOCRRegionInput(t, src, 50, []rapidOCRDetBox{nativeOCRRegionBox(60.25, 58.75, 90, 22)}, false)
			}()
		}
		pending.Wait()
		if !bytes.Equal(imaging.Clone(src).Pix, before.Pix) {
			t.Fatal("concurrent inference modified source")
		}
	}
}

func TestNativeOCRRegionFullPipelineTensors(t *testing.T) {
	previous := runtime.GOMAXPROCS(1)
	defer runtime.GOMAXPROCS(previous)
	probabilities, width, height := nativeOCRProbabilityMap("text")
	_, jpeg := nativePerformanceJPEG(t, 193, 129)
	_, aligned := nativePerformanceJPEG(t, 188, 124)
	for _, procs := range []int{1, 4} {
		runtime.GOMAXPROCS(procs)
		for _, src := range []image.Image{nativePerformanceImage(193, 129), jpeg, aligned, image.NewGray(image.Rect(-3, -5, 61, 59))} {
			config := rapidOCRInferConfig{padding: 50, maxSideLen: 960, boxThresh: .3, boxScoreThresh: .6, unclipRatio: 1.6}
			prepared, scale := referenceNativeOCRDetectorInput(src, config)
			scale.ratioWidth, scale.ratioHeight = float64(width)/float64(scale.sourceWidth), float64(height)/float64(scale.sourceHeight)
			boxes := referenceRapidOCRBoxesFromProbabilityMap(probabilities, width, height, scale, config.boxScoreThresh, config.boxThresh, config.unclipRatio)
			if len(boxes) == 0 {
				t.Fatal("full pipeline fixture has no text boxes")
			}
			full := imaging.Paste(imaging.New(src.Bounds().Dx()+100, src.Bounds().Dy()+100, color.White), src, image.Pt(50, 50))
			wants := []*image.NRGBA{prepared}
			for _, box := range boxes {
				crop, err := referenceRapidOCRCrop(full, box)
				if err != nil {
					t.Fatal(err)
				}
				targetWidth := max(1, int(math.Round(float64(crop.Rect.Dx())*48/float64(crop.Rect.Dy()))))
				wants = append(wants, imaging.Resize(crop, targetWidth, 48, imaging.Linear))
			}
			r := nativeOCRFusedDetectorRuntime(probabilities, width, height, false)
			calls := 0
			r.base.bindings.matFromPixels = func(p *byte, kind, w, h, stride int32, _ uintptr) uintptr {
				if calls >= len(wants) {
					t.Error("unexpected full pipeline call")
					return 1
				}
				want := wants[calls]
				calls++
				if kind != nativeMatPixelRGBA2RGB || int(w) != want.Rect.Dx() || int(h) != want.Rect.Dy() || int(stride) != want.Stride || !bytes.Equal(unsafe.Slice(p, len(want.Pix)), want.Pix) {
					t.Errorf("%T cpu=%d tensor=%d differs from original pipeline", src, procs, calls-1)
				}
				return 1
			}
			got, lines, err := r.inferRapidOCR(modelClassOCR, src, config)
			if err != nil || calls != len(wants) || len(lines) != len(boxes) {
				t.Fatalf("full pipeline error=%v calls=%d lines=%d", err, calls, len(lines))
			}
			assertNativeOCRBoxesEqual(t, got, boxes)
		}
	}
}

func TestNativeOCRRegionPreservesCropErrors(t *testing.T) {
	for _, box := range []rapidOCRDetBox{{}, {points: [4]rapidOCRPoint{{math.NaN(), 1}, {2, 1}, {2, 2}, {1, 2}}}} {
		r := nativeOCRFusedDetectorRuntime([]float32{0}, 1, 1, false)
		_, _, err := r.inferRapidOCR(modelClassOCR, nativePerformanceImage(10, 10), rapidOCRInferConfig{padding: 3, skipDet: true, detBoxes: []rapidOCRDetBox{box}})
		if err == nil || err.Error() != "crop rapidocr box 0: rapidocr crop box has zero area" {
			t.Fatalf("crop error changed: %v", err)
		}
	}
}

func BenchmarkNativeOCRRegionPreparation(b *testing.B) {
	_, jpeg := nativePerformanceJPEG(b, 768, 512)
	_, large := nativePerformanceJPEG(b, 1536, 1024)
	_, aligned := nativePerformanceJPEG(b, 764, 508)
	for _, tc := range []struct {
		name string
		src  image.Image
		skip bool
	}{
		{"recognize-jpeg", jpeg, true}, {"recognize-nrgba", nativePerformanceImage(768, 512), true},
		{"recognize-large-jpeg", large, true}, {"full-empty-jpeg", jpeg, false},
		{"full-empty-large-jpeg", large, false}, {"full-aligned-control", aligned, false},
	} {
		b.Run(tc.name, func(b *testing.B) {
			r := nativeOCRFusedDetectorRuntime([]float32{0}, 1, 1, false)
			config := rapidOCRInferConfig{padding: 50, maxSideLen: 960, skipDet: tc.skip, boxThresh: .3}
			if tc.skip {
				config.detBoxes = []rapidOCRDetBox{nativeOCRRegionBox(90, 85, 450, 75)}
			}
			b.ReportAllocs()
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				if _, _, err := r.inferRapidOCR(modelClassOCR, tc.src, config); err != nil {
					b.Fatal(err)
				}
			}
		})
	}
}
