package main

import (
	"bytes"
	"image"
	"image/draw"
	"math"
	"runtime"
	"sync"
)

// Linear weights, alpha arithmetic and byte rounding follow imaging v1.6.2.
// Adapted from github.com/disintegration/imaging (MIT):
// Copyright (c) 2012 Grigory Dryapak
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

type rapidOCRLinearWeight struct {
	index  int
	weight float64
}

func rapidOCRLinearWeights(dstSize, srcSize int) [][]rapidOCRLinearWeight {
	du := float64(srcSize) / float64(dstSize)
	scale := math.Max(du, 1)
	ru := math.Ceil(scale)
	weights := make([][]rapidOCRLinearWeight, dstSize)
	storage := make([]rapidOCRLinearWeight, 0, dstSize*int(math.Ceil(2*scale)))
	for v := range weights {
		fu := (float64(v)+0.5)*du - 0.5
		begin := max(0, int(math.Ceil(fu-ru)))
		end := min(srcSize-1, int(math.Floor(fu+ru)))
		start := len(storage)
		var sum float64
		for u := begin; u <= end; u++ {
			x := math.Abs((float64(u) - fu) / scale)
			if x < 1 {
				w := 1 - x
				sum += w
				storage = append(storage, rapidOCRLinearWeight{index: u, weight: w})
			}
		}
		row := storage[start:]
		if sum != 0 {
			for i := range row {
				row[i].weight /= sum
			}
		}
		weights[v] = row
	}
	return weights
}

func rapidOCRLinearByte(value float64) uint8 {
	v := int64(value + 0.5)
	if v > 255 {
		return 255
	}
	if v > 0 {
		return uint8(v)
	}
	return 0
}

func rapidOCRLinearRow(dst, source []byte, weights [][]rapidOCRLinearWeight) {
	for x, weights := range weights {
		var r, g, b, a float64
		for _, w := range weights {
			i := w.index * 4
			s := source[i : i+4 : i+4]
			aw := float64(s[3]) * w.weight
			r += float64(s[0]) * aw
			g += float64(s[1]) * aw
			b += float64(s[2]) * aw
			a += aw
		}
		i := x * 4
		d := dst[i : i+4 : i+4]
		if a == 0 {
			clear(d) // A recycled row must not retain an earlier opaque pixel.
			continue
		}
		aInv := 1 / a
		d[0] = rapidOCRLinearByte(r * aInv)
		d[1] = rapidOCRLinearByte(g * aInv)
		d[2] = rapidOCRLinearByte(b * aInv)
		d[3] = rapidOCRLinearByte(a)
	}
}

// Both axes must change and all dimensions must be positive. Preserve imaging's
// horizontal-then-vertical byte quantization, but retain only the horizontal
// rows needed by each worker's current vertical window, rather than a full image.
func rapidOCRResizeLinearNRGBA(source *image.NRGBA, width, height int) *image.NRGBA {
	return rapidOCRResizeLinearSource(rapidOCRLinearSource{nrgba: source, width: source.Rect.Dx(), height: source.Rect.Dy()}, width, height)
}

// The optional border is synthesized one row at a time. Coordinates and source
// strides match rapidOCRPadImage; no complete padded image needs to exist.
type rapidOCRLinearSource struct {
	nrgba         *image.NRGBA
	ycbcr         *image.YCbCr
	width, height int
	padding       int
}

func (source rapidOCRLinearSource) readRow(y int, row []byte, opaque *image.RGBA) []byte {
	if source.padding == 0 && source.nrgba != nil {
		offset := y * source.nrgba.Stride
		return source.nrgba.Pix[offset : offset+source.width*4]
	}
	if y < source.padding || y >= source.height-source.padding {
		for i := range row {
			row[i] = 255
		}
		return row
	}
	if source.nrgba != nil {
		offset := (y - source.padding) * source.nrgba.Stride
		copy(row[source.padding*4:], source.nrgba.Pix[offset:offset+source.nrgba.Rect.Dx()*4])
	} else {
		// The standard library converts YCbCr to these shared opaque NRGBA
		// bytes with exactly the same rounding as the full padded canvas.
		opaque.Rect = image.Rect(0, y, source.width, y+1)
		interior := image.Rect(source.padding, y, source.width-source.padding, y+1)
		point := source.ycbcr.Rect.Min.Add(image.Pt(0, y-source.padding))
		draw.Draw(opaque, interior, source.ycbcr, point, draw.Src)
	}
	return row
}

func rapidOCRResizeLinearSource(source rapidOCRLinearSource, width, height int) *image.NRGBA {
	dst := image.NewNRGBA(image.Rect(0, 0, width, height))
	nativeResizeLinearInto(source, width, height, dst.Pix, dst.Stride, 4)
	return dst
}

// Write the final quantized pixels into owned NRGBA (4 channels) or a visible
// RGB tensor rectangle (3 channels). Horizontal cache rows always retain alpha.
// Both source axes must change; the caller supplies valid dimensions/storage.
func nativeResizeLinearInto(source rapidOCRLinearSource, width, height int, pixels []byte, stride, channels int) {
	horizontal := rapidOCRLinearWeights(width, source.width)
	vertical := rapidOCRLinearWeights(height, source.height)
	windowRows := 0
	for _, weights := range vertical {
		windowRows = max(windowRows, len(weights))
	}
	rowBytes := width * 4
	outputRowBytes := width * channels
	writeRow := nativeResizeLinearNRGBARow
	if channels == 3 {
		writeRow = nativeResizeLinearRGBRow
	}
	process := func(start, end int) {
		cache := make([]byte, windowRows*rowBytes)
		indices := make([]int, windowRows)
		rows := make([][]byte, windowRows)
		var scan []byte
		var opaque *image.RGBA
		if source.padding != 0 || source.ycbcr != nil {
			scan = bytes.Repeat([]byte{255}, source.width*4)
			if source.ycbcr != nil {
				opaque = &image.RGBA{Pix: scan, Stride: source.width * 4}
			}
		}
		for i := range indices {
			indices[i] = -1
		}
		for y := start; y < end; y++ {
			weights := vertical[y]
			for i, w := range weights {
				slot := w.index % windowRows
				row := cache[slot*rowBytes : (slot+1)*rowBytes]
				if indices[slot] != w.index {
					rapidOCRLinearRow(row, source.readRow(w.index, scan, opaque), horizontal)
					indices[slot] = w.index
				}
				rows[i] = row
			}
			writeRow(pixels[y*stride:y*stride+outputRowBytes], rows, weights)
		}
	}
	workers := min(runtime.GOMAXPROCS(0), height)
	if workers == 1 {
		process(0, height)
		return
	}
	var pending sync.WaitGroup
	for worker := 0; worker < workers; worker++ {
		pending.Add(1)
		go func() {
			defer pending.Done()
			process(height*worker/workers, height*(worker+1)/workers)
		}()
	}
	pending.Wait()
}

// Select the fixed output format once per resize, rather than branching on
// channels for every pixel. Keep both filters' accumulation order identical.
func nativeResizeLinearNRGBARow(dst []byte, rows [][]byte, weights []rapidOCRLinearWeight) {
	for offset := 0; offset < len(dst); offset += 4 {
		var r, g, b, a float64
		for i, w := range weights {
			s := rows[i][offset : offset+4 : offset+4]
			aw := float64(s[3]) * w.weight
			r += float64(s[0]) * aw
			g += float64(s[1]) * aw
			b += float64(s[2]) * aw
			a += aw
		}
		d := dst[offset : offset+4 : offset+4]
		if a == 0 {
			clear(d)
			continue
		}
		aInv := 1 / a
		d[0] = rapidOCRLinearByte(r * aInv)
		d[1] = rapidOCRLinearByte(g * aInv)
		d[2] = rapidOCRLinearByte(b * aInv)
		d[3] = rapidOCRLinearByte(a)
	}
}

func nativeResizeLinearRGBRow(dst []byte, rows [][]byte, weights []rapidOCRLinearWeight) {
	for offset, output := 0, 0; output < len(dst); offset, output = offset+4, output+3 {
		var r, g, b, a float64
		for i, w := range weights {
			s := rows[i][offset : offset+4 : offset+4]
			aw := float64(s[3]) * w.weight
			r += float64(s[0]) * aw
			g += float64(s[1]) * aw
			b += float64(s[2]) * aw
			a += aw
		}
		d := dst[output : output+3 : output+3]
		if a == 0 {
			// The visible rectangle must overwrite prefilled padding, even
			// when imaging's quantized result is fully transparent black.
			clear(d)
			continue
		}
		aInv := 1 / a
		d[0] = rapidOCRLinearByte(r * aInv)
		d[1] = rapidOCRLinearByte(g * aInv)
		d[2] = rapidOCRLinearByte(b * aInv)
	}
}
