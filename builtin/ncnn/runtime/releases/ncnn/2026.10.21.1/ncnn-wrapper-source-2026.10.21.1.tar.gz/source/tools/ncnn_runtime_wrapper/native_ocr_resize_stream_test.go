package main

import (
	"bytes"
	"fmt"
	"image"
	"math/rand"
	"runtime"
	"sync"
	"testing"

	"github.com/disintegration/imaging"
)

func TestNativeOCRStreamingResizeAllocationBudget(t *testing.T) {
	previous := runtime.GOMAXPROCS(1)
	defer runtime.GOMAXPROCS(previous)
	for _, tc := range []struct{ sw, sh, dw, dh int }{{864, 612, 832, 576}, {450, 75, 288, 48}, {1536, 1024, 768, 512}} {
		t.Run(fmt.Sprintf("%dx%d-to-%dx%d", tc.sw, tc.sh, tc.dw, tc.dh), func(t *testing.T) {
			src := nativePerformanceImage(tc.sw, tc.sh)
			runtime.GC()
			var before, after runtime.MemStats
			runtime.ReadMemStats(&before)
			for i := 0; i < 3; i++ {
				dst := rapidOCRResizeInput(src, tc.dw, tc.dh)
				if dst.Rect != image.Rect(0, 0, tc.dw, tc.dh) {
					t.Fatal("invalid resized dimensions")
				}
			}
			runtime.ReadMemStats(&after)
			// Final pixels plus weights and bounded per-worker row windows.
			limit := uint64(tc.dw*tc.dh*4 + max(128*1024, (tc.dw+tc.dh)*256))
			if got := (after.TotalAlloc - before.TotalAlloc) / 3; got > limit {
				t.Fatalf("resize allocated %d bytes/image, budget %d", got, limit)
			}
		})
	}
}

func TestNativeOCRStreamingResizeMatchesImaging(t *testing.T) {
	defer runtime.GOMAXPROCS(runtime.GOMAXPROCS(0))
	random := rand.New(rand.NewSource(172026))
	for _, procs := range []int{1, 4} {
		old := runtime.GOMAXPROCS(procs)
		for _, size := range [][2]int{{1, 1}, {1, 13}, {17, 1}, {2, 3}, {7, 11}, {32, 31}, {65, 63}, {129, 65}} {
			parent := image.NewNRGBA(image.Rect(-7, -5, size[0]+6, size[1]+8))
			random.Read(parent.Pix)
			src := parent.SubImage(image.Rect(-3, -2, size[0]-3, size[1]-2)).(*image.NRGBA)
			before := append([]byte(nil), parent.Pix...)
			for _, dstSize := range [][2]int{{1, 1}, {1, 7}, {9, 1}, {2, 2}, {3, 5}, {8, 13}, {31, 32}, {64, 65}, {size[0], size[1]}, {size[0], 9}, {13, size[1]}, {0, 7}, {9, 0}, {0, 0}, {-1, 8}} {
				want := imaging.Resize(src, dstSize[0], dstSize[1], imaging.Linear)
				got := rapidOCRResizeInput(src, dstSize[0], dstSize[1])
				if got.Rect != want.Rect {
					t.Fatalf("bounds: %+v != %+v", got.Rect, want.Rect)
				}
				for y := 0; y < want.Rect.Dy(); y++ {
					if !bytes.Equal(got.Pix[y*got.Stride:y*got.Stride+want.Rect.Dx()*4], want.Pix[y*want.Stride:(y+1)*want.Stride]) {
						t.Fatalf("pixels differ: cpu=%d %v to %v row %d", procs, size, dstSize, y)
					}
				}
				if !bytes.Equal(parent.Pix, before) {
					t.Fatal("source mutated")
				}
				if dstSize[0] > 0 && dstSize[1] > 0 && dstSize != size && len(got.Pix) > 0 {
					got.Pix[0] ^= 255
					if !bytes.Equal(parent.Pix, before) {
						t.Fatal("resized output aliases source")
					}
				}
			}
		}
		runtime.GOMAXPROCS(old)
	}
	// Alpha endpoints, transparent hidden colors, and opaque rows.
	for _, alpha := range []uint8{0, 1, 127, 128, 254, 255} {
		src := nativePerformanceImage(61, 37)
		for i := 3; i < len(src.Pix); i += 4 {
			src.Pix[i] = alpha
		}
		want := imaging.Resize(src, 39, 23, imaging.Linear)
		got := rapidOCRResizeInput(src, 39, 23)
		if !bytes.Equal(got.Pix, want.Pix) {
			t.Fatalf("alpha %d changed", alpha)
		}
	}
	// Random ratios cover changing window lengths and wrapped row slots.
	for i := 0; i < 100; i++ {
		src := nativePerformanceImage(1+random.Intn(160), 1+random.Intn(120))
		random.Read(src.Pix)
		width, height := 1+random.Intn(150), 1+random.Intn(110)
		want := imaging.Resize(src, width, height, imaging.Linear)
		got := rapidOCRResizeInput(src, width, height)
		if !bytes.Equal(got.Pix, want.Pix) {
			t.Fatalf("random %v to %dx%d changed", src.Rect, width, height)
		}
	}
	for _, size := range [][4]int{{864, 612, 832, 576}, {450, 75, 288, 48}, {1536, 1024, 768, 512}, {511, 2049, 127, 33}, {3, 2, 257, 129}} {
		src := nativePerformanceImage(size[0], size[1])
		random.Read(src.Pix)
		want := imaging.Resize(src, size[2], size[3], imaging.Linear)
		got := rapidOCRResizeInput(src, size[2], size[3])
		if !bytes.Equal(got.Pix, want.Pix) {
			t.Fatalf("large ratio %v changed", size)
		}
	}
	for _, src := range []image.Image{image.NewRGBA(image.Rect(0, 0, 23, 17)), image.NewGray(image.Rect(0, 0, 23, 17)), image.NewNRGBA64(image.Rect(0, 0, 23, 17)), image.NewYCbCr(image.Rect(0, 0, 23, 17), image.YCbCrSubsampleRatio420), struct{ image.Image }{nativePerformanceImage(23, 17)}} {
		want := imaging.Resize(src, 13, 11, imaging.Linear)
		got := rapidOCRResizeInput(src, 13, 11)
		if !bytes.Equal(got.Pix, want.Pix) {
			t.Fatalf("fallback %T changed", src)
		}
	}
}

func TestNativeOCRStreamingResizeConcurrentOwnership(t *testing.T) {
	src := nativePerformanceImage(193, 129)
	before := append([]byte(nil), src.Pix...)
	want := imaging.Resize(src, 97, 65, imaging.Linear)
	var wg sync.WaitGroup
	for i := 0; i < 8; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			got := rapidOCRResizeInput(src, 97, 65)
			if !bytes.Equal(got.Pix, want.Pix) {
				t.Error("concurrent pixels differ")
			}
			clear(got.Pix)
		}()
	}
	wg.Wait()
	if !bytes.Equal(src.Pix, before) {
		t.Fatal("concurrent output aliases source")
	}
}

func BenchmarkNativeOCRStreamingResize(b *testing.B) {
	for _, tc := range []struct {
		name           string
		sw, sh, dw, dh int
	}{
		{"detector", 864, 612, 832, 576}, {"recognizer", 450, 75, 288, 48}, {"downscale", 1536, 1024, 768, 512},
		{"identity-control", 864, 608, 864, 608}, {"one-axis-control", 480, 75, 480, 48},
	} {
		src := nativePerformanceImage(tc.sw, tc.sh)
		b.Run(tc.name, func(b *testing.B) {
			b.ReportAllocs()
			for i := 0; i < b.N; i++ {
				dst := rapidOCRResizeInput(src, tc.dw, tc.dh)
				if dst.Rect.Dx() != tc.dw || dst.Rect.Dy() != tc.dh {
					b.Fatal("invalid dimensions")
				}
			}
		})
	}
}
