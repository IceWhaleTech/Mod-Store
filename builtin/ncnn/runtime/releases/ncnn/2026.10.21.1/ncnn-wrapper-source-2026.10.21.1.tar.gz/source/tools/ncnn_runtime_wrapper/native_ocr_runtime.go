package main

import (
	"bufio"
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"math"
	"os"
	"path"
	"path/filepath"
	"regexp"
	"runtime"
	"slices"
	"sort"
	"strconv"
	"strings"
	"sync"

	"github.com/disintegration/imaging"
)

const (
	nativeMatPixelBGR      int32 = 2
	nativeMatPixelRGBA2RGB int32 = 4 | (nativeMatPixelRGB << 16)
	nativeMatPixelRGBA2BGR int32 = 4 | (nativeMatPixelBGR << 16)
)

var rapidOCRTextLinePatternForWrapper = regexp.MustCompile(`textLine\[(\d+)\]\((.*)\)`)

type rapidOCRBundleLayout struct {
	runtimeBinaryName string
	detModel          string
	clsModel          string
	recModel          string
	keysPath          string
	defaultPadding    int
	defaultMaxSideLen int
	defaultBoxScore   float64
	defaultBoxThresh  float64
	defaultUnclip     float64
	defaultDoAngle    bool
	defaultMostAngle  bool
	modern            bool
}

type rapidOCRInferConfig struct {
	imagePath       string
	threadLimit     int
	padding         int
	maxSideLen      int
	boxScoreThresh  float64
	boxThresh       float64
	unclipRatio     float64
	doAngle         bool
	mostAngle       bool
	detailsOnlyHint bool
	detOnly         bool
	skipDet         bool
	detBoxes        []rapidOCRDetBox
}

type rapidOCRDetBox struct {
	confidence float64
	points     [4]rapidOCRPoint
}

type rapidOCRPoint struct {
	x float64
	y float64
}

type rapidOCRDetectorScale struct {
	sourceWidth  int
	sourceHeight int
	ratioWidth   float64
	ratioHeight  float64
}

type rapidOCRTextLine struct {
	text       string
	charScores []float32
}

func tryNativeOCRLoad(native nativeEmbeddingSpec, modelClass string, bundleDir string, req loadRequest, backendRequested []string) (loadResultPayload, bool, error) {
	if native.backend == nil || !strings.EqualFold(modelClassBase(modelClass), modelClassOCR) {
		return loadResultPayload{}, false, nil
	}
	options := resolveNativeEmbeddingLoadOptions(mergeBundleLoadMetadataForNativeRuntime(bundleDir, req.Metadata), req.ThreadLimit)
	if err := native.backend.load(modelClass, bundleDir, options); err != nil {
		return loadResultPayload{}, true, err
	}
	degradedToCPU := len(backendRequested) > 0 && !onlyCPUBackends(backendRequested)
	degradeReason := ""
	if degradedToCPU {
		degradeReason = "rapidocr_ncnn_cpu_only"
	}
	return loadResultPayload{
		loadResult: loadResult{
			BackendEffective: "cpu",
			DeviceEffective:  native.deviceID(),
			DegradedToCPU:    degradedToCPU,
			DegradeReason:    degradeReason,
		},
	}, true, nil
}

func tryNativeOCRInfer(state *wrapperRuntimeState, native nativeEmbeddingSpec, parsed inferRequest) (wrapperInferResult, bool) {
	modelClass := strings.TrimSpace(parsed.ModelClass)
	if native.backend == nil || !strings.EqualFold(modelClassBase(modelClass), modelClassOCR) {
		return wrapperInferResult{}, false
	}
	if !strings.EqualFold(strings.TrimSpace(parsed.Task), "ocr") {
		return wrapperInferResult{Output: map[string]interface{}{"ok": false, "error": "unsupported_task", "task": strings.TrimSpace(parsed.Task)}}, true
	}
	if state == nil {
		return wrapperInferResult{}, false
	}
	bundleDir, bundleID, ok := state.loadedBundle(modelClass)
	if !ok {
		return wrapperInferResult{Output: map[string]interface{}{
			"ok":             false,
			"error":          "ncnn_model_class_not_loaded",
			"degrade_reason": "rapidocr_ncnn_not_loaded",
			"model_class":    modelClass,
			"task":           strings.TrimSpace(parsed.Task),
			"loaded":         false,
		}}, true
	}
	layout, err := resolveRapidOCRBundleLayout(bundleDir)
	if err != nil {
		return rapidOCRInferError(modelClass, bundleID, parsed.Task, "rapidocr_ncnn_invalid_bundle", err), true
	}
	config, err := prepareRapidOCRInferConfig(layout, parsed)
	if err != nil {
		return rapidOCRInferError(modelClass, bundleID, parsed.Task, "rapidocr_ncnn_invalid_input", err), true
	}
	source, err := imaging.Open(config.imagePath, imaging.AutoOrientation(true))
	if err != nil {
		return rapidOCRInferError(modelClass, bundleID, parsed.Task, "rapidocr_ncnn_invalid_input", fmt.Errorf("open image %s: %w", config.imagePath, err)), true
	}
	boxes, textLines, err := native.backend.inferRapidOCR(modelClass, source, config)
	if err != nil {
		return rapidOCRInferError(modelClass, bundleID, parsed.Task, "rapidocr_ncnn_failed", err), true
	}
	rawOutput := formatRapidOCROutput(boxes, textLines, source.Bounds().Dx(), source.Bounds().Dy())
	lines := parseRapidOCRTextLines(rawOutput)
	text := strings.TrimSpace(strings.Join(lines, "\n"))
	output := map[string]interface{}{
		"ok":           true,
		"bundle_id":    bundleID,
		"model_class":  modelClass,
		"raw_output":   rawOutput,
		"text":         text,
		"ocr_text":     text,
		"result_text":  text,
		"lines":        lines,
		"details_only": config.detailsOnlyHint,
	}
	return wrapperInferResult{Output: output}, true
}

func rapidOCRInferError(modelClass, bundleID, task, reason string, err error) wrapperInferResult {
	return wrapperInferResult{Output: map[string]interface{}{
		"ok":             false,
		"error":          err.Error(),
		"degrade_reason": reason,
		"model_class":    modelClass,
		"bundle_id":      bundleID,
		"task":           strings.TrimSpace(task),
		"loaded":         true,
	}}
}

func resolveRapidOCRBundleLayout(bundleDir string) (rapidOCRBundleLayout, error) {
	metadata := readBundleMetadataForNativeRuntime(bundleDir)
	if len(metadata) == 0 {
		return rapidOCRBundleLayout{}, fmt.Errorf("rapidocr metadata.json is required")
	}
	pipeline := metadataMapValue(metadata["pipeline"])
	if len(pipeline) == 0 {
		return rapidOCRBundleLayout{}, fmt.Errorf("rapidocr pipeline metadata is required")
	}
	det := metadataMapValue(pipeline["det"])
	cls := metadataMapValue(pipeline["cls"])
	if len(cls) == 0 {
		cls = metadataMapValue(pipeline["ori"])
	}
	rec := metadataMapValue(pipeline["rec"])
	detParam, err := rapidOCRBundleRelativePath(metadataStringValue(det["param"]), "det param")
	if err != nil {
		return rapidOCRBundleLayout{}, err
	}
	detBin, err := rapidOCRBundleRelativePath(metadataStringValue(det["bin"]), "det bin")
	if err != nil {
		return rapidOCRBundleLayout{}, err
	}
	clsParam, err := rapidOCRBundleRelativePath(metadataStringValue(cls["param"]), "cls param")
	if err != nil {
		return rapidOCRBundleLayout{}, err
	}
	clsBin, err := rapidOCRBundleRelativePath(metadataStringValue(cls["bin"]), "cls bin")
	if err != nil {
		return rapidOCRBundleLayout{}, err
	}
	recParam, err := rapidOCRBundleRelativePath(metadataStringValue(rec["param"]), "rec param")
	if err != nil {
		return rapidOCRBundleLayout{}, err
	}
	recBin, err := rapidOCRBundleRelativePath(metadataStringValue(rec["bin"]), "rec bin")
	if err != nil {
		return rapidOCRBundleLayout{}, err
	}
	keysPath, err := rapidOCRBundleRelativePath(metadataStringValue(rec["keys"]), "rec keys")
	if err != nil {
		return rapidOCRBundleLayout{}, err
	}
	layout := rapidOCRBundleLayout{
		runtimeBinaryName: "",
		detModel:          rapidOCRModelArgument(detParam),
		clsModel:          rapidOCRModelArgument(clsParam),
		recModel:          rapidOCRModelArgument(recParam),
		keysPath:          keysPath,
		defaultPadding:    50,
		defaultMaxSideLen: 1024,
		defaultBoxScore:   0.5,
		defaultBoxThresh:  0.3,
		defaultUnclip:     1.6,
		defaultDoAngle:    true,
		defaultMostAngle:  true,
	}
	modelProfile := strings.ToLower(strings.TrimSpace(metadataStringValue(metadata["model_profile"])))
	layout.modern = modelProfile == "ppocrv5-mobile" ||
		(strings.Contains(layout.detModel, "PP-OCRv5_mobile") && strings.Contains(layout.recModel, "PP-OCRv5_mobile"))
	defaults := metadataMapValue(metadata["default_params"])
	if value, ok := metadataIntValue(defaults["padding"]); ok && value > 0 {
		layout.defaultPadding = value
	}
	if value, ok := metadataIntValue(defaults["max_side_len"]); ok && value > 0 {
		layout.defaultMaxSideLen = value
	}
	if value, ok := rapidOCRFloat64Value(defaults["box_score_thresh"]); ok && value > 0 {
		layout.defaultBoxScore = value
	}
	if value, ok := rapidOCRFloat64Value(defaults["box_thresh"]); ok && value > 0 {
		layout.defaultBoxThresh = value
	}
	if value, ok := rapidOCRFloat64Value(defaults["unclip_ratio"]); ok && value > 0 {
		layout.defaultUnclip = value
	}
	if value, ok := rapidOCRBoolValue(defaults["do_angle"]); ok {
		layout.defaultDoAngle = value
	}
	if value, ok := rapidOCRBoolValue(defaults["most_angle"]); ok {
		layout.defaultMostAngle = value
	}
	for _, relativePath := range []string{
		detParam,
		detBin,
		clsParam,
		clsBin,
		recParam,
		recBin,
		keysPath,
	} {
		artifact := filepath.Join(bundleDir, filepath.FromSlash(relativePath))
		if info, err := os.Stat(artifact); err != nil || info.IsDir() {
			if err != nil {
				return rapidOCRBundleLayout{}, fmt.Errorf("rapidocr bundle artifact missing: %s: %w", artifact, err)
			}
			return rapidOCRBundleLayout{}, fmt.Errorf("rapidocr bundle artifact %s is a directory", artifact)
		}
	}
	if layout.detModel == "" || layout.clsModel == "" || layout.recModel == "" || layout.keysPath == "" {
		return rapidOCRBundleLayout{}, fmt.Errorf("rapidocr pipeline metadata is incomplete")
	}
	return layout, nil
}

func rapidOCRModelArgument(value string) string {
	value = filepath.ToSlash(strings.TrimSpace(value))
	value = strings.TrimSuffix(value, filepath.Ext(value))
	return value
}

func rapidOCRBundleRelativePath(value string, field string) (string, error) {
	value = strings.TrimSpace(value)
	if value == "" || strings.Contains(value, `\\`) {
		return "", fmt.Errorf("rapidocr %s path must stay within the bundle", strings.TrimSpace(field))
	}
	cleaned := path.Clean(filepath.ToSlash(value))
	if cleaned == "." || cleaned == ".." || path.IsAbs(cleaned) || strings.HasPrefix(cleaned, "../") {
		return "", fmt.Errorf("rapidocr %s path must stay within the bundle: %q", strings.TrimSpace(field), value)
	}
	return cleaned, nil
}

func prepareRapidOCRInferConfig(layout rapidOCRBundleLayout, parsed inferRequest) (rapidOCRInferConfig, error) {
	imagePath := strings.TrimSpace(metadataStringValue(parsed.Input["image"]))
	if imagePath == "" {
		return rapidOCRInferConfig{}, fmt.Errorf("rapidocr input.image is required")
	}
	params := metadataMapValue(parsed.Input["params"])
	config := rapidOCRInferConfig{
		imagePath:      imagePath,
		threadLimit:    parsed.ThreadLimit,
		padding:        layout.defaultPadding,
		maxSideLen:     layout.defaultMaxSideLen,
		boxScoreThresh: layout.defaultBoxScore,
		boxThresh:      layout.defaultBoxThresh,
		unclipRatio:    layout.defaultUnclip,
		doAngle:        layout.defaultDoAngle,
		mostAngle:      layout.defaultMostAngle,
	}
	if config.threadLimit <= 0 {
		config.threadLimit = 4
	}
	if value, ok := metadataIntValue(params["padding"]); ok && value >= 0 {
		config.padding = value
	}
	if value, ok := metadataIntValue(params["max_side_len"]); ok && value > 0 {
		config.maxSideLen = value
	}
	if value, ok := rapidOCRFloat64Value(params["box_score_thresh"]); ok && value > 0 {
		config.boxScoreThresh = value
	}
	if value, ok := rapidOCRFloat64Value(params["box_thresh"]); ok && value > 0 {
		config.boxThresh = value
	}
	if value, ok := rapidOCRFloat64Value(params["unclip_ratio"]); ok && value > 0 {
		config.unclipRatio = value
	}
	if value, ok := rapidOCRBoolValue(params["do_angle"]); ok {
		config.doAngle = value
	}
	if value, ok := rapidOCRBoolValue(params["most_angle"]); ok {
		config.mostAngle = value
	}
	if value, ok := rapidOCRBoolValue(params["details_only"]); ok {
		config.detailsOnlyHint = value
	}
	if value, ok := rapidOCRBoolValue(params["det_only"]); ok {
		config.detOnly = value
	}
	runDet := rapidOCRBoolParam(params, "run_det", true)
	runCls := rapidOCRBoolParam(params, "run_cls", true)
	runRec := rapidOCRBoolParam(params, "run_rec", true)
	if config.detailsOnlyHint && runDet && !runCls && !runRec {
		config.detOnly = true
	}
	wantsSkipDet := rapidOCRBoolParam(params, "skip_det", false) || rapidOCRBoolParam(params, "reuse_det_boxes", false)
	if wantsSkipDet {
		config.detBoxes = parseRapidOCRDetBoxes(params["det_boxes"])
		if len(config.detBoxes) == 0 {
			return rapidOCRInferConfig{}, fmt.Errorf("det_boxes must contain at least one four-point RapidOCR detection box")
		}
		config.skipDet = true
	}
	return config, nil
}

func rapidOCRReadKeys(bundleDir string, layout rapidOCRBundleLayout) ([]string, error) {
	keysFile := filepath.Join(strings.TrimSpace(bundleDir), filepath.FromSlash(layout.keysPath))
	raw, err := os.ReadFile(keysFile)
	if err != nil {
		return nil, fmt.Errorf("read rapidocr keys %s: %w", keysFile, err)
	}
	lines := strings.Split(strings.ReplaceAll(string(raw), "\r\n", "\n"), "\n")
	keys := make([]string, 0, len(lines)+2)
	if !layout.modern {
		keys = append(keys, "#")
	}
	for _, line := range lines {
		line = strings.TrimSuffix(line, "\r")
		if line != "" {
			keys = append(keys, line)
		}
	}
	if !layout.modern {
		keys = append(keys, " ")
	}
	if len(keys) == 0 {
		return nil, fmt.Errorf("rapidocr keys file %s was empty", keysFile)
	}
	return keys, nil
}

func (r *nativeEmbeddingRuntime) inferRapidOCR(modelClass string, source image.Image, config rapidOCRInferConfig) ([]rapidOCRDetBox, []rapidOCRTextLine, error) {
	if r == nil || r.base == nil {
		return nil, nil, fmt.Errorf("native OCR backend unavailable")
	}
	model, unlockModel := r.lockLoadedModelForInfer(modelClass)
	if unlockModel != nil {
		defer unlockModel()
	}
	if model == nil || model.net == 0 || model.splitHeadNet == 0 {
		return nil, nil, fmt.Errorf("native OCR model class %s is not loaded", strings.TrimSpace(modelClass))
	}
	if source == nil || source.Bounds().Dx() <= 0 || source.Bounds().Dy() <= 0 {
		return nil, nil, fmt.Errorf("rapidocr source image is empty")
	}
	var padded *image.NRGBA
	boxes := append([]rapidOCRDetBox(nil), config.detBoxes...)
	if !config.skipDet {
		var err error
		boxes, padded, err = r.detectRapidOCRSource(model, source, config)
		if err != nil {
			return nil, nil, err
		}
	}
	if config.detOnly || len(boxes) == 0 {
		return boxes, nil, nil
	}
	if padded == nil {
		padded = rapidOCRCropCanvas(source, config.padding, boxes)
	}

	lines := make([]rapidOCRTextLine, 0, len(boxes))
	for index, box := range boxes {
		crop, err := rapidOCRCropImage(padded, box)
		if err != nil {
			return nil, nil, fmt.Errorf("crop rapidocr box %d: %w", index, err)
		}
		line, err := r.recognizeRapidOCR(model, crop, config.threadLimit)
		if err != nil {
			return nil, nil, fmt.Errorf("recognize rapidocr box %d: %w", index, err)
		}
		lines = append(lines, line)
	}
	return boxes, lines, nil
}

func (r *nativeEmbeddingRuntime) detectRapidOCR(model *nativeEmbeddingModel, padded image.Image, config rapidOCRInferConfig) ([]rapidOCRDetBox, error) {
	targetMaxSide := rapidOCRDetectorTargetMaxSide(padded.Bounds().Dx(), padded.Bounds().Dy(), config.padding, config.maxSideLen)
	prepared, scale, err := prepareRapidOCRDetectorImage(padded, targetMaxSide)
	if err != nil {
		return nil, err
	}
	return r.detectRapidOCRPrepared(model, prepared, scale, config)
}

// Stream supported source rows through the original two-pass filter. If a full
// canvas was needed for a fallback, return it for the subsequent crop stage.
func (r *nativeEmbeddingRuntime) detectRapidOCRSource(model *nativeEmbeddingModel, source image.Image, config rapidOCRInferConfig) ([]rapidOCRDetBox, *image.NRGBA, error) {
	padding := max(config.padding, 0)
	linear := rapidOCRLinearSource{padding: padding, width: source.Bounds().Dx() + 2*padding, height: source.Bounds().Dy() + 2*padding}
	switch src := source.(type) {
	case *image.NRGBA:
		linear.nrgba = src
	case *image.YCbCr:
		linear.ycbcr = src
	}
	if linear.width > 0 && linear.height > 0 && (linear.nrgba != nil || linear.ycbcr != nil) {
		targetMaxSide := rapidOCRDetectorTargetMaxSide(linear.width, linear.height, config.padding, config.maxSideLen)
		width, height := rapidOCRDetectorTargetSize(linear.width, linear.height, targetMaxSide)
		if width != linear.width && height != linear.height {
			prepared := rapidOCRResizeLinearSource(linear, width, height)
			scale := rapidOCRDetectorScale{sourceWidth: linear.width, sourceHeight: linear.height}
			boxes, err := r.detectRapidOCRPrepared(model, prepared, scale, config)
			return boxes, nil, err
		}
	}
	padded := rapidOCRPadImage(source, config.padding)
	boxes, err := r.detectRapidOCR(model, padded, config)
	return boxes, padded, err
}

// Only the union of sampled text regions needs pixels for recognition. Keep
// coordinates in the original padded space so the crop's interpolation and
// rounding stay unchanged. A halo covers both bilinear neighbors and rounding
// at a corner. This is called only for nonempty boxes and a nonempty source.
func rapidOCRCropCanvas(source image.Image, padding int, boxes []rapidOCRDetBox) *image.NRGBA {
	switch source.(type) {
	case *image.NRGBA, *image.YCbCr:
	default:
		return rapidOCRPadImage(source, padding)
	}
	padding = max(padding, 0)
	bounds := source.Bounds()
	width, height := bounds.Dx()+2*padding, bounds.Dy()+2*padding
	if width <= 0 || height <= 0 {
		return rapidOCRPadImage(source, padding)
	}
	region := image.Rectangle{Min: image.Pt(width, height)}
	for _, box := range boxes {
		for _, point := range box.points {
			if math.IsNaN(point.x) || math.IsNaN(point.y) || math.IsInf(point.x, 0) || math.IsInf(point.y, 0) {
				return rapidOCRPadImage(source, padding)
			}
			x := int(math.Floor(rapidOCRClamp(point.x, 0, float64(width-1))))
			y := int(math.Floor(rapidOCRClamp(point.y, 0, float64(height-1))))
			region.Min.X, region.Min.Y = min(region.Min.X, max(0, x-1)), min(region.Min.Y, max(0, y-1))
			region.Max.X, region.Max.Y = max(region.Max.X, min(width, x+3)), max(region.Max.Y, min(height, y+3))
		}
	}
	interior := image.Rect(padding, padding, padding+bounds.Dx(), padding+bounds.Dy())
	translation := bounds.Min.Sub(image.Pt(padding, padding))
	if src, ok := source.(*image.NRGBA); ok && region.In(interior) {
		// The crop sampler only reads. Borrow a header over these visible
		// pixels; the final crop and model input still have owned storage.
		view := *src.SubImage(region.Add(translation)).(*image.NRGBA)
		view.Rect = region
		return &view
	}
	canvas := image.NewNRGBA(region)
	if !region.In(interior) {
		for i := range canvas.Pix {
			canvas.Pix[i] = 255
		}
	}
	visible := region.Intersect(interior)
	if !visible.Empty() {
		point := visible.Min.Add(translation)
		if _, ok := source.(*image.YCbCr); ok {
			// Match the full canvas's standard-library opaque conversion,
			// including chroma phase for odd origins and parent strides.
			opaque := &image.RGBA{Pix: canvas.Pix, Stride: canvas.Stride, Rect: canvas.Rect}
			draw.Draw(opaque, visible, source, point, draw.Src)
		} else {
			draw.Draw(canvas, visible, source, point, draw.Src)
		}
	}
	return canvas
}

func (r *nativeEmbeddingRuntime) detectRapidOCRPrepared(model *nativeEmbeddingModel, prepared *image.NRGBA, scale rapidOCRDetectorScale, config rapidOCRInferConfig) ([]rapidOCRDetBox, error) {
	pixelType := nativeMatPixelRGBA2RGB
	if model.ocrProfile.modern {
		pixelType = nativeMatPixelRGBA2BGR
	}
	var boxes []rapidOCRDetBox
	err := r.withRapidOCRNetOutput(
		model, model.net, prepared.Pix, prepared.Bounds().Dx(), prepared.Bounds().Dy(), prepared.Stride, pixelType,
		rapidOCRInputBlobName(model.ocrProfile), rapidOCROutputBlobName(model.ocrProfile),
		[]float32{0.485 * 255, 0.456 * 255, 0.406 * 255},
		[]float32{1 / (0.229 * 255), 1 / (0.224 * 255), 1 / (0.225 * 255)}, config.threadLimit,
		func(values []float32, outputWidth, outputHeight int) error {
			if outputWidth <= 0 || outputHeight <= 0 || len(values) < outputWidth*outputHeight {
				return fmt.Errorf("rapidocr detector returned invalid %dx%d output with %d values", outputWidth, outputHeight, len(values))
			}
			scale.ratioWidth = float64(outputWidth) / float64(scale.sourceWidth)
			scale.ratioHeight = float64(outputHeight) / float64(scale.sourceHeight)
			boxes = rapidOCRBoxesFromProbabilityMap(values[:outputWidth*outputHeight], outputWidth, outputHeight, scale, config.boxScoreThresh, config.boxThresh, config.unclipRatio)
			return nil
		},
	)
	return boxes, err
}

func (r *nativeEmbeddingRuntime) recognizeRapidOCR(model *nativeEmbeddingModel, crop image.Image, threadLimit int) (rapidOCRTextLine, error) {
	height := crop.Bounds().Dy()
	width := crop.Bounds().Dx()
	if width <= 0 || height <= 0 {
		return rapidOCRTextLine{}, fmt.Errorf("rapidocr recognition crop is empty")
	}
	targetWidth := int(math.Round(float64(width) * 48 / float64(height)))
	if targetWidth < 1 {
		targetWidth = 1
	}
	prepared := rapidOCRResizeInput(crop, targetWidth, 48)
	pixelType := nativeMatPixelRGBA2RGB
	if model.ocrProfile.modern {
		pixelType = nativeMatPixelRGBA2BGR
	}
	var line rapidOCRTextLine
	err := r.withRapidOCRNetOutput(
		model, model.splitHeadNet, prepared.Pix, targetWidth, 48, prepared.Stride, pixelType,
		rapidOCRInputBlobName(model.ocrProfile), rapidOCROutputBlobName(model.ocrProfile),
		[]float32{127.5, 127.5, 127.5}, []float32{1 / 127.5, 1 / 127.5, 1 / 127.5}, threadLimit,
		func(values []float32, columns, rows int) error {
			line.text, line.charScores = rapidOCRDecodeCTCWithScores(values, rows, columns, model.ocrKeys, model.ocrProfile.modern)
			return nil
		},
	)
	return line, err
}

func rapidOCRInputBlobName(layout rapidOCRBundleLayout) string {
	if layout.modern {
		return "in0"
	}
	return "input"
}

func rapidOCROutputBlobName(layout rapidOCRBundleLayout) string {
	if layout.modern {
		return "out0"
	}
	return "output"
}

func rapidOCRPadImage(source image.Image, padding int) *image.NRGBA {
	if padding < 0 {
		padding = 0
	}
	bounds := source.Bounds()
	canvas := imaging.New(bounds.Dx()+2*padding, bounds.Dy()+2*padding, color.NRGBA{R: 255, G: 255, B: 255, A: 255})
	interior := bounds.Sub(bounds.Min).Add(image.Pt(padding, padding))
	switch source.(type) {
	case *image.NRGBA:
		draw.Draw(canvas, interior, source, bounds.Min, draw.Src)
	case *image.YCbCr:
		// JPEG pixels are opaque, so an RGBA header shares the exact NRGBA
		// bytes while enabling the standard library's YCbCr conversion path.
		opaque := &image.RGBA{Pix: canvas.Pix, Stride: canvas.Stride, Rect: canvas.Rect}
		workers := min(runtime.GOMAXPROCS(0), bounds.Dy())
		if workers <= 1 {
			draw.Draw(opaque, interior, source, bounds.Min, draw.Src)
			break
		}
		// Keep the previous parallel JPEG conversion, using disjoint row
		// bands and a bounded worker count instead of cloning the canvas.
		var pending sync.WaitGroup
		for worker := 0; worker < workers; worker++ {
			start, end := bounds.Dy()*worker/workers, bounds.Dy()*(worker+1)/workers
			pending.Add(1)
			go func() {
				defer pending.Done()
				band := image.Rect(interior.Min.X, interior.Min.Y+start, interior.Max.X, interior.Min.Y+end)
				draw.Draw(opaque, band, source, bounds.Min.Add(image.Pt(0, start)), draw.Src)
			}()
		}
		pending.Wait()
	default:
		// Preserve imaging's unpremultiplication and 16-bit rounding for
		// less common inputs. Its conversion can differ from image/draw.
		return imaging.Paste(canvas, source, image.Pt(padding, padding))
	}
	return canvas
}

// rapidOCRResizeInput may borrow an unchanged NRGBA input. Callers must treat
// the returned pixels as read-only until synchronous NCNN input conversion
// finishes. Dual-axis NRGBA resizing streams imaging-equivalent Linear rows;
// other image types and single-axis resizing retain the original implementation.
func rapidOCRResizeInput(source image.Image, width, height int) *image.NRGBA {
	if src, ok := source.(*image.NRGBA); ok && width > 0 && height > 0 && src.Rect.Dx() == width && src.Rect.Dy() == height {
		if src.Rect.Min == (image.Point{}) {
			return src
		}
		// Subimage Pix starts at its visible top-left. Normalize only the
		// header; preserve its parent stride for NCNN's strided conversion.
		return &image.NRGBA{Pix: src.Pix, Stride: src.Stride, Rect: image.Rect(0, 0, width, height)}
	}
	if src, ok := source.(*image.NRGBA); ok && width > 0 && height > 0 && src.Rect.Dx() > 0 && src.Rect.Dy() > 0 && src.Rect.Dx() != width && src.Rect.Dy() != height {
		return rapidOCRResizeLinearNRGBA(src, width, height)
	}
	return imaging.Resize(source, width, height, imaging.Linear)
}

func prepareRapidOCRDetectorImage(source image.Image, targetMaxSide int) (*image.NRGBA, rapidOCRDetectorScale, error) {
	if source == nil || source.Bounds().Dx() <= 0 || source.Bounds().Dy() <= 0 {
		return nil, rapidOCRDetectorScale{}, fmt.Errorf("rapidocr detector source image is empty")
	}
	width := source.Bounds().Dx()
	height := source.Bounds().Dy()
	targetWidth, targetHeight := rapidOCRDetectorTargetSize(width, height, targetMaxSide)
	prepared := rapidOCRResizeInput(source, targetWidth, targetHeight)
	return prepared, rapidOCRDetectorScale{
		sourceWidth:  width,
		sourceHeight: height,
		ratioWidth:   float64(targetWidth) / float64(width),
		ratioHeight:  float64(targetHeight) / float64(height),
	}, nil
}

func rapidOCRDetectorTargetSize(width, height, targetMaxSide int) (int, int) {
	if targetMaxSide <= 0 {
		targetMaxSide = max(width, height)
	}
	ratio := float64(targetMaxSide) / float64(max(width, height))
	return max(32, int(float64(width)*ratio)/32*32), max(32, int(float64(height)*ratio)/32*32)
}

func rapidOCRDetectorTargetMaxSide(paddedWidth, paddedHeight, padding, requestedMaxSide int) int {
	padding = max(padding, 0)
	sourceMaxSide := max(paddedWidth-2*padding, paddedHeight-2*padding)
	if sourceMaxSide <= 0 {
		sourceMaxSide = max(paddedWidth, paddedHeight)
	}
	if requestedMaxSide <= 0 || requestedMaxSide > sourceMaxSide {
		requestedMaxSide = sourceMaxSide
	}
	return requestedMaxSide + 2*padding
}

func rapidOCRPixels(source image.Image, bgr bool) []byte {
	return nativeImageRGBPixels(source, bgr)
}

func formatRapidOCROutput(boxes []rapidOCRDetBox, lines []rapidOCRTextLine, width, height int) string {
	var builder strings.Builder
	fmt.Fprintf(&builder, "ImageSize(%d,%d)\n", width, height)
	for index, box := range boxes {
		fmt.Fprintf(&builder, "TextBox[%d](+padding)[score(%s),", index, strconv.FormatFloat(box.confidence, 'f', 6, 64))
		for pointIndex, point := range box.points {
			if pointIndex > 0 {
				builder.WriteString(", ")
			}
			fmt.Fprintf(&builder, "[x: %d, y: %d]", int(math.Round(point.x)), int(math.Round(point.y)))
		}
		builder.WriteString("]\n")
		if index < len(lines) {
			fmt.Fprintf(&builder, "textLine[%d](%s)\n", index, lines[index].text)
		}
	}
	return strings.TrimSpace(builder.String())
}

type rapidOCRRotatedRect struct {
	center     rapidOCRPoint
	axisWidth  rapidOCRPoint
	axisHeight rapidOCRPoint
	halfWidth  float64
	halfHeight float64
}

// Hull storage is borrowed only while decoding one component. The boundary
// points are owned scratch too, so sorting and deduplicating them is safe.
type rapidOCRGeometryScratch struct {
	hull []rapidOCRPoint
}

// Keep only the pending BFS frontier. Completed pixels contribute their score
// and boundary corners immediately, so their indices need not be retained.
type rapidOCRComponentScratch struct {
	queue    []int
	head     int
	pending  int
	boundary []rapidOCRPoint
}

func (scratch *rapidOCRComponentScratch) push(index int) {
	if scratch.pending == len(scratch.queue) {
		queue := make([]int, max(64, 2*len(scratch.queue)))
		n := copy(queue, scratch.queue[scratch.head:])
		copy(queue[n:], scratch.queue[:scratch.head])
		scratch.queue = queue
		scratch.head = 0
	}
	tail := scratch.head + scratch.pending
	if tail >= len(scratch.queue) {
		tail -= len(scratch.queue)
	}
	scratch.queue[tail] = index
	scratch.pending++
}

// pop requires a nonempty frontier.
func (scratch *rapidOCRComponentScratch) pop() int {
	index := scratch.queue[scratch.head]
	scratch.head++
	if scratch.head == len(scratch.queue) {
		scratch.head = 0
	}
	scratch.pending--
	return index
}

func rapidOCRTraceComponent(probabilities []float32, width, height, start int, threshold float64, visited []uint64, scratch *rapidOCRComponentScratch) (count int, score float64) {
	scratch.head, scratch.pending = 0, 0
	scratch.boundary = scratch.boundary[:0]
	visited[start>>6] |= uint64(1) << (start & 63)
	scratch.push(start)
	for scratch.pending > 0 {
		index := scratch.pop()
		count++
		// FIFO traversal preserves the original floating-point addition order.
		score += float64(probabilities[index])
		x, y := index%width, index/width
		boundary := x == 0 || x == width-1 || y == 0 || y == height-1
		if !boundary {
			for _, neighbor := range []int{index - 1, index + 1, index - width, index + width} {
				if float64(probabilities[neighbor]) <= threshold {
					boundary = true
					break
				}
			}
		}
		if boundary {
			scratch.boundary = append(scratch.boundary,
				rapidOCRPoint{x: float64(x), y: float64(y)},
				rapidOCRPoint{x: float64(x + 1), y: float64(y)},
				rapidOCRPoint{x: float64(x + 1), y: float64(y + 1)},
				rapidOCRPoint{x: float64(x), y: float64(y + 1)},
			)
		}
		for offsetY := -1; offsetY <= 1; offsetY++ {
			for offsetX := -1; offsetX <= 1; offsetX++ {
				if offsetX == 0 && offsetY == 0 {
					continue
				}
				nextX, nextY := x+offsetX, y+offsetY
				if nextX < 0 || nextX >= width || nextY < 0 || nextY >= height {
					continue
				}
				next := nextY*width + nextX
				mask := uint64(1) << (next & 63)
				if visited[next>>6]&mask != 0 || float64(probabilities[next]) <= threshold {
					continue
				}
				visited[next>>6] |= mask
				scratch.push(next)
			}
		}
	}
	return count, score
}

func rapidOCRBoxesFromProbabilityMap(
	probabilities []float32,
	width, height int,
	scale rapidOCRDetectorScale,
	boxScoreThresh, boxThresh, unclipRatio float64,
) []rapidOCRDetBox {
	if width <= 0 || height <= 0 || len(probabilities) < width*height ||
		scale.sourceWidth <= 0 || scale.sourceHeight <= 0 || scale.ratioWidth <= 0 || scale.ratioHeight <= 0 {
		return nil
	}
	// Allocate one bit per pixel only after finding a foreground component.
	var visited []uint64
	boxes := make([]rapidOCRDetBox, 0)
	// Reuse scratch only within this probability map. Returned boxes own their
	// points, so neither buffer escapes or needs to be retained between images.
	var component rapidOCRComponentScratch
	var geometry rapidOCRGeometryScratch
	componentCount := 0
	for start := 0; start < width*height && componentCount < 1000; start++ {
		if float64(probabilities[start]) <= boxThresh || (visited != nil && visited[start>>6]&(uint64(1)<<(start&63)) != 0) {
			continue
		}
		componentCount++
		if visited == nil {
			visited = make([]uint64, (width*height-1)/64+1)
		}
		count, score := rapidOCRTraceComponent(probabilities, width, height, start, boxThresh, visited, &component)
		if count <= 2 {
			continue
		}
		rect, ok := rapidOCRMinimumAreaRect(component.boundary, &geometry)
		if !ok || max(rect.halfWidth*2, rect.halfHeight*2) < 3 {
			continue
		}
		score /= float64(count)
		if score < boxScoreThresh {
			continue
		}
		rect = rapidOCRUnclipRect(rect, unclipRatio)
		if max(rect.halfWidth*2, rect.halfHeight*2) < 5 {
			continue
		}
		points := rapidOCROrderedRectPoints(rect)
		for index, point := range points {
			points[index] = rapidOCRPoint{
				x: rapidOCRClamp(math.Trunc(point.x/scale.ratioWidth), 0, float64(scale.sourceWidth-1)),
				y: rapidOCRClamp(math.Trunc(point.y/scale.ratioHeight), 0, float64(scale.sourceHeight-1)),
			}
		}
		boxes = append(boxes, rapidOCRDetBox{confidence: score, points: points})
	}
	if len(boxes) > 1 {
		sort.SliceStable(boxes, func(i, j int) bool {
			iy, ix := rapidOCRBoxTopLeft(boxes[i])
			jy, jx := rapidOCRBoxTopLeft(boxes[j])
			if math.Abs(iy-jy) > 1 {
				return iy < jy
			}
			return ix < jx
		})
	}
	return boxes
}

func rapidOCRMinimumAreaRect(points []rapidOCRPoint, scratch *rapidOCRGeometryScratch) (rapidOCRRotatedRect, bool) {
	hull := rapidOCRConvexHull(points, scratch)
	if len(hull) < 3 {
		return rapidOCRRotatedRect{}, false
	}
	bestArea := math.Inf(1)
	var best rapidOCRRotatedRect
	for index, point := range hull {
		next := hull[(index+1)%len(hull)]
		dx, dy := next.x-point.x, next.y-point.y
		length := math.Hypot(dx, dy)
		if length <= 0 {
			continue
		}
		axisWidth := rapidOCRPoint{x: dx / length, y: dy / length}
		axisHeight := rapidOCRPoint{x: -axisWidth.y, y: axisWidth.x}
		minWidth, maxWidth := math.Inf(1), math.Inf(-1)
		minHeight, maxHeight := math.Inf(1), math.Inf(-1)
		for _, candidate := range hull {
			widthProjection := candidate.x*axisWidth.x + candidate.y*axisWidth.y
			heightProjection := candidate.x*axisHeight.x + candidate.y*axisHeight.y
			minWidth = math.Min(minWidth, widthProjection)
			maxWidth = math.Max(maxWidth, widthProjection)
			minHeight = math.Min(minHeight, heightProjection)
			maxHeight = math.Max(maxHeight, heightProjection)
		}
		area := (maxWidth - minWidth) * (maxHeight - minHeight)
		if area >= bestArea {
			continue
		}
		centerWidth := (minWidth + maxWidth) / 2
		centerHeight := (minHeight + maxHeight) / 2
		bestArea = area
		best = rapidOCRRotatedRect{
			center: rapidOCRPoint{
				x: axisWidth.x*centerWidth + axisHeight.x*centerHeight,
				y: axisWidth.y*centerWidth + axisHeight.y*centerHeight,
			},
			axisWidth:  axisWidth,
			axisHeight: axisHeight,
			halfWidth:  (maxWidth - minWidth) / 2,
			halfHeight: (maxHeight - minHeight) / 2,
		}
	}
	return best, !math.IsInf(bestArea, 1)
}

// rapidOCRConvexHull consumes points and returns a hull valid until scratch is
// reused. Neither slice may refer to native output or returned box storage.
func rapidOCRConvexHull(points []rapidOCRPoint, scratch *rapidOCRGeometryScratch) []rapidOCRPoint {
	hull := scratch.hull[:0]
	if len(points) < 2 {
		scratch.hull = append(hull, points...)
		return scratch.hull
	}
	slices.SortFunc(points, func(first, second rapidOCRPoint) int {
		if first.x == second.x {
			if first.y < second.y {
				return -1
			}
			if first.y > second.y {
				return 1
			}
			return 0
		}
		if first.x < second.x {
			return -1
		}
		if first.x > second.x {
			return 1
		}
		return 0
	})
	unique := points[:0]
	for _, point := range points {
		if len(unique) == 0 || point != unique[len(unique)-1] {
			unique = append(unique, point)
		}
	}
	if len(unique) < 3 {
		scratch.hull = append(hull, unique...)
		return scratch.hull
	}
	for _, point := range unique {
		for len(hull) >= 2 && rapidOCRCross(hull[len(hull)-2], hull[len(hull)-1], point) <= 0 {
			hull = hull[:len(hull)-1]
		}
		hull = append(hull, point)
	}
	// The rightmost point already ends the lower chain. Append the upper
	// chain in the same order, keeping that endpoint while popping its turns.
	lowerLength := len(hull)
	for index := len(unique) - 2; index >= 0; index-- {
		point := unique[index]
		for len(hull) > lowerLength && rapidOCRCross(hull[len(hull)-2], hull[len(hull)-1], point) <= 0 {
			hull = hull[:len(hull)-1]
		}
		hull = append(hull, point)
	}
	scratch.hull = hull[:len(hull)-1] // Drop the repeated leftmost point.
	return scratch.hull
}

func rapidOCRCross(origin, first, second rapidOCRPoint) float64 {
	return (first.x-origin.x)*(second.y-origin.y) - (first.y-origin.y)*(second.x-origin.x)
}

func rapidOCRUnclipRect(rect rapidOCRRotatedRect, ratio float64) rapidOCRRotatedRect {
	if ratio <= 0 {
		return rect
	}
	width, height := rect.halfWidth*2, rect.halfHeight*2
	perimeter := 2 * (width + height)
	if perimeter <= 0 {
		return rect
	}
	distance := width * height * ratio / perimeter
	rect.halfWidth += distance
	rect.halfHeight += distance
	return rect
}

func rapidOCROrderedRectPoints(rect rapidOCRRotatedRect) [4]rapidOCRPoint {
	width := rapidOCRPoint{x: rect.axisWidth.x * rect.halfWidth, y: rect.axisWidth.y * rect.halfWidth}
	height := rapidOCRPoint{x: rect.axisHeight.x * rect.halfHeight, y: rect.axisHeight.y * rect.halfHeight}
	points := [4]rapidOCRPoint{
		{x: rect.center.x - width.x - height.x, y: rect.center.y - width.y - height.y},
		{x: rect.center.x + width.x - height.x, y: rect.center.y + width.y - height.y},
		{x: rect.center.x + width.x + height.x, y: rect.center.y + width.y + height.y},
		{x: rect.center.x - width.x + height.x, y: rect.center.y - width.y + height.y},
	}
	// Four points use the same insertion order as sort.Slice's small-slice
	// path, without reflection or moving this fixed array onto the heap.
	for i := 1; i < len(points); i++ {
		for j := i; j > 0; j-- {
			previous, current := points[j-1], points[j]
			if !(current.x < previous.x || (current.x == previous.x && current.y < previous.y)) {
				break
			}
			points[j-1], points[j] = current, previous
		}
	}
	var ordered [4]rapidOCRPoint
	if points[0].y <= points[1].y {
		ordered[0], ordered[3] = points[0], points[1]
	} else {
		ordered[0], ordered[3] = points[1], points[0]
	}
	if points[2].y <= points[3].y {
		ordered[1], ordered[2] = points[2], points[3]
	} else {
		ordered[1], ordered[2] = points[3], points[2]
	}
	return ordered
}

func rapidOCRBoxTopLeft(box rapidOCRDetBox) (float64, float64) {
	minX, minY := box.points[0].x, box.points[0].y
	for _, point := range box.points[1:] {
		minX = math.Min(minX, point.x)
		minY = math.Min(minY, point.y)
	}
	return minY, minX
}

func rapidOCRClamp(value, minimum, maximum float64) float64 {
	return math.Min(math.Max(value, minimum), maximum)
}

func rapidOCRCropImage(source image.Image, box rapidOCRDetBox) (*image.NRGBA, error) {
	if source == nil || source.Bounds().Dx() <= 0 || source.Bounds().Dy() <= 0 {
		return nil, fmt.Errorf("rapidocr crop source image is empty")
	}
	points := box.points
	width := int(math.Round(math.Max(
		math.Hypot(points[1].x-points[0].x, points[1].y-points[0].y),
		math.Hypot(points[2].x-points[3].x, points[2].y-points[3].y),
	)))
	height := int(math.Round(math.Max(
		math.Hypot(points[3].x-points[0].x, points[3].y-points[0].y),
		math.Hypot(points[2].x-points[1].x, points[2].y-points[1].y),
	)))
	if width <= 0 || height <= 0 {
		return nil, fmt.Errorf("rapidocr crop box has zero area")
	}
	rotate := float64(height) >= float64(width)*1.5
	cropWidth, cropHeight := width, height
	if rotate {
		cropWidth, cropHeight = height, width
	}
	crop := image.NewNRGBA(image.Rect(0, 0, cropWidth, cropHeight))
	for y := 0; y < height; y++ {
		v := 0.0
		if height > 1 {
			v = float64(y) / float64(height-1)
		}
		for x := 0; x < width; x++ {
			u := 0.0
			if width > 1 {
				u = float64(x) / float64(width-1)
			}
			top := rapidOCRLerpPoint(points[0], points[1], u)
			bottom := rapidOCRLerpPoint(points[3], points[2], u)
			sourcePoint := rapidOCRLerpPoint(top, bottom, v)
			pixel := rapidOCRBilinearSample(source, sourcePoint.x, sourcePoint.y)
			offset := y*crop.Stride + x*4
			if rotate {
				// Write clockwise into the final canvas instead of allocating
				// an unrotated crop and copying every pixel a second time.
				offset = x*crop.Stride + (height-1-y)*4
			}
			dst := crop.Pix[offset : offset+4]
			dst[0], dst[1], dst[2], dst[3] = pixel.R, pixel.G, pixel.B, pixel.A
		}
	}
	return crop, nil
}

func rapidOCRLerpPoint(first, second rapidOCRPoint, amount float64) rapidOCRPoint {
	return rapidOCRPoint{
		x: first.x + (second.x-first.x)*amount,
		y: first.y + (second.y-first.y)*amount,
	}
}

func rapidOCRBilinearSample(source image.Image, x, y float64) color.NRGBA {
	bounds := source.Bounds()
	x = rapidOCRClamp(x, float64(bounds.Min.X), float64(bounds.Max.X-1))
	y = rapidOCRClamp(y, float64(bounds.Min.Y), float64(bounds.Max.Y-1))
	x0, y0 := int(math.Floor(x)), int(math.Floor(y))
	x1, y1 := min(x0+1, bounds.Max.X-1), min(y0+1, bounds.Max.Y-1)
	xWeight, yWeight := x-float64(x0), y-float64(y0)
	if src, ok := source.(*image.NRGBA); ok && image.Pt(x0, y0).In(bounds) {
		// OCR's padded source is NRGBA. Coordinates have already been
		// clamped, so read four visible pixels without interface dispatch
		// or repeating NRGBAAt's bounds check for each neighbor.
		topLeft := src.PixOffset(x0, y0)
		topRight := src.PixOffset(x1, y0)
		bottomLeft := src.PixOffset(x0, y1)
		bottomRight := src.PixOffset(x1, y1)
		a, b := src.Pix[topLeft:topLeft+4], src.Pix[topRight:topRight+4]
		c, d := src.Pix[bottomLeft:bottomLeft+4], src.Pix[bottomRight:bottomRight+4]
		return color.NRGBA{
			R: rapidOCRInterpolateByte(a[0], b[0], c[0], d[0], xWeight, yWeight),
			G: rapidOCRInterpolateByte(a[1], b[1], c[1], d[1], xWeight, yWeight),
			B: rapidOCRInterpolateByte(a[2], b[2], c[2], d[2], xWeight, yWeight),
			A: rapidOCRInterpolateByte(a[3], b[3], c[3], d[3], xWeight, yWeight),
		}
	}
	values := [4]color.NRGBA{
		nativeImageNRGBAAt(source, x0, y0),
		nativeImageNRGBAAt(source, x1, y0),
		nativeImageNRGBAAt(source, x0, y1),
		nativeImageNRGBAAt(source, x1, y1),
	}
	return color.NRGBA{
		R: rapidOCRInterpolateByte(values[0].R, values[1].R, values[2].R, values[3].R, xWeight, yWeight),
		G: rapidOCRInterpolateByte(values[0].G, values[1].G, values[2].G, values[3].G, xWeight, yWeight),
		B: rapidOCRInterpolateByte(values[0].B, values[1].B, values[2].B, values[3].B, xWeight, yWeight),
		A: rapidOCRInterpolateByte(values[0].A, values[1].A, values[2].A, values[3].A, xWeight, yWeight),
	}
}

func rapidOCRInterpolateByte(a, b, c, d uint8, xWeight, yWeight float64) uint8 {
	top := float64(a) + (float64(b)-float64(a))*xWeight
	bottom := float64(c) + (float64(d)-float64(c))*xWeight
	return uint8(math.Round(top + (bottom-top)*yWeight))
}

func rapidOCRRotateClockwise(source *image.NRGBA) *image.NRGBA {
	bounds := source.Bounds()
	rotated := image.NewNRGBA(image.Rect(0, 0, bounds.Dy(), bounds.Dx()))
	for y := 0; y < bounds.Dy(); y++ {
		for x := 0; x < bounds.Dx(); x++ {
			rotated.SetNRGBA(bounds.Dy()-1-y, x, source.NRGBAAt(bounds.Min.X+x, bounds.Min.Y+y))
		}
	}
	return rotated
}

func rapidOCRDecodeCTC(values []float32, rows, columns int, keys []string, modern bool) string {
	text, _ := rapidOCRDecodeCTCWithScores(values, rows, columns, keys, modern)
	return text
}

func rapidOCRDecodeCTCWithScores(values []float32, rows, columns int, keys []string, modern bool) (string, []float32) {
	if rows <= 0 || columns <= 0 || len(values) < rows*columns || len(keys) == 0 {
		return "", nil
	}
	var builder strings.Builder
	scores := make([]float32, 0, rows)
	lastIndex := 0
	for row := 0; row < rows; row++ {
		rowValues := values[row*columns : (row+1)*columns]
		maxIndex := 0
		maxValue := rowValues[0]
		for column := 1; column < len(rowValues); column++ {
			if rowValues[column] > maxValue {
				maxIndex = column
				maxValue = rowValues[column]
			}
		}
		keyIndex := maxIndex
		if modern {
			keyIndex--
		}
		if maxIndex > 0 && keyIndex >= 0 && keyIndex < len(keys) && !(row > 0 && maxIndex == lastIndex) {
			builder.WriteString(keys[keyIndex])
			scores = append(scores, maxValue)
		}
		lastIndex = maxIndex
	}
	return builder.String(), scores
}

func parseRapidOCRDetBoxes(raw interface{}) []rapidOCRDetBox {
	items := rapidOCRInterfaceSlice(raw)
	boxes := make([]rapidOCRDetBox, 0, len(items))
	for _, item := range items {
		itemMap := rapidOCRMapValue(item)
		pointItems := rapidOCRInterfaceSlice(itemMap["points"])
		if len(pointItems) != 4 {
			continue
		}
		box := rapidOCRDetBox{}
		if rawConfidence, exists := itemMap["confidence"]; exists {
			value, ok := rapidOCRFloat64Value(rawConfidence)
			if !ok {
				continue
			}
			box.confidence = value
		}
		valid := true
		for index, pointItem := range pointItems {
			pointMap := rapidOCRMapValue(pointItem)
			x, xOK := rapidOCRFloat64Value(pointMap["x"])
			y, yOK := rapidOCRFloat64Value(pointMap["y"])
			if !xOK || !yOK {
				valid = false
				break
			}
			box.points[index] = rapidOCRPoint{x: x, y: y}
		}
		if valid {
			boxes = append(boxes, box)
		}
	}
	return boxes
}

func rapidOCRInterfaceSlice(raw interface{}) []interface{} {
	switch typed := raw.(type) {
	case []interface{}:
		return typed
	case []map[string]interface{}:
		items := make([]interface{}, 0, len(typed))
		for _, item := range typed {
			items = append(items, item)
		}
		return items
	case []map[string]float64:
		items := make([]interface{}, 0, len(typed))
		for _, item := range typed {
			items = append(items, item)
		}
		return items
	default:
		return nil
	}
}

func rapidOCRMapValue(raw interface{}) map[string]interface{} {
	switch typed := raw.(type) {
	case map[string]interface{}:
		return typed
	case map[string]float64:
		value := make(map[string]interface{}, len(typed))
		for key, item := range typed {
			value[key] = item
		}
		return value
	default:
		return nil
	}
}

func rapidOCRBoolParam(values map[string]interface{}, key string, fallback bool) bool {
	if value, ok := rapidOCRBoolValue(values[key]); ok {
		return value
	}
	return fallback
}

func parseRapidOCRTextLines(raw string) []string {
	if strings.TrimSpace(raw) == "" {
		return nil
	}
	seen := make(map[string]struct{}, 8)
	var lines []string
	scanner := bufio.NewScanner(strings.NewReader(strings.ReplaceAll(raw, "\r\n", "\n")))
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" {
			continue
		}
		matches := rapidOCRTextLinePatternForWrapper.FindStringSubmatch(line)
		if len(matches) != 3 {
			continue
		}
		text := strings.TrimSpace(matches[2])
		if text == "" {
			continue
		}
		if _, ok := seen[text]; ok {
			continue
		}
		seen[text] = struct{}{}
		lines = append(lines, text)
	}
	return lines
}

func rapidOCRBoolValue(value interface{}) (bool, bool) {
	switch typed := value.(type) {
	case bool:
		return typed, true
	case string:
		parsed, err := strconv.ParseBool(strings.TrimSpace(typed))
		return parsed, err == nil
	case float64:
		return typed != 0, true
	case int:
		return typed != 0, true
	default:
		return false, false
	}
}

func rapidOCRFloat64Value(value interface{}) (float64, bool) {
	switch typed := value.(type) {
	case float64:
		return rapidOCRFiniteFloat64(typed, true)
	case float32:
		return rapidOCRFiniteFloat64(float64(typed), true)
	case int:
		return float64(typed), true
	case int64:
		return float64(typed), true
	case jsonNumber:
		parsed, err := strconv.ParseFloat(string(typed), 64)
		return rapidOCRFiniteFloat64(parsed, err == nil)
	case string:
		parsed, err := strconv.ParseFloat(strings.TrimSpace(typed), 64)
		return rapidOCRFiniteFloat64(parsed, err == nil)
	default:
		return 0, false
	}
}

func rapidOCRFiniteFloat64(value float64, ok bool) (float64, bool) {
	if !ok || math.IsNaN(value) || math.IsInf(value, 0) {
		return 0, false
	}
	return value, true
}

type jsonNumber string
