package main

import (
	"encoding/json"
	"math"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestResolveRapidOCRBundleLayoutRecognizesPipelineMetadata(t *testing.T) {
	bundleDir := writeRapidOCRBundleForTest(t)

	layout, err := resolveRapidOCRBundleLayout(bundleDir)
	if err != nil {
		t.Fatalf("resolveRapidOCRBundleLayout() error = %v", err)
	}
	if layout.runtimeBinaryName != "" {
		t.Fatalf("runtimeBinaryName = %q, want no executable for v7", layout.runtimeBinaryName)
	}
	if layout.detModel != "det/ch_PP-OCRv3_det_infer" {
		t.Fatalf("detModel = %q, want det/ch_PP-OCRv3_det_infer", layout.detModel)
	}
	if layout.clsModel != "cls/ch_ppocr_mobile_v2.0_cls_infer" {
		t.Fatalf("clsModel = %q, want cls/ch_ppocr_mobile_v2.0_cls_infer", layout.clsModel)
	}
	if layout.recModel != "rec/ch_PP-OCRv3_rec_infer" {
		t.Fatalf("recModel = %q, want rec/ch_PP-OCRv3_rec_infer", layout.recModel)
	}
	if layout.keysPath != "keys/ppocr_keys_v1.txt" {
		t.Fatalf("keysPath = %q, want keys/ppocr_keys_v1.txt", layout.keysPath)
	}
	if layout.defaultPadding != 50 || layout.defaultMaxSideLen != 1024 {
		t.Fatalf("defaults = padding:%d max-side:%d", layout.defaultPadding, layout.defaultMaxSideLen)
	}
}

func TestResolveRapidOCRBundleLayoutRecognizesPPOCRv6StyleOrientationMetadata(t *testing.T) {
	bundleDir := writeRapidOCRBundleForTestWithMetadata(t, map[string]interface{}{
		"bundle_id":   "rapidocr-ncnn",
		"model_class": modelClassOCR,
		"pipeline": map[string]interface{}{
			"det": map[string]interface{}{"param": "det/PP-OCRv6_server_det.param", "bin": "det/PP-OCRv6_server_det.bin"},
			"ori": map[string]interface{}{"param": "ori/PP-LCNet_x1_0_textline_ori.param", "bin": "ori/PP-LCNet_x1_0_textline_ori.bin"},
			"rec": map[string]interface{}{"param": "rec/PP-OCRv6_server_rec.param", "bin": "rec/PP-OCRv6_server_rec.bin", "keys": "keys/ppocrv6_keys_v1.txt"},
		},
		"default_params": map[string]interface{}{
			"padding": 50, "max_side_len": 1600, "box_score_thresh": 0.3,
			"box_thresh": 0.3, "unclip_ratio": 2.0,
		},
	}, []string{
		"det/PP-OCRv6_server_det.param", "det/PP-OCRv6_server_det.bin",
		"ori/PP-LCNet_x1_0_textline_ori.param", "ori/PP-LCNet_x1_0_textline_ori.bin",
		"rec/PP-OCRv6_server_rec.param", "rec/PP-OCRv6_server_rec.bin",
		"keys/ppocrv6_keys_v1.txt",
	})

	layout, err := resolveRapidOCRBundleLayout(bundleDir)
	if err != nil {
		t.Fatal(err)
	}
	if layout.detModel != "det/PP-OCRv6_server_det" ||
		layout.clsModel != "ori/PP-LCNet_x1_0_textline_ori" ||
		layout.recModel != "rec/PP-OCRv6_server_rec" {
		t.Fatalf("unexpected v6 layout: %#v", layout)
	}
}

func TestResolveRapidOCRBundleLayoutRecognizesMixedPPOCRv6DetAndPPOCRv3RecMetadata(t *testing.T) {
	bundleDir := writeRapidOCRBundleForTestWithMetadata(t, map[string]interface{}{
		"bundle_id":   "rapidocr-ncnn",
		"model_class": modelClassOCR,
		"pipeline": map[string]interface{}{
			"det": map[string]interface{}{"param": "det/PP-OCRv6_small_det.param", "bin": "det/PP-OCRv6_small_det.bin"},
			"cls": map[string]interface{}{"param": "cls/ch_ppocr_mobile_v2.0_cls_infer.param", "bin": "cls/ch_ppocr_mobile_v2.0_cls_infer.bin"},
			"rec": map[string]interface{}{"param": "rec/ch_PP-OCRv3_rec_infer.param", "bin": "rec/ch_PP-OCRv3_rec_infer.bin", "keys": "keys/ppocr_keys_v1.txt"},
		},
		"default_params": map[string]interface{}{"max_side_len": 1280},
	}, []string{
		"det/PP-OCRv6_small_det.param", "det/PP-OCRv6_small_det.bin",
		"cls/ch_ppocr_mobile_v2.0_cls_infer.param", "cls/ch_ppocr_mobile_v2.0_cls_infer.bin",
		"rec/ch_PP-OCRv3_rec_infer.param", "rec/ch_PP-OCRv3_rec_infer.bin",
		"keys/ppocr_keys_v1.txt",
	})

	layout, err := resolveRapidOCRBundleLayout(bundleDir)
	if err != nil {
		t.Fatal(err)
	}
	if layout.detModel != "det/PP-OCRv6_small_det" || layout.recModel != "rec/ch_PP-OCRv3_rec_infer" {
		t.Fatalf("unexpected mixed layout: %#v", layout)
	}
	if layout.defaultMaxSideLen != 1280 {
		t.Fatalf("defaultMaxSideLen = %d, want 1280", layout.defaultMaxSideLen)
	}
}

func TestResolveRapidOCRBundleLayoutRejectsArtifactPathOutsideBundle(t *testing.T) {
	bundleDir := writeRapidOCRBundleForTestWithMetadata(t, map[string]interface{}{
		"bundle_id":   "rapidocr-ncnn",
		"model_class": modelClassOCR,
		"pipeline": map[string]interface{}{
			"det": map[string]interface{}{"param": "../outside-det.param", "bin": "det/model.bin"},
			"cls": map[string]interface{}{"param": "cls/model.param", "bin": "cls/model.bin"},
			"rec": map[string]interface{}{"param": "rec/model.param", "bin": "rec/model.bin", "keys": "keys/keys.txt"},
		},
	}, []string{
		"../outside-det.param", "det/model.bin", "cls/model.param", "cls/model.bin",
		"rec/model.param", "rec/model.bin", "keys/keys.txt",
	})

	_, err := resolveRapidOCRBundleLayout(bundleDir)
	if err == nil || !strings.Contains(err.Error(), "bundle") {
		t.Fatalf("resolveRapidOCRBundleLayout() error = %v, want outside-bundle rejection", err)
	}
}

func TestResolveRapidOCRBundleLayoutIgnoresLegacyRuntimeExecutableMetadata(t *testing.T) {
	bundleDir := writeRapidOCRBundleForTest(t)
	metadataPath := filepath.Join(bundleDir, "metadata.json")
	metadata := readBundleMetadataForNativeRuntime(bundleDir)
	metadata["runtime"] = "../RapidOcrNcnn"
	writeRapidOCRJSONFileForTest(t, metadataPath, metadata)

	layout, err := resolveRapidOCRBundleLayout(bundleDir)
	if err != nil {
		t.Fatalf("legacy runtime metadata must not affect v7: %v", err)
	}
	if layout.runtimeBinaryName != "" {
		t.Fatalf("runtimeBinaryName = %q, want none", layout.runtimeBinaryName)
	}
}

func TestPrepareRapidOCRInferConfigRejectsInvalidDetBoxesForReuse(t *testing.T) {
	_, err := prepareRapidOCRInferConfig(rapidOCRBundleLayout{}, inferRequest{
		Input: map[string]interface{}{
			"image": "docs.png",
			"params": map[string]interface{}{
				"reuse_det_boxes": true,
				"det_boxes": []interface{}{map[string]interface{}{
					"confidence": 0.9,
					"points":     []interface{}{map[string]interface{}{"x": 1.0, "y": 1.0}},
				}},
			},
		},
	})
	if err == nil || !strings.Contains(err.Error(), "det_boxes") {
		t.Fatalf("prepareRapidOCRInferConfig() error = %v, want det_boxes validation error", err)
	}
}

func TestPrepareRapidOCRInferConfigRejectsNonFiniteDetBoxesForReuse(t *testing.T) {
	for _, testCase := range []struct {
		name       string
		confidence interface{}
		x          interface{}
	}{
		{name: "nan confidence", confidence: math.NaN(), x: 1.0},
		{name: "infinite confidence string", confidence: "Inf", x: 1.0},
		{name: "nan coordinate string", confidence: 0.9, x: "NaN"},
		{name: "infinite coordinate", confidence: 0.9, x: math.Inf(-1)},
	} {
		t.Run(testCase.name, func(t *testing.T) {
			_, err := prepareRapidOCRInferConfig(rapidOCRBundleLayout{}, inferRequest{
				Input: map[string]interface{}{
					"image": "docs.png",
					"params": map[string]interface{}{
						"reuse_det_boxes": true,
						"det_boxes": []interface{}{map[string]interface{}{
							"confidence": testCase.confidence,
							"points": []interface{}{
								map[string]interface{}{"x": testCase.x, "y": 1.0},
								map[string]interface{}{"x": 2.0, "y": 1.0},
								map[string]interface{}{"x": 2.0, "y": 2.0},
								map[string]interface{}{"x": 1.0, "y": 2.0},
							},
						}},
					},
				},
			})
			if err == nil || !strings.Contains(err.Error(), "det_boxes") {
				t.Fatalf("prepareRapidOCRInferConfig() error = %v, want non-finite det_boxes rejection", err)
			}
		})
	}
}

func writeRapidOCRBundleForTest(t *testing.T) string {
	t.Helper()
	return writeRapidOCRBundleForTestWithMetadata(t, map[string]interface{}{
		"bundle_id":   "rapidocr-ncnn",
		"model_class": modelClassOCR,
		"runtime":     "RapidOcrNcnn",
		"pipeline": map[string]interface{}{
			"det": map[string]interface{}{"param": "det/ch_PP-OCRv3_det_infer.param", "bin": "det/ch_PP-OCRv3_det_infer.bin"},
			"cls": map[string]interface{}{"param": "cls/ch_ppocr_mobile_v2.0_cls_infer.param", "bin": "cls/ch_ppocr_mobile_v2.0_cls_infer.bin"},
			"rec": map[string]interface{}{"param": "rec/ch_PP-OCRv3_rec_infer.param", "bin": "rec/ch_PP-OCRv3_rec_infer.bin", "keys": "keys/ppocr_keys_v1.txt"},
		},
		"default_params": map[string]interface{}{
			"padding": 50, "max_side_len": 1024, "box_score_thresh": 0.6,
			"box_thresh": 0.3, "unclip_ratio": 2.0,
		},
	}, []string{
		"det/ch_PP-OCRv3_det_infer.param", "det/ch_PP-OCRv3_det_infer.bin",
		"cls/ch_ppocr_mobile_v2.0_cls_infer.param", "cls/ch_ppocr_mobile_v2.0_cls_infer.bin",
		"rec/ch_PP-OCRv3_rec_infer.param", "rec/ch_PP-OCRv3_rec_infer.bin",
		"keys/ppocr_keys_v1.txt",
	})
}

func writeRapidOCRBundleForTestWithMetadata(t *testing.T, metadata map[string]interface{}, artifacts []string) string {
	t.Helper()
	bundleDir := t.TempDir()
	ready := bundleReadyManifest{
		BundleID:   "rapidocr-ncnn",
		ModelClass: modelClassOCR,
		Artifacts:  append([]string{"metadata.json"}, artifacts...),
	}
	writeRapidOCRJSONFileForTest(t, filepath.Join(bundleDir, ".ready.json"), ready)
	writeRapidOCRJSONFileForTest(t, filepath.Join(bundleDir, "metadata.json"), metadata)
	for _, name := range ready.Artifacts[1:] {
		artifactPath := filepath.Join(bundleDir, filepath.FromSlash(name))
		if err := os.MkdirAll(filepath.Dir(artifactPath), 0o755); err != nil {
			t.Fatalf("MkdirAll(%s) error = %v", artifactPath, err)
		}
		if err := os.WriteFile(artifactPath, []byte(name), 0o644); err != nil {
			t.Fatalf("WriteFile(%s) error = %v", artifactPath, err)
		}
	}
	return bundleDir
}

func writeRapidOCRJSONFileForTest(t *testing.T, path string, value interface{}) {
	t.Helper()
	data, err := json.Marshal(value)
	if err != nil {
		t.Fatalf("json.Marshal(%s) error = %v", path, err)
	}
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		t.Fatalf("MkdirAll(%s) error = %v", path, err)
	}
	if err := os.WriteFile(path, data, 0o644); err != nil {
		t.Fatalf("WriteFile(%s) error = %v", path, err)
	}
}
