package main

import (
	"image"
	"image/color"
	"os"
	"path/filepath"
	"reflect"
	"sort"
	"strings"
	"testing"
	"unsafe"
)

func TestRapidOCRV7BundleDoesNotResolveExecutableRuntime(t *testing.T) {
	bundleDir := writeRapidOCRBundleForTest(t)
	layout, err := resolveRapidOCRBundleLayout(bundleDir)
	if err != nil {
		t.Fatal(err)
	}
	if layout.runtimeBinaryName != "" {
		t.Fatalf("runtime binary = %q, want none for embedded v7 OCR", layout.runtimeBinaryName)
	}
}

func TestRapidOCRV7ExtractsAndUnclipsDetectorComponent(t *testing.T) {
	probabilities := []float32{
		0, 0, 0, 0, 0, 0,
		0, .9, .9, .9, 0, 0,
		0, .9, .9, .9, 0, 0,
		0, 0, 0, 0, 0, 0,
	}
	boxes := rapidOCRBoxesFromProbabilityMap(probabilities, 6, 4, rapidOCRDetectorScale{
		sourceWidth:  120,
		sourceHeight: 80,
		ratioWidth:   .05,
		ratioHeight:  .05,
	}, .6, .3, 2)
	if len(boxes) != 1 {
		t.Fatalf("boxes = %#v, want one component", boxes)
	}
	if boxes[0].confidence < .89 {
		t.Fatalf("confidence = %f, want detector score", boxes[0].confidence)
	}
	if boxes[0].points[0].x >= boxes[0].points[1].x || boxes[0].points[0].y > boxes[0].points[3].y {
		t.Fatalf("box points are not ordered clockwise from top-left: %#v", boxes[0].points)
	}
}

func TestRapidOCRV7DecodesLegacyCTCOutput(t *testing.T) {
	keys := []string{"#", "A", "B", " "}
	values := []float32{
		.9, .1, 0, 0,
		.1, .8, .1, 0,
		.1, .9, 0, 0,
		.8, .1, .1, 0,
		.1, .1, .8, 0,
	}
	if got := rapidOCRDecodeCTC(values, 5, 4, keys, false); got != "AB" {
		t.Fatalf("decoded text = %q, want AB", got)
	}
}

func TestRapidOCRV7ReadsLegacyKeys(t *testing.T) {
	bundleDir := t.TempDir()
	keysPath := filepath.Join(bundleDir, "keys", "ppocr_keys_v1.txt")
	if err := os.MkdirAll(filepath.Dir(keysPath), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(keysPath, []byte("A\nB\n"), 0o644); err != nil {
		t.Fatal(err)
	}

	keys, err := rapidOCRReadKeys(bundleDir, rapidOCRBundleLayout{keysPath: "keys/ppocr_keys_v1.txt"})
	if err != nil {
		t.Fatal(err)
	}
	if want := []string{"#", "A", "B", " "}; !reflect.DeepEqual(keys, want) {
		t.Fatalf("keys = %#v, want %#v", keys, want)
	}
}

func TestRapidOCRV7CropsOrderedRectangle(t *testing.T) {
	source := image.NewNRGBA(image.Rect(0, 0, 6, 4))
	for y := 0; y < 4; y++ {
		for x := 0; x < 6; x++ {
			source.SetNRGBA(x, y, color.NRGBA{R: uint8(20*x + y), A: 255})
		}
	}
	box := rapidOCRDetBox{points: [4]rapidOCRPoint{
		{x: 1, y: 1}, {x: 5, y: 1}, {x: 5, y: 3}, {x: 1, y: 3},
	}}

	crop, err := rapidOCRCropImage(source, box)
	if err != nil {
		t.Fatal(err)
	}
	if crop.Bounds().Dx() != 4 || crop.Bounds().Dy() != 2 {
		t.Fatalf("crop size = %dx%d, want 4x2", crop.Bounds().Dx(), crop.Bounds().Dy())
	}
}

func TestRapidOCRV7DetectorTargetDoesNotUpscaleSmallSource(t *testing.T) {
	if got := rapidOCRDetectorTargetMaxSide(200, 160, 50, 960); got != 200 {
		t.Fatalf("detector target max side = %d, want padded source max side 200", got)
	}
	if got := rapidOCRDetectorTargetMaxSide(1400, 1000, 50, 960); got != 1060 {
		t.Fatalf("detector target max side = %d, want requested source cap plus padding 1060", got)
	}
}

func TestRapidOCRV7ReusesDetectionBoxesWithoutRunningDetector(t *testing.T) {
	output := []float32{
		.9, .1,
		.1, .9,
		.9, .1,
	}
	detectorExtracts := 0
	recognizerExtracts := 0
	bindings := nativeNCNNBindings{
		matFromPixels:             func(*byte, int32, int32, int32, int32, uintptr) uintptr { return 20 },
		matDestroy:                func(uintptr) {},
		matSubstractMeanNormalize: func(uintptr, *float32, *float32) {},
		extractorCreate:           func(net uintptr) uintptr { return net },
		extractorDestroy:          func(uintptr) {},
		extractorInput:            func(uintptr, *byte, uintptr) int32 { return 0 },
		extractorExtract: func(extractor uintptr, _ *byte, outputMat *uintptr) int32 {
			if extractor == 11 {
				detectorExtracts++
				return -1
			}
			recognizerExtracts++
			*outputMat = 21
			return 0
		},
		optionCreate: func() uintptr { return 0 },
		matGetDims:   func(uintptr) int32 { return 2 },
		matGetW:      func(uintptr) int32 { return 2 },
		matGetH:      func(uintptr) int32 { return 3 },
		matGetD:      func(uintptr) int32 { return 1 },
		matGetC:      func(uintptr) int32 { return 1 },
		matGetData:   func(uintptr) unsafe.Pointer { return unsafe.Pointer(&output[0]) },
	}
	runtimeValue := &nativeEmbeddingRuntime{
		base: &nativeEmbeddingBackend{bindings: bindings},
		loaded: map[string]*nativeEmbeddingModel{
			modelClassOCR: {
				net:          11,
				splitHeadNet: 12,
				ocrKeys:      []string{"#", "A", " "},
			},
		},
	}
	source := image.NewNRGBA(image.Rect(0, 0, 6, 4))
	boxes := []rapidOCRDetBox{{points: [4]rapidOCRPoint{
		{x: 1, y: 1}, {x: 5, y: 1}, {x: 5, y: 3}, {x: 1, y: 3},
	}}}

	gotBoxes, lines, err := runtimeValue.inferRapidOCR(modelClassOCR, source, rapidOCRInferConfig{skipDet: true, detBoxes: boxes})
	if err != nil {
		t.Fatal(err)
	}
	if detectorExtracts != 0 || recognizerExtracts != 1 {
		t.Fatalf("extract calls = detector:%d recognizer:%d, want 0/1", detectorExtracts, recognizerExtracts)
	}
	if len(gotBoxes) != 1 || len(lines) != 1 || lines[0].text != "A" {
		t.Fatalf("OCR result = boxes:%#v lines:%#v, want reused box and A", gotBoxes, lines)
	}
}

func TestRapidOCRV7LoadsAndUnloadsDetectorAndRecognizer(t *testing.T) {
	bundleDir := writeRapidOCRBundleForTest(t)
	nextNet := uintptr(10)
	var destroyed []uintptr
	bindings := nativeNCNNBindings{
		netCreate: func() uintptr {
			nextNet++
			return nextNet
		},
		netDestroy:                 func(net uintptr) { destroyed = append(destroyed, net) },
		netSetOption:               func(uintptr, uintptr) {},
		netLoadParam:               func(uintptr, *byte) int32 { return 0 },
		netLoadModel:               func(uintptr, *byte) int32 { return 0 },
		optionCreate:               func() uintptr { return 1 },
		optionDestroy:              func(uintptr) {},
		optionSetNumThreads:        func(uintptr, int32) {},
		optionSetUseFP16Packed:     func(uintptr, int32) {},
		optionSetUseFP16Storage:    func(uintptr, int32) {},
		optionSetUseFP16Arithmetic: func(uintptr, int32) {},
		optionSetUseINT8Packed:     func(uintptr, int32) {},
		optionSetUseINT8Storage:    func(uintptr, int32) {},
		optionSetUseINT8Arithmetic: func(uintptr, int32) {},
		optionSetUsePackingLayout:  func(uintptr, int32) {},
	}
	runtimeValue := &nativeEmbeddingRuntime{
		base:   &nativeEmbeddingBackend{bindings: bindings},
		loaded: make(map[string]*nativeEmbeddingModel),
	}

	if err := runtimeValue.load(modelClassOCR, bundleDir, nativeEmbeddingLoadOptions{}); err != nil {
		t.Fatal(err)
	}
	model := runtimeValue.loaded[modelClassOCR]
	if model == nil || model.net == 0 || model.splitHeadNet == 0 || model.net == model.splitHeadNet {
		t.Fatalf("loaded OCR model = %#v, want distinct detector and recognizer nets", model)
	}
	runtimeValue.unload(modelClassOCR)
	sort.Slice(destroyed, func(i, j int) bool { return destroyed[i] < destroyed[j] })
	if want := []uintptr{11, 12}; !reflect.DeepEqual(destroyed, want) {
		t.Fatalf("destroyed nets = %#v, want %#v", destroyed, want)
	}
}

func TestRapidOCRV7SourceDoesNotExecuteSidecar(t *testing.T) {
	raw, err := os.ReadFile("native_ocr_runtime.go")
	if err != nil {
		t.Fatal(err)
	}
	source := string(raw)
	for _, forbidden := range []string{"os/exec", "exec.Command", "RapidOcrNcnnStaged", "RAPIDOCR_SIDECAR"} {
		if strings.Contains(source, forbidden) {
			t.Fatalf("native OCR runtime still contains sidecar dependency %q", forbidden)
		}
	}
}
