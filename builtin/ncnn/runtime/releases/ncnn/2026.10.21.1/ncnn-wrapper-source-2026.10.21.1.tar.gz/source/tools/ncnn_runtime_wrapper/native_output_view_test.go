package main

import (
	"math"
	"reflect"
	"strings"
	"testing"
	"unsafe"
)

func BenchmarkNativeOutputExtraction(b *testing.B) {
	values := make([]float32, 8400*84)
	r := &nativeEmbeddingRuntime{base: &nativeEmbeddingBackend{bindings: nativeNCNNBindings{
		extractorExtract: func(_ uintptr, _ *byte, out *uintptr) int32 { *out = 10; return 0 },
		matGetDims:       func(uintptr) int32 { return 2 },
		matGetW:          func(uintptr) int32 { return 8400 },
		matGetH:          func(uintptr) int32 { return 84 },
		matGetD:          func(uintptr) int32 { return 0 },
		matGetC:          func(uintptr) int32 { return 0 },
		matGetData:       func(uintptr) unsafe.Pointer { return unsafe.Pointer(&values[0]) },
		matDestroy:       func(uintptr) {},
	}}}
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		output, err := r.extractNativeVisionOutputMat(1, "output")
		if err != nil || len(output.values) != len(values) {
			b.Fatalf("extract: %v", err)
		}
		r.base.bindings.matDestroy(output.mat)
	}
}

func TestNativeVisionDetectionsOwnResultsAfterMatDestruction(t *testing.T) {
	bundleDir := writeNativeSplitFaceBundleForTest(t)
	r := newNativeSplitFaceRuntimeForTest(t, bundleDir)
	input, err := prepareNativeVisionImageInput(bundleDir, map[string]interface{}{"image": writeNativeVisionSourceImageForTest(t)})
	if err != nil {
		t.Fatal(err)
	}
	const outputMat = uintptr(201)
	values := unsafe.Slice((*float32)(r.base.bindings.matGetData(outputMat)), 5)
	want := decodeNativeYOLOv8DetectOutputWithClass(append([]float32(nil), values...), 1, 5, input, "face")
	destroyed := false
	r.base.bindings.matDestroy = func(mat uintptr) {
		if mat == outputMat {
			destroyed = true
			for i := range values {
				values[i] = float32(math.NaN())
			}
		}
	}
	got, err := r.detectVision(modelClassVision, input, 0, "face", false)
	if err != nil {
		t.Fatal(err)
	}
	if !destroyed || !reflect.DeepEqual(got, want) {
		t.Fatalf("results changed after Mat release: destroyed=%v got=%#v want=%#v", destroyed, got, want)
	}
}

func TestNativeVisionOutputBorrowsTheLiveMat(t *testing.T) {
	values := []float32{1, 2, 3, 4, 5, 6}
	destroyed := 0
	r := &nativeEmbeddingRuntime{base: &nativeEmbeddingBackend{bindings: nativeNCNNBindings{
		extractorExtract: func(_ uintptr, _ *byte, out *uintptr) int32 { *out = 10; return 0 },
		matGetDims:       func(uintptr) int32 { return 2 },
		matGetW:          func(uintptr) int32 { return 3 },
		matGetH:          func(uintptr) int32 { return 2 },
		matGetD:          func(uintptr) int32 { return 0 },
		matGetC:          func(uintptr) int32 { return 0 },
		matGetData:       func(uintptr) unsafe.Pointer { return unsafe.Pointer(&values[0]) },
		matDestroy: func(uintptr) {
			destroyed++
			for i := range values {
				values[i] = -999
			}
		},
	}}}
	output, err := r.extractNativeVisionOutputMat(1, "output")
	if err != nil {
		t.Fatal(err)
	}
	if destroyed != 0 || output.mat != 10 {
		t.Fatal("returned a destroyed Mat")
	}
	if &output.values[0] != &values[0] {
		t.Fatal("extraction copied the entire output instead of borrowing the live Mat")
	}
	if output.dims != 2 || output.width != 3 || output.height != 2 || len(output.values) != len(values) {
		t.Fatalf("invalid shape: %+v", output)
	}
	// Owned model results must survive after the caller releases the Mat.
	owned := append([]float32(nil), output.values...)
	r.base.bindings.matDestroy(output.mat)
	if destroyed != 1 || owned[0] != 1 {
		t.Fatal("releasing Mat changed owned results")
	}
	values[0] = float32(math.NaN())
	if _, err := r.extractNativeVisionOutputMat(1, "output"); err == nil || !strings.Contains(err.Error(), "non-finite") {
		t.Fatalf("non-finite output: %v", err)
	}
	if destroyed != 2 {
		t.Fatalf("failed extraction leaked Mat: %d destructions", destroyed)
	}
}
