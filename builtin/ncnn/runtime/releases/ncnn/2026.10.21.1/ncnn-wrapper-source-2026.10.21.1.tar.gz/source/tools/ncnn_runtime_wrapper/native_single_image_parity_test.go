package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
)

// Optional real-model check. Run the same test binary from the baseline and
// optimized sources, then compare the JSON and tensor digests byte for byte.
func TestNativeSingleImageOutputParity(t *testing.T) {
	outputDir := os.Getenv("ZIMAOS_NCNN_PARITY_OUTPUT_DIR")
	if outputDir == "" || os.Getenv(envNativeLibraryPath) == "" {
		t.Skip("set local NCNN library, benchmark bundles and parity output directory")
	}
	if err := os.MkdirAll(outputDir, 0o700); err != nil {
		t.Fatal(err)
	}
	for _, task := range []string{"detect", "face_detect", "face_embed"} {
		t.Run(task, func(t *testing.T) {
			bundleDir := os.Getenv("ZIMAOS_NCNN_BENCHMARK_DETECT_BUNDLE")
			if task != "detect" {
				bundleDir = os.Getenv("ZIMAOS_NCNN_BENCHMARK_FACE_BUNDLE")
			}
			if bundleDir == "" {
				t.Skip("set existing local benchmark model bundle")
			}
			backend, err := openNativeEmbeddingBackend()
			if err != nil {
				t.Fatal(err)
			}
			runtimeValue := &nativeEmbeddingRuntime{base: backend, loaded: make(map[string]*nativeEmbeddingModel)}
			if err := runtimeValue.load(modelClassVision, bundleDir, nativeEmbeddingLoadOptions{threadLimit: 4}); err != nil {
				t.Fatal(err)
			}
			t.Cleanup(func() { runtimeValue.unload(modelClassVision) })
			body, _ := nativePerformanceJPEG(t, 768, 512)
			path := filepath.Join(t.TempDir(), "source.jpg")
			if err := os.WriteFile(path, body, 0o600); err != nil {
				t.Fatal(err)
			}
			input := map[string]interface{}{"image": path}
			prepared, err := prepareNativeVisionImageInput(bundleDir, input)
			if err != nil {
				t.Fatal(err)
			}
			pixels := prepared.pixels
			if task == "face_embed" {
				face := nativePerformanceFace()
				input["faces"] = []map[string]interface{}{face}
				pixels, _, _, err = nativeFaceEmbeddingPixelsForFace(prepared.sourceImage, prepared.profile, face)
				if err != nil {
					t.Fatal(err)
				}
			}
			state := &wrapperRuntimeState{loadedBundles: make(map[string]string), loadedBundleIDs: make(map[string]string)}
			state.rememberLoad(modelClassVision, []string{"cpu"}, bundleDir, "parity")
			result, handled := tryNativeVisionInfer(state, nativeEmbeddingSpec{backend: runtimeValue}, inferRequest{
				ModelClass: modelClassVision, Task: task, ThreadLimit: 4, Input: input,
			})
			if !handled || result.Output["ok"] != true {
				t.Fatalf("native inference: %#v", result.Output)
			}
			digest := sha256.Sum256(pixels)
			payload, err := json.MarshalIndent(map[string]interface{}{
				"tensor_sha256": hex.EncodeToString(digest[:]), "output": result.Output,
			}, "", "  ")
			if err != nil {
				t.Fatal(err)
			}
			if err := os.WriteFile(filepath.Join(outputDir, task+".json"), payload, 0o600); err != nil {
				t.Fatal(err)
			}
		})
	}
}
