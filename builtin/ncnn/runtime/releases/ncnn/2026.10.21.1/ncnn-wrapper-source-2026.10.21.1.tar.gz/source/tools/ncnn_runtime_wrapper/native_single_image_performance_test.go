package main

import (
	"bytes"
	"fmt"
	"image"
	"image/jpeg"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func nativePerformanceImage(width, height int) *image.NRGBA {
	src := image.NewNRGBA(image.Rect(0, 0, width, height))
	for y := 0; y < height; y++ {
		for x := 0; x < width; x++ {
			i := src.PixOffset(x, y)
			src.Pix[i], src.Pix[i+1], src.Pix[i+2], src.Pix[i+3] = byte(x*7), byte(y*11), byte(x+y), byte(x*3+y*5)
		}
	}
	return src
}

func nativePerformanceJPEG(b testing.TB, width, height int) ([]byte, image.Image) {
	b.Helper()
	src := nativePerformanceImage(width, height)
	for i := 3; i < len(src.Pix); i += 4 {
		src.Pix[i] = 255
	}
	var buf bytes.Buffer
	if err := jpeg.Encode(&buf, src, &jpeg.Options{Quality: 90}); err != nil {
		b.Fatal(err)
	}
	decoded, err := jpeg.Decode(bytes.NewReader(buf.Bytes()))
	if err != nil {
		b.Fatal(err)
	}
	return buf.Bytes(), decoded
}

func BenchmarkNativePixelPacking(b *testing.B) {
	for _, size := range [][2]int{{640, 640}, {1280, 768}} {
		src := nativePerformanceImage(size[0], size[1])
		for _, mode := range []string{"vision_rgb", "ocr_rgb", "ocr_bgr"} {
			b.Run(fmt.Sprintf("%dx%d/%s", size[0], size[1], mode), func(b *testing.B) {
				b.ReportAllocs()
				b.ResetTimer()
				for i := 0; i < b.N; i++ {
					var pixels []byte
					if mode == "vision_rgb" {
						pixels = nativeVisionRGBPixels(src)
					} else {
						pixels = rapidOCRPixels(src, mode == "ocr_bgr")
					}
					if len(pixels) != size[0]*size[1]*3 {
						b.Fatal("invalid packed pixels")
					}
				}
			})
		}
	}
}

func nativePerformanceFace() map[string]interface{} {
	landmarks := make([][]float64, len(nativeAdaFace112Template))
	for i, point := range nativeAdaFace112Template {
		landmarks[i] = []float64{point[0]*3 + 40, point[1]*3 + 30}
	}
	return map[string]interface{}{"pixel_landmarks": landmarks, "pixel_bbox": []float64{100, 120, 340, 380}}
}

func BenchmarkNativeFaceAlignment(b *testing.B) {
	_, jpegSource := nativePerformanceJPEG(b, 512, 512)
	for _, kind := range []string{"nrgba", "jpeg"} {
		var src image.Image = nativePerformanceImage(512, 512)
		if kind == "jpeg" {
			src = jpegSource
		}
		b.Run(kind, func(b *testing.B) {
			face := nativePerformanceFace()
			profile := nativeVisionProfile{faceEmbeddingWidth: 112, faceEmbeddingHeight: 112}
			b.ReportAllocs()
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				pixels, _, _, err := nativeFaceEmbeddingPixelsForFace(src, profile, face)
				if err != nil || len(pixels) != 112*112*3 {
					b.Fatalf("align face: %v", err)
				}
			}
		})
	}
}

func BenchmarkNativeOCRCrop(b *testing.B) {
	_, src := nativePerformanceJPEG(b, 512, 512)
	box := rapidOCRDetBox{points: [4]rapidOCRPoint{{40, 40}, {360, 50}, {355, 130}, {35, 120}}}
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		if _, err := rapidOCRCropImage(src, box); err != nil {
			b.Fatal(err)
		}
	}
}

// Opt in to real CPU model execution with an existing local library and bundle.
// Models load before timing; each iteration reads and decodes one JPEG and runs
// preparation, the native graph and postprocessing, without network downloads.
func BenchmarkNativeSingleImageInference(b *testing.B) {
	for _, task := range []string{"detect", "face_detect", "face_embed"} {
		b.Run(task, func(b *testing.B) {
			bundleDir := strings.TrimSpace(os.Getenv("ZIMAOS_NCNN_BENCHMARK_DETECT_BUNDLE"))
			if task != "detect" {
				bundleDir = strings.TrimSpace(os.Getenv("ZIMAOS_NCNN_BENCHMARK_FACE_BUNDLE"))
			}
			if bundleDir == "" || strings.TrimSpace(os.Getenv(envNativeLibraryPath)) == "" {
				b.Skip("set local NCNN library and benchmark bundle paths")
			}
			backend, err := openNativeEmbeddingBackend()
			if err != nil {
				b.Fatal(err)
			}
			runtimeValue := &nativeEmbeddingRuntime{base: backend, loaded: make(map[string]*nativeEmbeddingModel)}
			if err := runtimeValue.load(modelClassVision, bundleDir, nativeEmbeddingLoadOptions{threadLimit: 4}); err != nil {
				b.Fatal(err)
			}
			b.Cleanup(func() { runtimeValue.unload(modelClassVision) })
			body, _ := nativePerformanceJPEG(b, 768, 512)
			path := filepath.Join(b.TempDir(), "source.jpg")
			if err := os.WriteFile(path, body, 0o600); err != nil {
				b.Fatal(err)
			}
			state := &wrapperRuntimeState{loadedBundles: make(map[string]string), loadedBundleIDs: make(map[string]string)}
			state.rememberLoad(modelClassVision, []string{"cpu"}, bundleDir, "benchmark")
			request := inferRequest{ModelClass: modelClassVision, Task: task, ThreadLimit: 4, Input: map[string]interface{}{"image": path}}
			if task == "face_embed" {
				request.Input["faces"] = []map[string]interface{}{nativePerformanceFace()}
			}
			b.ReportAllocs()
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				result, handled := tryNativeVisionInfer(state, nativeEmbeddingSpec{backend: runtimeValue}, request)
				if !handled || result.Output["ok"] != true {
					b.Fatalf("native single image inference: %#v", result.Output)
				}
			}
		})
	}
}
