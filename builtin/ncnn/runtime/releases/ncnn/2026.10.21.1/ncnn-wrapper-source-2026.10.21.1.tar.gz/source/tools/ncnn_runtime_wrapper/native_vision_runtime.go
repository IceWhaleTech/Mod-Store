package main

import (
	"bytes"
	"fmt"
	"image"
	"image/color"
	"math"
	"os"
	"path/filepath"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"unsafe"

	"github.com/disintegration/imaging"
)

const nativeMatPixelRGB int32 = 1

type nativeVisionProfileKind string

const (
	nativeVisionProfileYOLOv8Detect   nativeVisionProfileKind = "yolov8_detect"
	nativeVisionProfileSCRFDFace      nativeVisionProfileKind = "scrfd_face"
	defaultYOLOv8DetectScoreThreshold                         = 0.25
	defaultYOLOv8DetectNMSThreshold                           = 0.45
	defaultSCRFDFaceScoreThreshold                            = 0.35
	defaultSCRFDFaceNMSThreshold                              = 0.45
	envNativeSCRFDDebug                                       = "ZIMAOS_NCNN_DEBUG_SCRFD"
)

type nativeVisionProfile struct {
	kind                nativeVisionProfileKind
	normalizeOutput     bool
	inputBlobName       string
	outputBlobName      string
	targetWidth         int
	targetHeight        int
	outputDim           int
	classCount          int
	classLabels         []string
	meanValues          []float32
	normValues          []float32
	detectorSubdir      string
	scrfdScoreBlobs     []string
	scrfdBBoxBlobs      []string
	scrfdKPSBlobs       []string
	scrfdStrides        []int
	faceBundle          bool
	faceEmbeddingSubdir string
	faceEmbeddingWidth  int
	faceEmbeddingHeight int
	faceEmbeddingDim    int
	faceEmbeddingMean   []float32
	faceEmbeddingNorm   []float32
}

type nativePreparedVisionInput struct {
	profile      nativeVisionProfile
	width        int
	height       int
	sourceWidth  int
	sourceHeight int
	scale        float64
	padX         int
	padY         int
	sourceImage  image.Image
	pixels       []byte
}

type nativeVisionOutputMat struct {
	values   []float32
	dims     int
	width    int
	height   int
	depth    int
	channels int
}

func tryNativeVisionLoad(native nativeEmbeddingSpec, modelClass, bundleDir string, req loadRequest, backendRequested []string) (loadResultPayload, bool, error) {
	if native.backend == nil || !strings.EqualFold(modelClassBase(modelClass), modelClassVision) {
		return loadResultPayload{}, false, nil
	}
	if _, ok, err := detectNativeVisionProfile(bundleDir); err != nil {
		return loadResultPayload{}, true, err
	} else if !ok {
		return loadResultPayload{}, false, nil
	}
	options := resolveNativeEmbeddingLoadOptions(mergeBundleLoadMetadataForNativeRuntime(bundleDir, req.Metadata), req.ThreadLimit)
	if err := native.backend.load(modelClass, bundleDir, options); err != nil {
		return loadResultPayload{}, true, err
	}
	degradedToCPU := len(backendRequested) > 0 && !onlyCPUBackends(backendRequested)
	degradeReason := ""
	if degradedToCPU {
		degradeReason = "ncnn_native_vision_cpu_only"
	}
	return loadResultPayload{
		loadResult: loadResult{
			BackendEffective: "cpu",
			DeviceEffective:  native.deviceID(),
			DegradedToCPU:    degradedToCPU,
			DegradeReason:    degradeReason,
		},
	}, true, nil
}

func tryNativeVisionInfer(state *wrapperRuntimeState, native nativeEmbeddingSpec, parsed inferRequest) (wrapperInferResult, bool) {
	modelClass := strings.TrimSpace(parsed.ModelClass)
	if !strings.EqualFold(modelClassBase(modelClass), modelClassVision) || native.backend == nil {
		return wrapperInferResult{}, false
	}
	if state == nil {
		return wrapperInferResult{}, false
	}
	bundleDir, bundleID, ok := state.loadedBundle(modelClass)
	if !ok {
		return wrapperInferResult{}, false
	}
	profile, supported, err := detectNativeVisionProfile(bundleDir)
	if err != nil {
		return wrapperInferResult{
			Output: map[string]interface{}{
				"ok":             false,
				"error":          err.Error(),
				"degrade_reason": "ncnn_native_vision_invalid_bundle",
				"model_class":    modelClass,
				"bundle_id":      bundleID,
				"task":           strings.TrimSpace(parsed.Task),
				"loaded":         true,
			},
		}, true
	} else if !supported {
		return wrapperInferResult{}, false
	}
	prepared, err := prepareNativeVisionImageInputForTask(profile, parsed.Input, parsed.Task)
	if err != nil {
		return wrapperInferResult{
			Output: map[string]interface{}{
				"ok":             false,
				"error":          err.Error(),
				"degrade_reason": "ncnn_native_vision_invalid_input",
				"model_class":    modelClass,
				"bundle_id":      bundleID,
				"task":           strings.TrimSpace(parsed.Task),
				"loaded":         true,
			},
		}, true
	}
	switch prepared.profile.kind {
	case nativeVisionProfileYOLOv8Detect, nativeVisionProfileSCRFDFace:
		task := strings.ToLower(strings.TrimSpace(parsed.Task))
		faceTask := prepared.profile.faceBundle && task == "face"
		faceDetectTask := prepared.profile.faceBundle && task == "face_detect"
		faceEmbedTask := prepared.profile.faceBundle && task == "face_embed"
		if task != "detect" && !strings.HasPrefix(task, "detect_") && !faceTask && !faceDetectTask && !faceEmbedTask {
			return wrapperInferResult{
				Output: map[string]interface{}{
					"ok":    false,
					"error": "unsupported_task",
					"task":  strings.TrimSpace(parsed.Task),
				},
			}, true
		}
		if faceEmbedTask {
			faces, parseErr := nativeFaceMapsFromInput(parsed.Input["faces"])
			if parseErr != nil {
				return wrapperInferResult{
					Output: map[string]interface{}{
						"ok":             false,
						"error":          parseErr.Error(),
						"degrade_reason": "ncnn_native_vision_invalid_input",
						"model_class":    modelClass,
						"bundle_id":      bundleID,
						"task":           strings.TrimSpace(parsed.Task),
						"loaded":         true,
					},
				}, true
			}
			embeddedFaces, inferErr := native.backend.embedVisionFaces(modelClass, prepared, faces, parsed.ThreadLimit)
			if inferErr != nil {
				return wrapperInferResult{
					Output: map[string]interface{}{
						"ok":             false,
						"error":          inferErr.Error(),
						"degrade_reason": "ncnn_native_vision_failed",
						"model_class":    modelClass,
						"bundle_id":      bundleID,
						"task":           strings.TrimSpace(parsed.Task),
						"loaded":         true,
					},
				}, true
			}
			return wrapperInferResult{Output: map[string]interface{}{
				"faces":       embeddedFaces,
				"bundle_id":   bundleID,
				"model_class": modelClass,
				"ok":          true,
			}}, true
		}
		requestedClass := requestedNativeVisionDetectClass(parsed)
		if faceTask && requestedClass == "" {
			requestedClass = "face"
		}
		output, inferErr := native.backend.detectVision(modelClass, prepared, parsed.ThreadLimit, requestedClass, !faceDetectTask)
		if inferErr != nil {
			return wrapperInferResult{
				Output: map[string]interface{}{
					"ok":             false,
					"error":          inferErr.Error(),
					"degrade_reason": "ncnn_native_vision_failed",
					"model_class":    modelClass,
					"bundle_id":      bundleID,
					"task":           strings.TrimSpace(parsed.Task),
					"loaded":         true,
				},
			}, true
		}
		output["bundle_id"] = bundleID
		output["model_class"] = modelClass
		output["ok"] = true
		return wrapperInferResult{Output: output}, true
	default:
		return wrapperInferResult{
			Output: map[string]interface{}{
				"ok":    false,
				"error": "unsupported_task",
				"task":  strings.TrimSpace(parsed.Task),
			},
		}, true
	}
}

func detectNativeVisionProfile(bundleDir string) (nativeVisionProfile, bool, error) {
	metadata := readBundleMetadataForNativeRuntime(bundleDir)
	if len(metadata) == 0 {
		return nativeVisionProfile{}, false, nil
	}
	inputBlobName, outputBlobName := resolveNativeVisionIOBlobNames(bundleDir, metadata, "in0", "out0")
	bundleID := strings.TrimSpace(strings.ToLower(metadataStringValue(metadata["bundle_id"])))
	targetWidth := 256
	targetHeight := 256
	if value, ok := metadataIntValue(metadata["input_width"]); ok && value > 0 {
		targetWidth = value
	}
	if value, ok := metadataIntValue(metadata["input_height"]); ok && value > 0 {
		targetHeight = value
	}
	if task := strings.TrimSpace(strings.ToLower(metadataStringValue(metadata["task"]))); task == "detect" {
		if size := metadataIntSlice(metadata["input_size"]); len(size) >= 2 {
			if size[0] > 0 {
				targetWidth = size[0]
			}
			if size[1] > 0 {
				targetHeight = size[1]
			}
		}
		classCount, ok := metadataIntValue(metadata["classes"])
		if !ok || classCount <= 0 {
			classCount = len(nativeYOLOv8COCOClassLabels)
		}
		meanValues, normValues := nativeVisionNormalizationFromMetadata(metadata)
		if len(normValues) == 0 {
			normValues = []float32{1.0 / 255.0, 1.0 / 255.0, 1.0 / 255.0}
		}
		return nativeVisionProfile{
			kind:           nativeVisionProfileYOLOv8Detect,
			inputBlobName:  inputBlobName,
			outputBlobName: outputBlobName,
			targetWidth:    targetWidth,
			targetHeight:   targetHeight,
			classCount:     classCount,
			meanValues:     meanValues,
			normValues:     normValues,
		}, true, nil
	}
	if faceProfile, ok := nativeVisionFaceProfile(bundleDir, metadata, bundleID, targetWidth, targetHeight); ok {
		if strings.TrimSpace(faceProfile.inputBlobName) == "" {
			faceProfile.inputBlobName = inputBlobName
		}
		if strings.TrimSpace(faceProfile.outputBlobName) == "" {
			faceProfile.outputBlobName = outputBlobName
		}
		return faceProfile, true, nil
	}
	return nativeVisionProfile{}, false, nil
}

func prepareNativeVisionImageInput(bundleDir string, input map[string]interface{}) (nativePreparedVisionInput, error) {
	profile, ok, err := detectNativeVisionProfile(bundleDir)
	if err != nil {
		return nativePreparedVisionInput{}, err
	}
	if !ok {
		return nativePreparedVisionInput{}, fmt.Errorf("unsupported native vision bundle")
	}
	return prepareNativeVisionImageInputForTask(profile, input, "")
}

func prepareNativeVisionImageInputForTask(profile nativeVisionProfile, input map[string]interface{}, task string) (nativePreparedVisionInput, error) {
	imagePath, _ := input["image"].(string)
	imagePath = strings.TrimSpace(imagePath)
	if imagePath == "" {
		return nativePreparedVisionInput{}, fmt.Errorf("image must be provided for native vision inference")
	}
	src, err := imaging.Open(imagePath)
	if err != nil {
		return nativePreparedVisionInput{}, fmt.Errorf("open image %s: %w", imagePath, err)
	}
	sourceBounds := src.Bounds()
	sourceWidth := sourceBounds.Dx()
	sourceHeight := sourceBounds.Dy()
	if profile.faceBundle && strings.EqualFold(strings.TrimSpace(task), "face_embed") {
		// Embedding only reads the source for aligned face crops. Preparing the
		// full detector tensor here would resize, pad and pack unused pixels.
		return nativePreparedVisionInput{
			profile:      profile,
			sourceWidth:  sourceWidth,
			sourceHeight: sourceHeight,
			sourceImage:  src,
		}, nil
	}
	switch profile.kind {
	case nativeVisionProfileYOLOv8Detect, nativeVisionProfileSCRFDFace:
		scale := math.Min(float64(profile.targetWidth)/float64(sourceWidth), float64(profile.targetHeight)/float64(sourceHeight))
		resizedWidth := maxInt(1, int(math.Round(float64(sourceWidth)*scale)))
		resizedHeight := maxInt(1, int(math.Round(float64(sourceHeight)*scale)))
		padX := (profile.targetWidth - resizedWidth) / 2
		padY := (profile.targetHeight - resizedHeight) / 2
		linear := rapidOCRLinearSource{width: sourceWidth, height: sourceHeight}
		switch src := src.(type) {
		case *image.NRGBA:
			linear.nrgba = src
		case *image.YCbCr:
			linear.ycbcr = src
		}
		var pixels []byte
		if resizedWidth != sourceWidth && resizedHeight != sourceHeight &&
			profile.targetWidth > 0 && profile.targetHeight > 0 && padX >= 0 && padY >= 0 &&
			(linear.nrgba != nil || linear.ycbcr != nil) {
			// Keep the original two-stage Linear quantization, but write the
			// visible RGB directly. Neither full NRGBA resize canvas is needed.
			pixels = bytes.Repeat([]byte{114}, profile.targetWidth*profile.targetHeight*3)
			offset := (padY*profile.targetWidth + padX) * 3
			nativeResizeLinearInto(linear, resizedWidth, resizedHeight, pixels[offset:], profile.targetWidth*3, 3)
		} else {
			resized := imaging.Resize(src, resizedWidth, resizedHeight, imaging.Linear)
			pixels = nativeImageRGBPixelsPadded(resized, profile.targetWidth, profile.targetHeight, image.Pt(padX, padY), 114)
		}
		return nativePreparedVisionInput{
			profile:      profile,
			width:        profile.targetWidth,
			height:       profile.targetHeight,
			sourceWidth:  sourceWidth,
			sourceHeight: sourceHeight,
			scale:        scale,
			padX:         padX,
			padY:         padY,
			sourceImage:  src,
			pixels:       pixels,
		}, nil
	default:
		preprocessed := imaging.Fill(src, profile.targetWidth, profile.targetHeight, imaging.Center, imaging.Linear)
		bounds := preprocessed.Bounds()
		return nativePreparedVisionInput{
			profile:      profile,
			width:        bounds.Dx(),
			height:       bounds.Dy(),
			sourceWidth:  sourceWidth,
			sourceHeight: sourceHeight,
			sourceImage:  src,
			pixels:       nativeVisionRGBPixels(preprocessed),
		}, nil
	}
}

func (r *nativeEmbeddingRuntime) inferVision(modelClass string, input nativePreparedVisionInput, threadLimit int) ([]float64, error) {
	if r == nil || r.base == nil {
		return nil, fmt.Errorf("native embedding backend unavailable")
	}
	model, unlockModel := r.lockLoadedModelForInfer(modelClass)
	if unlockModel != nil {
		defer unlockModel()
	}
	if model == nil || model.net == 0 {
		return nil, fmt.Errorf("native vision model class %s is not loaded", strings.TrimSpace(modelClass))
	}
	if model.visionProfile.kind == "" {
		return nil, fmt.Errorf("native vision profile not loaded")
	}
	return r.inferVisionNet(model, model.net, input, threadLimit)
}

func (r *nativeEmbeddingRuntime) inferVisionNet(model *nativeEmbeddingModel, net uintptr, input nativePreparedVisionInput, threadLimit int) ([]float64, error) {
	if r == nil || r.base == nil {
		return nil, fmt.Errorf("native embedding backend unavailable")
	}
	if model == nil || net == 0 {
		return nil, fmt.Errorf("native vision model is not loaded")
	}
	if len(input.pixels) == 0 || input.width <= 0 || input.height <= 0 {
		return nil, fmt.Errorf("native vision input pixels are empty")
	}

	stride := int32(input.width * 3)
	mat := r.base.bindings.matFromPixels(byteSliceCStringPointer(input.pixels), nativeMatPixelRGB, int32(input.width), int32(input.height), stride, 0)
	if mat == 0 {
		return nil, fmt.Errorf("failed to create NCNN input mat from image pixels")
	}
	defer r.base.bindings.matDestroy(mat)

	var meanPtr *float32
	if len(input.profile.meanValues) > 0 {
		meanPtr = &input.profile.meanValues[0]
	}
	var normPtr *float32
	if len(input.profile.normValues) > 0 {
		normPtr = &input.profile.normValues[0]
	}
	if meanPtr != nil || normPtr != nil {
		r.base.bindings.matSubstractMeanNormalize(mat, meanPtr, normPtr)
	}

	extractor := r.base.bindings.extractorCreate(net)
	if extractor == 0 {
		return nil, fmt.Errorf("failed to create NCNN extractor")
	}
	defer r.base.bindings.extractorDestroy(extractor)

	effectiveThreadLimit := threadLimit
	if effectiveThreadLimit <= 0 {
		effectiveThreadLimit = model.threadLimit
	}
	if effectiveThreadLimit > 0 {
		extractorOpt := r.base.bindings.optionCreate()
		if extractorOpt != 0 {
			r.base.configureExtractorOption(extractorOpt, effectiveThreadLimit, model)
			r.base.bindings.extractorSetOption(extractor, extractorOpt)
			r.base.bindings.optionDestroy(extractorOpt)
		}
	}

	in0 := append([]byte(nativeVisionInputBlobName(input.profile)), 0)
	if code := r.base.bindings.extractorInput(extractor, byteSliceCStringPointer(in0), mat); code != 0 {
		return nil, fmt.Errorf("failed to bind NCNN vision input %s: %d", strings.TrimRight(string(in0), "\x00"), code)
	}

	out0 := append([]byte(nativeVisionOutputBlobName(input.profile)), 0)
	var outputMat uintptr
	if code := r.base.bindings.extractorExtract(extractor, byteSliceCStringPointer(out0), &outputMat); code != 0 {
		return nil, fmt.Errorf("failed to extract NCNN vision output %s: %d", strings.TrimRight(string(out0), "\x00"), code)
	}
	if outputMat == 0 {
		return nil, fmt.Errorf("native NCNN vision extractor returned nil output mat")
	}
	defer r.base.bindings.matDestroy(outputMat)

	total := nativeMatElementCount(r.base.bindings, outputMat)
	if total <= 0 {
		return nil, fmt.Errorf("native NCNN vision output mat was empty")
	}
	data := r.base.bindings.matGetData(outputMat)
	if data == nil {
		return nil, fmt.Errorf("native NCNN vision output mat data pointer was nil")
	}
	values := unsafe.Slice((*float32)(data), total)
	result := make([]float64, total)
	for i, value := range values {
		if !nativeFloat32IsFinite(value) {
			return nil, fmt.Errorf("native NCNN vision output contains non-finite value at index %d", i)
		}
		result[i] = float64(value)
	}
	result = postprocessNativeVisionOutput(result, input.profile)
	runtime.KeepAlive(input.pixels)
	runtime.KeepAlive(input.profile.meanValues)
	runtime.KeepAlive(input.profile.normValues)
	return result, nil
}

func (r *nativeEmbeddingRuntime) detectVision(modelClass string, input nativePreparedVisionInput, threadLimit int, requestedClass string, includeFaceEmbeddings bool) (map[string]interface{}, error) {
	if r == nil || r.base == nil {
		return nil, fmt.Errorf("native embedding backend unavailable")
	}
	model, unlockModel := r.lockLoadedModelForInfer(modelClass)
	if unlockModel != nil {
		defer unlockModel()
	}
	if model == nil || model.net == 0 {
		return nil, fmt.Errorf("native vision model class %s is not loaded", strings.TrimSpace(modelClass))
	}
	if model.visionProfile.kind != nativeVisionProfileYOLOv8Detect && model.visionProfile.kind != nativeVisionProfileSCRFDFace {
		return nil, fmt.Errorf("native detect vision profile not loaded")
	}
	if len(input.pixels) == 0 || input.width <= 0 || input.height <= 0 {
		return nil, fmt.Errorf("native vision input pixels are empty")
	}

	stride := int32(input.width * 3)
	mat := r.base.bindings.matFromPixels(byteSliceCStringPointer(input.pixels), nativeMatPixelRGB, int32(input.width), int32(input.height), stride, 0)
	if mat == 0 {
		return nil, fmt.Errorf("failed to create NCNN input mat from image pixels")
	}
	defer r.base.bindings.matDestroy(mat)

	var meanPtr *float32
	if len(input.profile.meanValues) > 0 {
		meanPtr = &input.profile.meanValues[0]
	}
	var normPtr *float32
	if len(input.profile.normValues) > 0 {
		normPtr = &input.profile.normValues[0]
	}
	if meanPtr != nil || normPtr != nil {
		r.base.bindings.matSubstractMeanNormalize(mat, meanPtr, normPtr)
	}

	extractor := r.base.bindings.extractorCreate(model.net)
	if extractor == 0 {
		return nil, fmt.Errorf("failed to create NCNN extractor")
	}
	defer r.base.bindings.extractorDestroy(extractor)

	effectiveThreadLimit := threadLimit
	if effectiveThreadLimit <= 0 {
		effectiveThreadLimit = model.threadLimit
	}
	if effectiveThreadLimit > 0 {
		extractorOpt := r.base.bindings.optionCreate()
		if extractorOpt != 0 {
			r.base.configureExtractorOption(extractorOpt, effectiveThreadLimit, model)
			r.base.bindings.extractorSetOption(extractor, extractorOpt)
			r.base.bindings.optionDestroy(extractorOpt)
		}
	}

	in0 := append([]byte(nativeVisionInputBlobName(model.visionProfile)), 0)
	if code := r.base.bindings.extractorInput(extractor, byteSliceCStringPointer(in0), mat); code != 0 {
		return nil, fmt.Errorf("failed to bind NCNN detect input %s: %d", strings.TrimRight(string(in0), "\x00"), code)
	}

	var result map[string]interface{}
	switch model.visionProfile.kind {
	case nativeVisionProfileSCRFDFace:
		outputs := make(map[string]nativeVisionOutputMat)
		for _, outputName := range nativeSCRFDOutputBlobNames(model.visionProfile) {
			outputMat, err := r.extractNativeVisionOutputMat(extractor, outputName)
			if err != nil {
				return nil, err
			}
			if outputMat.mat != 0 {
				defer r.base.bindings.matDestroy(outputMat.mat)
			}
			outputs[outputName] = outputMat.nativeVisionOutputMat
		}
		result = decodeNativeSCRFDFaceOutput(outputs, input)
	default:
		outputMat, err := r.extractNativeVisionOutputMat(extractor, nativeVisionOutputBlobName(model.visionProfile))
		if err != nil {
			return nil, err
		}
		if outputMat.mat != 0 {
			defer r.base.bindings.matDestroy(outputMat.mat)
		}
		result, err = decodeNativeYOLOv8OutputMatWithClass(outputMat.nativeVisionOutputMat, model.visionProfile, input, requestedClass)
		if err != nil {
			return nil, err
		}
	}
	if model.visionProfile.faceBundle && includeFaceEmbeddings {
		if faces, ok := result["faces"].([]map[string]interface{}); ok && len(faces) > 0 && model.faceEmbeddingNet != 0 {
			for _, face := range faces {
				embedding, err := r.inferFaceEmbedding(model, input, face, threadLimit)
				if err != nil || len(embedding) == 0 {
					continue
				}
				face["embedding"] = embedding
			}
		}
	}
	runtime.KeepAlive(input.pixels)
	runtime.KeepAlive(input.sourceImage)
	runtime.KeepAlive(input.profile.meanValues)
	runtime.KeepAlive(input.profile.normValues)
	return result, nil
}

func (r *nativeEmbeddingRuntime) embedVisionFaces(modelClass string, input nativePreparedVisionInput, faces []map[string]interface{}, threadLimit int) ([]map[string]interface{}, error) {
	if r == nil || r.base == nil {
		return nil, fmt.Errorf("native embedding backend unavailable")
	}
	model, unlockModel := r.lockLoadedModelForInfer(modelClass)
	if unlockModel != nil {
		defer unlockModel()
	}
	if model == nil || model.faceEmbeddingNet == 0 {
		return nil, fmt.Errorf("native face embedding model class %s is not loaded", strings.TrimSpace(modelClass))
	}
	if !model.visionProfile.faceBundle {
		return nil, fmt.Errorf("native face vision profile not loaded")
	}
	result := make([]map[string]interface{}, 0, len(faces))
	for index, face := range faces {
		embedding, err := r.inferFaceEmbedding(model, input, face, threadLimit)
		if err != nil {
			return nil, fmt.Errorf("face embedding %d: %w", index, err)
		}
		if len(embedding) == 0 {
			return nil, fmt.Errorf("face embedding %d was empty", index)
		}
		embeddedFace := make(map[string]interface{}, len(face)+1)
		for key, value := range face {
			embeddedFace[key] = value
		}
		embeddedFace["embedding"] = embedding
		result = append(result, embeddedFace)
	}
	return result, nil
}

type nativeVisionExtractedMat struct {
	// values borrows mat storage; decode before destroying mat and return only
	// owned detections/vectors to callers outside this inference operation.
	nativeVisionOutputMat
	mat uintptr
}

func (r *nativeEmbeddingRuntime) extractNativeVisionOutputMat(extractor uintptr, outputName string) (nativeVisionExtractedMat, error) {
	if r == nil || r.base == nil {
		return nativeVisionExtractedMat{}, fmt.Errorf("native embedding backend unavailable")
	}
	outputName = strings.TrimSpace(outputName)
	if outputName == "" {
		return nativeVisionExtractedMat{}, fmt.Errorf("native vision output blob name is required")
	}
	out0 := append([]byte(outputName), 0)
	var outputMat uintptr
	code := r.base.bindings.extractorExtract(extractor, byteSliceCStringPointer(out0), &outputMat)
	releaseOutputMat := outputMat != 0
	defer func() {
		if releaseOutputMat {
			r.base.bindings.matDestroy(outputMat)
		}
	}()
	if code != 0 {
		return nativeVisionExtractedMat{}, fmt.Errorf("failed to extract NCNN detect output %s: %d", strings.TrimRight(string(out0), "\x00"), code)
	}
	if outputMat == 0 {
		return nativeVisionExtractedMat{}, fmt.Errorf("native NCNN detect extractor returned nil output mat for %s", outputName)
	}
	total := nativeMatElementCount(r.base.bindings, outputMat)
	if total <= 0 {
		return nativeVisionExtractedMat{}, fmt.Errorf("native NCNN detect output mat %s was empty", outputName)
	}
	data := r.base.bindings.matGetData(outputMat)
	if data == nil {
		return nativeVisionExtractedMat{}, fmt.Errorf("native NCNN detect output mat %s data pointer was nil", outputName)
	}
	values := unsafe.Slice((*float32)(data), total)
	for index, value := range values {
		if !nativeFloat32IsFinite(value) {
			return nativeVisionExtractedMat{}, fmt.Errorf("native NCNN detect output mat %s contains non-finite value at index %d", outputName, index)
		}
	}
	releaseOutputMat = false
	// The caller retains this Mat until decoding completes, so its validated
	// values can be read directly. Returned detections/vectors own their data.
	return nativeVisionExtractedMat{
		mat: outputMat,
		nativeVisionOutputMat: nativeVisionOutputMat{
			values:   values,
			dims:     int(r.base.bindings.matGetDims(outputMat)),
			width:    int(r.base.bindings.matGetW(outputMat)),
			height:   int(r.base.bindings.matGetH(outputMat)),
			depth:    int(r.base.bindings.matGetD(outputMat)),
			channels: int(r.base.bindings.matGetC(outputMat)),
		},
	}, nil
}

func nativeVisionFaceProfile(bundleDir string, metadata map[string]interface{}, bundleID string, targetWidth int, targetHeight int) (nativeVisionProfile, bool) {
	pipeline := metadataMapValue(metadata["pipeline"])
	detector := metadataMapValue(pipeline["detector"])
	detectorTask := strings.TrimSpace(strings.ToLower(metadataStringValue(detector["task"])))
	isFace := detectorTask == "face_detect" || bundleID == "face-int8" || bundleID == "zima-face-ncnn-int8"
	if !isFace {
		return nativeVisionProfile{}, false
	}
	if size := metadataIntSlice(detector["input_size"]); len(size) >= 2 {
		if size[0] > 0 {
			targetWidth = size[0]
		}
		if size[1] > 0 {
			targetHeight = size[1]
		}
	}
	meanValues, normValues := nativeVisionNormalizationFromMetadata(detector)
	if len(normValues) == 0 {
		normValues = []float32{1.0 / 255.0, 1.0 / 255.0, 1.0 / 255.0}
	}
	embedding := metadataMapValue(pipeline["embedding"])
	embeddingWidth := 112
	embeddingHeight := 112
	if size := metadataIntSlice(embedding["input_size"]); len(size) >= 2 {
		if size[0] > 0 {
			embeddingWidth = size[0]
		}
		if size[1] > 0 {
			embeddingHeight = size[1]
		}
	}
	embeddingDim, ok := metadataIntValue(embedding["output_dimension"])
	if !ok || embeddingDim <= 0 {
		embeddingDim = 512
	}
	embeddingMean, embeddingNorm := nativeVisionNormalizationFromMetadata(embedding)
	if len(embeddingMean) == 0 {
		embeddingMean = []float32{127.5, 127.5, 127.5}
	}
	if len(embeddingNorm) == 0 {
		embeddingNorm = []float32{1.0 / 127.5, 1.0 / 127.5, 1.0 / 127.5}
	}
	detectorSubdir := nativeSCRFDDetectorSubdir(bundleDir, metadata)
	kind := nativeVisionProfileYOLOv8Detect
	inputBlobName := ""
	outputBlobName := ""
	var scrfdScoreBlobs []string
	var scrfdBBoxBlobs []string
	var scrfdKPSBlobs []string
	var scrfdStrides []int
	if detectorSubdir != "" {
		kind = nativeVisionProfileSCRFDFace
		scrfdDetector := nativeSCRFDSelectedDetectorMetadata(pipeline, detector)
		inputBlobName, outputBlobName = resolveNativeVisionIOBlobNames(filepath.Join(bundleDir, detectorSubdir), scrfdDetector, "", "")
		scrfdScoreBlobs, scrfdBBoxBlobs, scrfdKPSBlobs, scrfdStrides = nativeSCRFDHeadsFromMetadata(scrfdDetector)
		if len(scrfdScoreBlobs) == 0 || len(scrfdBBoxBlobs) == 0 || len(scrfdStrides) == 0 {
			scrfdScoreBlobs = []string{"412", "474", "536"}
			scrfdBBoxBlobs = []string{"415", "477", "539"}
			scrfdKPSBlobs = nil
			scrfdStrides = []int{8, 16, 32}
		}
		meanValues = []float32{127.5, 127.5, 127.5}
		normValues = []float32{1.0 / 128.0, 1.0 / 128.0, 1.0 / 128.0}
	}
	return nativeVisionProfile{
		kind:                kind,
		inputBlobName:       inputBlobName,
		outputBlobName:      outputBlobName,
		targetWidth:         targetWidth,
		targetHeight:        targetHeight,
		classCount:          1,
		classLabels:         []string{"face"},
		meanValues:          meanValues,
		normValues:          normValues,
		detectorSubdir:      detectorSubdir,
		scrfdScoreBlobs:     scrfdScoreBlobs,
		scrfdBBoxBlobs:      scrfdBBoxBlobs,
		scrfdKPSBlobs:       scrfdKPSBlobs,
		scrfdStrides:        scrfdStrides,
		faceBundle:          true,
		faceEmbeddingSubdir: "embedding",
		faceEmbeddingWidth:  embeddingWidth,
		faceEmbeddingHeight: embeddingHeight,
		faceEmbeddingDim:    embeddingDim,
		faceEmbeddingMean:   embeddingMean,
		faceEmbeddingNorm:   embeddingNorm,
	}, true
}

func nativeSCRFDSelectedDetectorMetadata(pipeline map[string]interface{}, fallback map[string]interface{}) map[string]interface{} {
	defaultDetector := strings.TrimSpace(metadataStringValue(pipeline["default_detector"]))
	candidates := metadataMapValue(pipeline["detector_candidates"])
	selected := metadataMapValue(candidates[defaultDetector])
	if len(selected) == 0 {
		return fallback
	}
	return selected
}

func nativeSCRFDHeadsFromMetadata(detector map[string]interface{}) ([]string, []string, []string, []int) {
	postprocess := metadataMapValue(detector["postprocess"])
	outputBlobs := metadataMapValue(postprocess["output_blobs"])
	strides := metadataIntSlice(postprocess["feature_strides"])
	if len(strides) == 0 {
		strides = []int{8, 16, 32}
	}
	scores := make([]string, 0, len(strides))
	boxes := make([]string, 0, len(strides))
	keypoints := make([]string, 0, len(strides))
	resolvedStrides := make([]int, 0, len(strides))
	for _, stride := range strides {
		blobs := metadataStringSlice(outputBlobs[fmt.Sprintf("stride%d", stride)])
		if stride <= 0 || len(blobs) < 2 {
			continue
		}
		resolvedStrides = append(resolvedStrides, stride)
		scores = append(scores, blobs[0])
		boxes = append(boxes, blobs[1])
		if len(blobs) >= 3 {
			keypoints = append(keypoints, blobs[2])
		}
	}
	if len(keypoints) != len(resolvedStrides) {
		keypoints = nil
	}
	return scores, boxes, keypoints, resolvedStrides
}

func nativeSCRFDDetectorSubdir(bundleDir string, metadata map[string]interface{}) string {
	if bundleDir = strings.TrimSpace(bundleDir); bundleDir != "" {
		subdir := filepath.Join("detector", "scrfd-500m-kps")
		if info, err := os.Stat(filepath.Join(bundleDir, subdir, "model.param")); err == nil && !info.IsDir() {
			return subdir
		}
	}
	layout := metadataMapValue(metadata["bundle_layout"])
	if hasNativeSCRFDDetectorLayout(layout) {
		return filepath.Join("detector", "scrfd-500m-kps")
	}
	pipeline := metadataMapValue(metadata["pipeline"])
	detector := metadataMapValue(pipeline["detector"])
	for _, key := range []string{"subdir", "model_subdir", "path", "artifact_subdir"} {
		if value := strings.TrimSpace(metadataStringValue(detector[key])); strings.Contains(strings.ToLower(value), "scrfd") {
			if subdir := nativeVisionSafeBundleSubdir(bundleDir, value); subdir != "" {
				return subdir
			}
		}
	}
	return ""
}

func nativeVisionSafeBundleSubdir(bundleDir string, value string) string {
	subdir := filepath.Clean(strings.TrimSpace(value))
	if subdir == "." || filepath.IsAbs(subdir) {
		return ""
	}
	parentPrefix := ".." + string(filepath.Separator)
	if subdir == ".." || strings.HasPrefix(subdir, parentPrefix) {
		return ""
	}
	bundleDir = strings.TrimSpace(bundleDir)
	if bundleDir == "" {
		return subdir
	}
	relative, err := filepath.Rel(bundleDir, filepath.Join(bundleDir, subdir))
	if err != nil || filepath.IsAbs(relative) || relative == ".." || strings.HasPrefix(relative, parentPrefix) {
		return ""
	}
	return subdir
}

func hasNativeSCRFDDetectorLayout(layout map[string]interface{}) bool {
	for _, value := range layout {
		for _, artifact := range metadataStringSlice(value) {
			if strings.Contains(strings.ToLower(strings.TrimSpace(artifact)), "detector/scrfd-500m-kps") {
				return true
			}
		}
	}
	return false
}

func metadataStringValue(value interface{}) string {
	typed, ok := value.(string)
	if !ok {
		return ""
	}
	return typed
}

func metadataStringSlice(value interface{}) []string {
	raw, ok := value.([]interface{})
	if !ok {
		return nil
	}
	result := make([]string, 0, len(raw))
	for _, item := range raw {
		text, ok := item.(string)
		if !ok {
			return nil
		}
		result = append(result, text)
	}
	return result
}

func metadataIntValue(value interface{}) (int, bool) {
	switch typed := value.(type) {
	case int:
		return typed, true
	case int32:
		return int(typed), true
	case int64:
		return int(typed), true
	case float32:
		return int(typed), true
	case float64:
		return int(typed), true
	default:
		return 0, false
	}
}

func metadataIntSlice(value interface{}) []int {
	raw, ok := value.([]interface{})
	if !ok {
		return nil
	}
	result := make([]int, 0, len(raw))
	for _, item := range raw {
		number, ok := metadataIntValue(item)
		if !ok {
			return nil
		}
		result = append(result, number)
	}
	return result
}

func metadataMapValue(value interface{}) map[string]interface{} {
	typed, ok := value.(map[string]interface{})
	if !ok {
		return nil
	}
	return typed
}

func metadataFloat32Slice(value interface{}) []float32 {
	raw, ok := value.([]interface{})
	if !ok {
		return nil
	}
	result := make([]float32, 0, len(raw))
	for _, item := range raw {
		switch typed := item.(type) {
		case float64:
			result = append(result, float32(typed))
		case float32:
			result = append(result, typed)
		case int:
			result = append(result, float32(typed))
		case int64:
			result = append(result, float32(typed))
		default:
			return nil
		}
	}
	return result
}

func nativeVisionNormalizationFromMetadata(metadata map[string]interface{}) ([]float32, []float32) {
	nested, ok := metadata["normalization"].(map[string]interface{})
	if !ok {
		return nil, nil
	}
	return metadataFloat32Slice(nested["mean"]), metadataFloat32Slice(nested["norm"])
}

func resolveNativeVisionIOBlobNames(bundleDir string, metadata map[string]interface{}, defaultInput string, defaultOutput string) (string, string) {
	inputBlobName := strings.TrimSpace(defaultInput)
	if inputBlobName == "" {
		inputBlobName = "in0"
	}
	outputBlobName := strings.TrimSpace(defaultOutput)
	if outputBlobName == "" {
		outputBlobName = "out0"
	}

	for _, key := range []string{"input_blob", "input_name", "validated_input"} {
		if value := strings.TrimSpace(metadataStringValue(metadata[key])); value != "" {
			inputBlobName = value
			break
		}
	}
	for _, key := range []string{"output_blob", "output_name", "validated_output"} {
		if value := strings.TrimSpace(metadataStringValue(metadata[key])); value != "" {
			outputBlobName = value
			break
		}
	}

	paramInputBlobName, paramOutputBlobName := parseNativeVisionParamBlobNames(bundleDir)
	if inputBlobName == "" || inputBlobName == "in0" {
		if strings.TrimSpace(paramInputBlobName) != "" {
			inputBlobName = paramInputBlobName
		}
	}
	if outputBlobName == "" || outputBlobName == "out0" {
		if strings.TrimSpace(paramOutputBlobName) != "" {
			outputBlobName = paramOutputBlobName
		}
	}
	return inputBlobName, outputBlobName
}

func parseNativeVisionParamBlobNames(bundleDir string) (string, string) {
	data, err := os.ReadFile(filepath.Join(strings.TrimSpace(bundleDir), "model.param"))
	if err != nil {
		return "", ""
	}
	lines := strings.Split(string(data), "\n")
	producedOrder := make([]string, 0, len(lines))
	produced := make(map[string]struct{}, len(lines))
	consumed := make(map[string]struct{}, len(lines))
	inputBlobName := ""

	for _, rawLine := range lines {
		line := strings.TrimSpace(rawLine)
		if line == "" {
			continue
		}
		fields := strings.Fields(line)
		if len(fields) < 4 {
			continue
		}
		bottomCount, err := strconv.Atoi(fields[2])
		if err != nil {
			continue
		}
		topCount, err := strconv.Atoi(fields[3])
		if err != nil {
			continue
		}
		if bottomCount < 0 || topCount <= 0 || len(fields) < 4+bottomCount+topCount {
			continue
		}
		bottoms := fields[4 : 4+bottomCount]
		tops := fields[4+bottomCount : 4+bottomCount+topCount]
		if strings.EqualFold(fields[0], "Input") && inputBlobName == "" && len(tops) > 0 {
			inputBlobName = strings.TrimSpace(tops[0])
		}
		for _, bottom := range bottoms {
			bottom = strings.TrimSpace(bottom)
			if bottom == "" {
				continue
			}
			consumed[bottom] = struct{}{}
		}
		for _, top := range tops {
			top = strings.TrimSpace(top)
			if top == "" {
				continue
			}
			if _, ok := produced[top]; ok {
				continue
			}
			produced[top] = struct{}{}
			producedOrder = append(producedOrder, top)
		}
	}

	outputBlobName := ""
	for i := len(producedOrder) - 1; i >= 0; i-- {
		candidate := producedOrder[i]
		if _, ok := consumed[candidate]; ok {
			continue
		}
		outputBlobName = candidate
		break
	}
	return inputBlobName, outputBlobName
}

func nativeVisionInputBlobName(profile nativeVisionProfile) string {
	if value := strings.TrimSpace(profile.inputBlobName); value != "" {
		return value
	}
	return "in0"
}

func nativeVisionOutputBlobName(profile nativeVisionProfile) string {
	if value := strings.TrimSpace(profile.outputBlobName); value != "" {
		return value
	}
	return "out0"
}

func postprocessNativeVisionOutput(values []float64, profile nativeVisionProfile) []float64 {
	if !profile.normalizeOutput {
		return values
	}
	var norm float64
	for _, value := range values {
		norm += value * value
	}
	if norm <= 0 {
		return values
	}
	scale := 1.0 / math.Sqrt(norm)
	result := make([]float64, len(values))
	for i, value := range values {
		result[i] = value * scale
	}
	return result
}

func nativeVisionRGBPixels(img image.Image) []byte {
	return nativeImageRGBPixels(img, false)
}

func requestedNativeVisionDetectClass(parsed inferRequest) string {
	if className, _ := parsed.Input["class"].(string); strings.TrimSpace(className) != "" {
		return strings.ToLower(strings.TrimSpace(className))
	}
	task := strings.ToLower(strings.TrimSpace(parsed.Task))
	if strings.HasPrefix(task, "detect_") {
		return strings.TrimSpace(strings.TrimPrefix(task, "detect_"))
	}
	return ""
}

type nativeYOLOv8Detection struct {
	ClassID    int
	Label      string
	Confidence float64
	Left       float64
	Top        float64
	Right      float64
	Bottom     float64
	CX         float64
	CY         float64
	W          float64
	H          float64
}

func nativeYOLOv8OutputShape(profile nativeVisionProfile, total int) (int, int, error) {
	cols := 4 + profile.classCount
	if cols <= 4 {
		return 0, 0, fmt.Errorf("invalid YOLOv8 class count %d", profile.classCount)
	}
	if total <= 0 || total%cols != 0 {
		return 0, 0, fmt.Errorf("unexpected YOLOv8 output size total=%d cols=%d", total, cols)
	}
	return total / cols, cols, nil
}

// Materialize row-major values for callers that need them. Inference decodes
// through nativeYOLOv8OutputView to avoid allocating this transpose.
func nativeYOLOv8OutputRows(profile nativeVisionProfile, values []float32, dims, width, height, depth, channels int) ([]float32, int, int, error) {
	rows, cols, err := nativeYOLOv8OutputShape(profile, len(values))
	if err != nil {
		return nil, 0, 0, err
	}
	switch dims {
	case 2:
		switch {
		case width == cols && height > 0:
			return values, height, cols, nil
		case height == cols && width > 0:
			reordered := make([]float32, len(values))
			for row := 0; row < width; row++ {
				for col := 0; col < height; col++ {
					reordered[row*height+col] = values[col*width+row]
				}
			}
			return reordered, width, height, nil
		}
	case 3:
		switch {
		case channels == 1:
			return nativeYOLOv8OutputRows(profile, values, 2, width, height, 0, 0)
		case width == cols && height > 0 && channels > 0 && len(values) == width*height*channels:
			return values, height * channels, cols, nil
		case channels == cols && width > 0 && height > 0 && len(values) == width*height*channels:
			reordered := make([]float32, 0, len(values))
			for y := 0; y < height; y++ {
				for x := 0; x < width; x++ {
					for ch := 0; ch < channels; ch++ {
						index := ch*width*height + y*width + x
						reordered = append(reordered, values[index])
					}
				}
			}
			return reordered, width * height, channels, nil
		}
	case 4:
		if depth == 1 {
			return nativeYOLOv8OutputRows(profile, values, 3, width, height, 0, channels)
		}
	}
	return values, rows, cols, nil
}

func decodeNativeYOLOv8DetectOutput(values []float32, rows, cols int, input nativePreparedVisionInput) map[string]interface{} {
	return decodeNativeYOLOv8DetectOutputWithClass(values, rows, cols, input, "")
}

func decodeNativeYOLOv8DetectOutputWithClass(values []float32, rows, cols int, input nativePreparedVisionInput, requestedClass string) map[string]interface{} {
	return decodeNativeYOLOv8DetectOutputView(nativeYOLOv8OutputView{values: values, rows: rows, cols: cols}, input, requestedClass)
}

func decodeNativeYOLOv8DetectOutputView(view nativeYOLOv8OutputView, input nativePreparedVisionInput, requestedClass string) map[string]interface{} {
	values, rows, cols := view.values, view.rows, view.cols
	requestedClass = strings.ToLower(strings.TrimSpace(requestedClass))
	if rows <= 0 || cols <= 4 || len(values) < rows*cols {
		output := map[string]interface{}{
			"objects":    []string{},
			"detections": []map[string]interface{}{},
		}
		if input.profile.faceBundle {
			output["faces"] = []map[string]interface{}{}
		}
		return output
	}
	var candidates []nativeYOLOv8Detection
	for row := 0; row < rows; row++ {
		classID, score := view.bestClass(row)
		if classID < 0 || score < defaultYOLOv8DetectScoreThreshold {
			continue
		}
		label := nativeYOLOv8ClassLabel(input.profile, classID)
		if requestedClass != "" && label != requestedClass {
			continue
		}
		start, step := row*cols, 1
		if view.featureMajor {
			start, step = row, rows
		}
		detection := nativeYOLOv8ProjectDetection(nativeYOLOv8Detection{
			ClassID:    classID,
			Label:      label,
			Confidence: score,
			CX:         float64(values[start]),
			CY:         float64(values[start+step]),
			W:          float64(values[start+2*step]),
			H:          float64(values[start+3*step]),
		}, input)
		if detection.W <= 0 || detection.H <= 0 {
			continue
		}
		if candidates == nil {
			// Most positions are background. Reserve a small starter only after
			// the first accepted box; this does not limit the number of results.
			candidates = make([]nativeYOLOv8Detection, 0, min(rows, 64))
		}
		candidates = append(candidates, detection)
	}
	kept := nativeYOLOv8ApplyNMS(candidates, defaultYOLOv8DetectNMSThreshold)
	objects := make([]string, 0, len(kept))
	seenObjects := make(map[string]struct{}, len(kept))
	detections := make([]map[string]interface{}, 0, len(kept))
	for _, detection := range kept {
		if _, ok := seenObjects[detection.Label]; !ok && detection.Label != "" {
			seenObjects[detection.Label] = struct{}{}
			objects = append(objects, detection.Label)
		}
		detections = append(detections, map[string]interface{}{
			"class_id":   detection.ClassID,
			"label":      detection.Label,
			"confidence": detection.Confidence,
			"left":       detection.Left,
			"top":        detection.Top,
			"right":      detection.Right,
			"bottom":     detection.Bottom,
			"cx":         detection.CX,
			"cy":         detection.CY,
			"w":          detection.W,
			"h":          detection.H,
		})
	}
	output := map[string]interface{}{
		"objects":    objects,
		"detections": detections,
	}
	if input.profile.faceBundle {
		output["faces"] = nativeFaceOutputsFromDetections(detections, input)
	}
	return output
}

func nativeYOLOv8BestClass(scores []float32) (int, float64) {
	bestIndex := -1
	var bestScore float64
	for index, score := range scores {
		if index == 0 || float64(score) > bestScore {
			bestIndex = index
			bestScore = float64(score)
		}
	}
	return bestIndex, bestScore
}

func nativeYOLOv8ClassLabel(profile nativeVisionProfile, classID int) string {
	if classID >= 0 && classID < len(profile.classLabels) {
		return profile.classLabels[classID]
	}
	if classID >= 0 && classID < len(nativeYOLOv8COCOClassLabels) {
		return nativeYOLOv8COCOClassLabels[classID]
	}
	return fmt.Sprintf("class_%d", classID)
}

func nativeFaceOutputsFromDetections(detections []map[string]interface{}, input nativePreparedVisionInput) []map[string]interface{} {
	faces := make([]map[string]interface{}, 0, len(detections))
	sourceWidth := input.sourceWidth
	if sourceWidth <= 0 {
		sourceWidth = input.width
	}
	sourceHeight := input.sourceHeight
	if sourceHeight <= 0 {
		sourceHeight = input.height
	}
	sourceWidthFloat := float64(maxInt(1, sourceWidth))
	sourceHeightFloat := float64(maxInt(1, sourceHeight))
	for _, detection := range detections {
		left := float64FromInterface(detection["left"])
		top := float64FromInterface(detection["top"])
		right := float64FromInterface(detection["right"])
		bottom := float64FromInterface(detection["bottom"])
		if right <= left || bottom <= top {
			continue
		}
		confidence := float64FromInterface(detection["confidence"])
		pixelBBox := []float64{left, top, right, bottom}
		normalizedBBox := []float64{
			clampFloat64(left/sourceWidthFloat, 0, 1),
			clampFloat64(top/sourceHeightFloat, 0, 1),
			clampFloat64(right/sourceWidthFloat, 0, 1),
			clampFloat64(bottom/sourceHeightFloat, 0, 1),
		}
		face := map[string]interface{}{
			"bbox":          normalizedBBox,
			"pixel_bbox":    pixelBBox,
			"confidence":    confidence,
			"quality_score": confidence,
		}
		if pixelLandmarks, ok := detection["landmarks"].([][]float64); ok && len(pixelLandmarks) == 5 {
			copiedPixelLandmarks := make([][]float64, 0, len(pixelLandmarks))
			normalizedLandmarks := make([][]float64, 0, len(pixelLandmarks))
			for _, point := range pixelLandmarks {
				if len(point) < 2 {
					continue
				}
				copiedPixelLandmarks = append(copiedPixelLandmarks, []float64{point[0], point[1]})
				normalizedLandmarks = append(normalizedLandmarks, []float64{
					clampFloat64(point[0]/sourceWidthFloat, 0, 1),
					clampFloat64(point[1]/sourceHeightFloat, 0, 1),
				})
			}
			if len(copiedPixelLandmarks) == 5 {
				face["pixel_landmarks"] = copiedPixelLandmarks
				face["landmarks"] = normalizedLandmarks
			}
		}
		faces = append(faces, face)
	}
	return faces
}

func nativeSCRFDOutputBlobNames(profile nativeVisionProfile) []string {
	seen := make(map[string]struct{}, 9)
	result := make([]string, 0, 9)
	appendName := func(name string) {
		name = strings.TrimSpace(name)
		if name == "" {
			return
		}
		if _, ok := seen[name]; ok {
			return
		}
		seen[name] = struct{}{}
		result = append(result, name)
	}
	for _, name := range profile.scrfdScoreBlobs {
		appendName(name)
	}
	for _, name := range profile.scrfdBBoxBlobs {
		appendName(name)
	}
	for _, name := range profile.scrfdKPSBlobs {
		appendName(name)
	}
	if len(result) == 0 {
		return []string{"412", "415", "474", "477", "536", "539"}
	}
	return result
}

type nativeSCRFDDetection struct {
	Confidence float64
	Left       float64
	Top        float64
	Right      float64
	Bottom     float64
	Landmarks  [][]float64
}

func decodeNativeSCRFDFaceOutput(outputs map[string]nativeVisionOutputMat, input nativePreparedVisionInput) map[string]interface{} {
	candidates := nativeSCRFDDecodeDetections(outputs, input)
	kept := nativeSCRFDApplyNMS(candidates, defaultSCRFDFaceNMSThreshold)
	detections := make([]map[string]interface{}, 0, len(kept))
	for _, detection := range kept {
		width := maxFloat64(0, detection.Right-detection.Left)
		height := maxFloat64(0, detection.Bottom-detection.Top)
		if width <= 0 || height <= 0 {
			continue
		}
		decoded := map[string]interface{}{
			"class_id":   0,
			"label":      "face",
			"confidence": detection.Confidence,
			"left":       detection.Left,
			"top":        detection.Top,
			"right":      detection.Right,
			"bottom":     detection.Bottom,
			"cx":         detection.Left + width/2,
			"cy":         detection.Top + height/2,
			"w":          width,
			"h":          height,
		}
		if len(detection.Landmarks) == 5 {
			decoded["landmarks"] = detection.Landmarks
		}
		detections = append(detections, decoded)
	}
	result := map[string]interface{}{
		"objects":    []string{"face"},
		"detections": detections,
		"faces":      nativeFaceOutputsFromDetections(detections, input),
	}
	if nativeSCRFDDebugEnabled() {
		result["scrfd_debug"] = nativeSCRFDDebugSummary(outputs, input, candidates, detections)
	}
	return result
}

func nativeSCRFDDebugEnabled() bool {
	switch strings.ToLower(strings.TrimSpace(os.Getenv(envNativeSCRFDDebug))) {
	case "1", "true", "yes", "on", "debug":
		return true
	default:
		return false
	}
}

func nativeSCRFDDebugSummary(outputs map[string]nativeVisionOutputMat, input nativePreparedVisionInput, candidates []nativeSCRFDDetection, detections []map[string]interface{}) map[string]interface{} {
	scoreBlobs := input.profile.scrfdScoreBlobs
	if len(scoreBlobs) == 0 {
		scoreBlobs = []string{"412", "474", "536"}
	}
	bboxBlobs := input.profile.scrfdBBoxBlobs
	if len(bboxBlobs) == 0 {
		bboxBlobs = []string{"415", "477", "539"}
	}
	scoreSummaries := make([]map[string]interface{}, 0, len(scoreBlobs))
	for _, name := range scoreBlobs {
		scoreSummaries = append(scoreSummaries, nativeSCRFDScoreDebugSummary(name, outputs[name]))
	}
	bboxSummaries := make([]map[string]interface{}, 0, len(bboxBlobs))
	for _, name := range bboxBlobs {
		bboxSummaries = append(bboxSummaries, nativeSCRFDBlobDebugSummary(name, outputs[name]))
	}
	return map[string]interface{}{
		"input_width":           input.width,
		"input_height":          input.height,
		"source_width":          input.sourceWidth,
		"source_height":         input.sourceHeight,
		"scale":                 input.scale,
		"pad_x":                 input.padX,
		"pad_y":                 input.padY,
		"score_threshold":       defaultSCRFDFaceScoreThreshold,
		"nms_threshold":         defaultSCRFDFaceNMSThreshold,
		"candidates_before_nms": len(candidates),
		"detections_after_nms":  len(detections),
		"score_blobs":           scoreSummaries,
		"bbox_blobs":            bboxSummaries,
	}
}

func nativeSCRFDScoreDebugSummary(name string, mat nativeVisionOutputMat) map[string]interface{} {
	summary := nativeSCRFDBlobDebugSummary(name, mat)
	width, height, channels := nativeSCRFDMatShape(mat)
	if width <= 0 || height <= 0 || channels <= 0 || len(mat.values) == 0 {
		return summary
	}
	topScore := float32(math.Inf(-1))
	topX, topY, topChannel := 0, 0, 0
	for channel := 0; channel < channels; channel++ {
		for y := 0; y < height; y++ {
			for x := 0; x < width; x++ {
				value, ok := nativeSCRFDValue(mat, x, y, channel, width, height, channels)
				if !ok {
					continue
				}
				if value > topScore {
					topScore = value
					topX = x
					topY = y
					topChannel = channel
				}
			}
		}
	}
	if !math.IsInf(float64(topScore), -1) {
		summary["top_score"] = nativeSCRFDDebugFloat(topScore)
		summary["top_x"] = topX
		summary["top_y"] = topY
		summary["top_channel"] = topChannel
	}
	return summary
}

func nativeSCRFDBlobDebugSummary(name string, mat nativeVisionOutputMat) map[string]interface{} {
	summary := map[string]interface{}{
		"name":     strings.TrimSpace(name),
		"present":  len(mat.values) > 0,
		"dims":     mat.dims,
		"width":    mat.width,
		"height":   mat.height,
		"depth":    mat.depth,
		"channels": mat.channels,
		"total":    len(mat.values),
	}
	if len(mat.values) == 0 {
		return summary
	}
	minValue := mat.values[0]
	maxValue := mat.values[0]
	var sum float64
	for _, value := range mat.values {
		if value < minValue {
			minValue = value
		}
		if value > maxValue {
			maxValue = value
		}
		sum += float64(value)
	}
	summary["min"] = nativeSCRFDDebugFloat(minValue)
	summary["max"] = nativeSCRFDDebugFloat(maxValue)
	summary["mean"] = math.Round((sum/float64(len(mat.values)))*1e6) / 1e6
	return summary
}

func nativeSCRFDDebugFloat(value float32) float64 {
	return math.Round(float64(value)*1e6) / 1e6
}

func nativeSCRFDDecodeDetections(outputs map[string]nativeVisionOutputMat, input nativePreparedVisionInput) []nativeSCRFDDetection {
	scoreBlobs := input.profile.scrfdScoreBlobs
	if len(scoreBlobs) == 0 {
		scoreBlobs = []string{"412", "474", "536"}
	}
	bboxBlobs := input.profile.scrfdBBoxBlobs
	if len(bboxBlobs) == 0 {
		bboxBlobs = []string{"415", "477", "539"}
	}
	strides := input.profile.scrfdStrides
	if len(strides) == 0 {
		strides = []int{8, 16, 32}
	}

	candidates := make([]nativeSCRFDDetection, 0)
	levels := minInt(minInt(len(scoreBlobs), len(bboxBlobs)), len(strides))
	for level := 0; level < levels; level++ {
		stride := strides[level]
		scoreMat, scoreOK := outputs[scoreBlobs[level]]
		bboxMat, bboxOK := outputs[bboxBlobs[level]]
		if !scoreOK || !bboxOK || stride <= 0 {
			continue
		}
		scoreWidth, scoreHeight, scoreChannels := nativeSCRFDMatShape(scoreMat)
		if scoreWidth <= 0 || scoreHeight <= 0 {
			continue
		}
		anchorsPerLocation := maxInt(1, scoreChannels)
		bboxChannels := nativeSCRFDBBoxChannels(bboxMat, scoreWidth, scoreHeight)
		flatWidth, flatHeight, flatAnchors, flatLayout := nativeSCRFDFlatLevelShape(scoreMat, input, stride)
		if flatLayout {
			scoreWidth = flatWidth
			scoreHeight = flatHeight
			anchorsPerLocation = flatAnchors
			bboxChannels = anchorsPerLocation * 4
		} else if bboxChannels < anchorsPerLocation*4 {
			continue
		}
		kpsMat, hasKPS := nativeSCRFDKeypointMat(outputs, input.profile.scrfdKPSBlobs, level)
		for y := 0; y < scoreHeight; y++ {
			for x := 0; x < scoreWidth; x++ {
				for anchorIndex := 0; anchorIndex < anchorsPerLocation; anchorIndex++ {
					score, ok := nativeSCRFDLevelValue(scoreMat, x, y, anchorIndex, 0, 1, scoreWidth, scoreHeight, anchorsPerLocation, flatLayout)
					if !ok || score < defaultSCRFDFaceScoreThreshold {
						continue
					}
					d0, ok0 := nativeSCRFDLevelValue(bboxMat, x, y, anchorIndex, 0, 4, scoreWidth, scoreHeight, anchorsPerLocation, flatLayout)
					d1, ok1 := nativeSCRFDLevelValue(bboxMat, x, y, anchorIndex, 1, 4, scoreWidth, scoreHeight, anchorsPerLocation, flatLayout)
					d2, ok2 := nativeSCRFDLevelValue(bboxMat, x, y, anchorIndex, 2, 4, scoreWidth, scoreHeight, anchorsPerLocation, flatLayout)
					d3, ok3 := nativeSCRFDLevelValue(bboxMat, x, y, anchorIndex, 3, 4, scoreWidth, scoreHeight, anchorsPerLocation, flatLayout)
					if !ok0 || !ok1 || !ok2 || !ok3 {
						continue
					}
					centerX := float64(x * stride)
					centerY := float64(y * stride)
					detection := nativeSCRFDDetection{
						Confidence: float64(score),
						Left:       centerX - float64(d0)*float64(stride),
						Top:        centerY - float64(d1)*float64(stride),
						Right:      centerX + float64(d2)*float64(stride),
						Bottom:     centerY + float64(d3)*float64(stride),
					}
					if hasKPS {
						landmarks := make([][]float64, 0, 5)
						for pointIndex := 0; pointIndex < 5; pointIndex++ {
							dx, okX := nativeSCRFDLevelValue(kpsMat, x, y, anchorIndex, pointIndex*2, 10, scoreWidth, scoreHeight, anchorsPerLocation, flatLayout)
							dy, okY := nativeSCRFDLevelValue(kpsMat, x, y, anchorIndex, pointIndex*2+1, 10, scoreWidth, scoreHeight, anchorsPerLocation, flatLayout)
							if !okX || !okY {
								landmarks = nil
								break
							}
							landmarks = append(landmarks, []float64{
								centerX + float64(dx)*float64(stride),
								centerY + float64(dy)*float64(stride),
							})
						}
						detection.Landmarks = landmarks
					}
					detection = nativeSCRFDProjectDetection(detection, input)
					if detection.Right > detection.Left && detection.Bottom > detection.Top {
						candidates = append(candidates, detection)
					}
				}
			}
		}
	}
	return candidates
}

func nativeSCRFDKeypointMat(outputs map[string]nativeVisionOutputMat, blobs []string, level int) (nativeVisionOutputMat, bool) {
	if level < 0 || level >= len(blobs) {
		return nativeVisionOutputMat{}, false
	}
	mat, ok := outputs[blobs[level]]
	return mat, ok && len(mat.values) > 0
}

func nativeSCRFDFlatLevelShape(scoreMat nativeVisionOutputMat, input nativePreparedVisionInput, stride int) (int, int, int, bool) {
	if scoreMat.dims != 2 || stride <= 0 || input.width <= 0 || input.height <= 0 {
		return 0, 0, 0, false
	}
	width := input.width / stride
	height := input.height / stride
	locations := width * height
	if width <= 0 || height <= 0 || locations <= 0 || len(scoreMat.values)%locations != 0 {
		return 0, 0, 0, false
	}
	anchors := len(scoreMat.values) / locations
	if anchors <= 0 {
		return 0, 0, 0, false
	}
	return width, height, anchors, true
}

func nativeSCRFDLevelValue(mat nativeVisionOutputMat, x int, y int, anchor int, feature int, featuresPerAnchor int, width int, height int, anchors int, flat bool) (float32, bool) {
	if !flat {
		return nativeSCRFDValue(mat, x, y, anchor*featuresPerAnchor+feature, width, height, anchors*featuresPerAnchor)
	}
	if x < 0 || y < 0 || anchor < 0 || feature < 0 || x >= width || y >= height || anchor >= anchors || feature >= featuresPerAnchor {
		return 0, false
	}
	row := (y*width+x)*anchors + anchor
	index := row*featuresPerAnchor + feature
	if index < 0 || index >= len(mat.values) {
		return 0, false
	}
	return mat.values[index], true
}

func nativeSCRFDMatShape(mat nativeVisionOutputMat) (int, int, int) {
	switch mat.dims {
	case 1:
		return maxInt(1, mat.width), 1, 1
	case 2:
		return maxInt(1, mat.width), maxInt(1, mat.height), 1
	case 3, 4:
		return maxInt(1, mat.width), maxInt(1, mat.height), maxInt(1, mat.channels)
	default:
		if mat.width > 0 && mat.height > 0 {
			return mat.width, mat.height, maxInt(1, mat.channels)
		}
	}
	return 0, 0, 0
}

func nativeSCRFDBBoxChannels(mat nativeVisionOutputMat, width int, height int) int {
	if mat.channels > 0 {
		return mat.channels
	}
	area := width * height
	if area <= 0 || len(mat.values)%area != 0 {
		return 0
	}
	return len(mat.values) / area
}

func nativeSCRFDValue(mat nativeVisionOutputMat, x int, y int, channel int, width int, height int, channels int) (float32, bool) {
	if width <= 0 || height <= 0 || channels <= 0 || x < 0 || y < 0 || channel < 0 || x >= width || y >= height || channel >= channels {
		return 0, false
	}
	index := channel*width*height + y*width + x
	if index < 0 || index >= len(mat.values) {
		return 0, false
	}
	return mat.values[index], true
}

func nativeSCRFDProjectDetection(detection nativeSCRFDDetection, input nativePreparedVisionInput) nativeSCRFDDetection {
	if input.scale <= 0 {
		return detection
	}
	left := (detection.Left - float64(input.padX)) / input.scale
	top := (detection.Top - float64(input.padY)) / input.scale
	right := (detection.Right - float64(input.padX)) / input.scale
	bottom := (detection.Bottom - float64(input.padY)) / input.scale
	maxWidth := float64(maxInt(1, input.sourceWidth))
	maxHeight := float64(maxInt(1, input.sourceHeight))
	left = clampFloat64(left, 0, maxWidth)
	top = clampFloat64(top, 0, maxHeight)
	right = clampFloat64(right, left, maxWidth)
	bottom = clampFloat64(bottom, top, maxHeight)
	detection.Left = left
	detection.Top = top
	detection.Right = right
	detection.Bottom = bottom
	for _, point := range detection.Landmarks {
		if len(point) < 2 {
			continue
		}
		point[0] = clampFloat64((point[0]-float64(input.padX))/input.scale, 0, maxWidth)
		point[1] = clampFloat64((point[1]-float64(input.padY))/input.scale, 0, maxHeight)
	}
	return detection
}

func nativeSCRFDApplyNMS(detections []nativeSCRFDDetection, threshold float64) []nativeSCRFDDetection {
	if len(detections) <= 1 {
		return detections
	}
	sorted := append([]nativeSCRFDDetection(nil), detections...)
	sort.SliceStable(sorted, func(i, j int) bool {
		return sorted[i].Confidence > sorted[j].Confidence
	})
	kept := make([]nativeSCRFDDetection, 0, len(sorted))
	for _, candidate := range sorted {
		suppressed := false
		for _, existing := range kept {
			if nativeSCRFDIoU(candidate, existing) > threshold {
				suppressed = true
				break
			}
		}
		if !suppressed {
			kept = append(kept, candidate)
		}
	}
	return kept
}

func nativeSCRFDIoU(a, b nativeSCRFDDetection) float64 {
	interLeft := maxFloat64(a.Left, b.Left)
	interTop := maxFloat64(a.Top, b.Top)
	interRight := minFloat64(a.Right, b.Right)
	interBottom := minFloat64(a.Bottom, b.Bottom)
	interWidth := maxFloat64(0, interRight-interLeft)
	interHeight := maxFloat64(0, interBottom-interTop)
	interArea := interWidth * interHeight
	if interArea <= 0 {
		return 0
	}
	areaA := maxFloat64(0, a.Right-a.Left) * maxFloat64(0, a.Bottom-a.Top)
	areaB := maxFloat64(0, b.Right-b.Left) * maxFloat64(0, b.Bottom-b.Top)
	union := areaA + areaB - interArea
	if union <= 0 {
		return 0
	}
	return interArea / union
}

func float64FromInterface(value interface{}) float64 {
	switch typed := value.(type) {
	case float64:
		return typed
	case float32:
		return float64(typed)
	case int:
		return float64(typed)
	case int64:
		return float64(typed)
	default:
		return 0
	}
}

func (r *nativeEmbeddingRuntime) inferFaceEmbedding(model *nativeEmbeddingModel, input nativePreparedVisionInput, face map[string]interface{}, threadLimit int) ([]float64, error) {
	if r == nil || r.base == nil || model == nil || model.faceEmbeddingNet == 0 {
		return nil, fmt.Errorf("native face embedding model is not loaded")
	}
	if input.sourceImage == nil {
		return nil, fmt.Errorf("native face embedding source image is unavailable")
	}
	pixels, width, height, err := nativeFaceEmbeddingPixelsForFace(input.sourceImage, input.profile, face)
	if err != nil {
		return nil, err
	}
	embeddingInput := nativePreparedVisionInput{
		profile: nativeVisionProfile{
			meanValues:      input.profile.faceEmbeddingMean,
			normValues:      input.profile.faceEmbeddingNorm,
			normalizeOutput: true,
		},
		width:  width,
		height: height,
		pixels: pixels,
	}
	return r.inferVisionNet(model, model.faceEmbeddingNet, embeddingInput, threadLimit)
}

func nativeFaceMapsFromInput(value interface{}) ([]map[string]interface{}, error) {
	if value == nil {
		return nil, fmt.Errorf("native face embedding faces are required")
	}
	switch typed := value.(type) {
	case []map[string]interface{}:
		return append([]map[string]interface{}(nil), typed...), nil
	case []interface{}:
		faces := make([]map[string]interface{}, 0, len(typed))
		for index, item := range typed {
			face, ok := item.(map[string]interface{})
			if !ok {
				return nil, fmt.Errorf("native face embedding face %d is invalid", index)
			}
			faces = append(faces, face)
		}
		return faces, nil
	default:
		return nil, fmt.Errorf("native face embedding faces are invalid")
	}
}

func nativeFaceEmbeddingPixelsForFace(source image.Image, profile nativeVisionProfile, face map[string]interface{}) ([]byte, int, int, error) {
	if landmarks, ok := nativeFaceEmbeddingLandmarks(source, face); ok {
		width := maxInt(1, profile.faceEmbeddingWidth)
		height := maxInt(1, profile.faceEmbeddingHeight)
		aligned, err := nativeFaceFivePointAlignedImage(source, landmarks, width, height)
		if err == nil {
			return nativeVisionRGBPixels(aligned), width, height, nil
		}
	}
	bbox, ok := nativeFaceEmbeddingBBox(source, face)
	if !ok || len(bbox) < 4 {
		return nil, 0, 0, fmt.Errorf("native face embedding bbox is unavailable")
	}
	return nativeFaceEmbeddingPixels(source, profile, bbox)
}

func nativeFaceEmbeddingLandmarks(source image.Image, face map[string]interface{}) ([][]float64, bool) {
	if source == nil {
		return nil, false
	}
	if landmarks, ok := nativeFaceLandmarkSlice(face["pixel_landmarks"]); ok {
		return landmarks, true
	}
	landmarks, ok := nativeFaceLandmarkSlice(face["landmarks"])
	if !ok {
		return nil, false
	}
	bounds := source.Bounds()
	width := float64(maxInt(1, bounds.Dx()))
	height := float64(maxInt(1, bounds.Dy()))
	for _, point := range landmarks {
		if point[0] < 0 || point[0] > 1 || point[1] < 0 || point[1] > 1 {
			return nil, false
		}
		point[0] = float64(bounds.Min.X) + point[0]*width
		point[1] = float64(bounds.Min.Y) + point[1]*height
	}
	return landmarks, true
}

func nativeFaceLandmarkSlice(value interface{}) ([][]float64, bool) {
	var rawPoints []interface{}
	switch typed := value.(type) {
	case [][]float64:
		rawPoints = make([]interface{}, 0, len(typed))
		for _, point := range typed {
			rawPoints = append(rawPoints, point)
		}
	case []interface{}:
		rawPoints = typed
	default:
		return nil, false
	}
	if len(rawPoints) != 5 {
		return nil, false
	}
	result := make([][]float64, 0, len(rawPoints))
	for _, rawPoint := range rawPoints {
		point, ok := nativeFaceCoordinateSlice(rawPoint)
		if !ok || len(point) < 2 || math.IsNaN(point[0]) || math.IsInf(point[0], 0) || math.IsNaN(point[1]) || math.IsInf(point[1], 0) {
			return nil, false
		}
		result = append(result, []float64{point[0], point[1]})
	}
	return result, true
}

func nativeFaceCoordinateSlice(value interface{}) ([]float64, bool) {
	switch typed := value.(type) {
	case []float64:
		return append([]float64(nil), typed...), true
	case []float32:
		result := make([]float64, len(typed))
		for index, coordinate := range typed {
			result[index] = float64(coordinate)
		}
		return result, true
	case []interface{}:
		result := make([]float64, len(typed))
		for index, coordinate := range typed {
			value, ok := nativeFaceCoordinateValue(coordinate)
			if !ok {
				return nil, false
			}
			result[index] = value
		}
		return result, true
	default:
		return nil, false
	}
}

func nativeFaceCoordinateValue(value interface{}) (float64, bool) {
	switch typed := value.(type) {
	case float64:
		return typed, true
	case float32:
		return float64(typed), true
	case int:
		return float64(typed), true
	case int32:
		return float64(typed), true
	case int64:
		return float64(typed), true
	default:
		return 0, false
	}
}

var nativeAdaFace112Template = [][]float64{
	{38.2946, 51.6963},
	{73.5318, 51.5014},
	{56.0252, 71.7366},
	{41.5493, 92.3655},
	{70.7299, 92.2041},
}

type nativeFaceSimilarityTransform struct {
	a  float64
	b  float64
	tx float64
	ty float64
}

func nativeFaceFivePointAlignedImage(source image.Image, landmarks [][]float64, width int, height int) (*image.NRGBA, error) {
	if source == nil || width <= 0 || height <= 0 || len(landmarks) != len(nativeAdaFace112Template) {
		return nil, fmt.Errorf("native face landmarks are invalid")
	}
	destination := make([][]float64, 0, len(nativeAdaFace112Template))
	scaleX := float64(width) / 112.0
	scaleY := float64(height) / 112.0
	for _, point := range nativeAdaFace112Template {
		destination = append(destination, []float64{point[0] * scaleX, point[1] * scaleY})
	}
	transform, ok := nativeFaceEstimateSimilarity(landmarks, destination)
	if !ok {
		return nil, fmt.Errorf("native face landmarks are degenerate")
	}
	result := image.NewNRGBA(image.Rect(0, 0, width, height))
	for y := 0; y < height; y++ {
		for x := 0; x < width; x++ {
			sourceX, sourceY, ok := transform.inverse(float64(x), float64(y))
			if !ok {
				return nil, fmt.Errorf("native face alignment transform is singular")
			}
			result.SetNRGBA(x, y, nativeFaceBilinearSample(source, sourceX, sourceY))
		}
	}
	return result, nil
}

func nativeFaceEstimateSimilarity(source [][]float64, destination [][]float64) (nativeFaceSimilarityTransform, bool) {
	if len(source) != len(destination) || len(source) < 2 {
		return nativeFaceSimilarityTransform{}, false
	}
	var sourceCenterX, sourceCenterY, destinationCenterX, destinationCenterY float64
	for index := range source {
		if len(source[index]) < 2 || len(destination[index]) < 2 {
			return nativeFaceSimilarityTransform{}, false
		}
		sourceCenterX += source[index][0]
		sourceCenterY += source[index][1]
		destinationCenterX += destination[index][0]
		destinationCenterY += destination[index][1]
	}
	count := float64(len(source))
	sourceCenterX /= count
	sourceCenterY /= count
	destinationCenterX /= count
	destinationCenterY /= count
	var denominator, realNumerator, imaginaryNumerator float64
	for index := range source {
		sx := source[index][0] - sourceCenterX
		sy := source[index][1] - sourceCenterY
		dx := destination[index][0] - destinationCenterX
		dy := destination[index][1] - destinationCenterY
		denominator += sx*sx + sy*sy
		realNumerator += sx*dx + sy*dy
		imaginaryNumerator += sx*dy - sy*dx
	}
	if denominator <= 1e-12 {
		return nativeFaceSimilarityTransform{}, false
	}
	a := realNumerator / denominator
	b := imaginaryNumerator / denominator
	if determinant := a*a + b*b; determinant <= 1e-12 || math.IsNaN(determinant) || math.IsInf(determinant, 0) {
		return nativeFaceSimilarityTransform{}, false
	}
	return nativeFaceSimilarityTransform{
		a:  a,
		b:  b,
		tx: destinationCenterX - a*sourceCenterX + b*sourceCenterY,
		ty: destinationCenterY - b*sourceCenterX - a*sourceCenterY,
	}, true
}

func (transform nativeFaceSimilarityTransform) inverse(x float64, y float64) (float64, float64, bool) {
	determinant := transform.a*transform.a + transform.b*transform.b
	if determinant <= 1e-12 {
		return 0, 0, false
	}
	dx := x - transform.tx
	dy := y - transform.ty
	return (transform.a*dx + transform.b*dy) / determinant,
		(-transform.b*dx + transform.a*dy) / determinant,
		true
}

func nativeFaceBilinearSample(source image.Image, x float64, y float64) color.NRGBA {
	bounds := source.Bounds()
	if x < float64(bounds.Min.X) || y < float64(bounds.Min.Y) || x > float64(bounds.Max.X-1) || y > float64(bounds.Max.Y-1) {
		return color.NRGBA{A: 255}
	}
	x0 := int(math.Floor(x))
	y0 := int(math.Floor(y))
	x1 := minInt(x0+1, bounds.Max.X-1)
	y1 := minInt(y0+1, bounds.Max.Y-1)
	weightX := x - float64(x0)
	weightY := y - float64(y0)
	c00 := nativeImageNRGBAAt(source, x0, y0)
	c10 := nativeImageNRGBAAt(source, x1, y0)
	c01 := nativeImageNRGBAAt(source, x0, y1)
	c11 := nativeImageNRGBAAt(source, x1, y1)
	interpolate := func(v00 uint8, v10 uint8, v01 uint8, v11 uint8) uint8 {
		top := float64(v00)*(1-weightX) + float64(v10)*weightX
		bottom := float64(v01)*(1-weightX) + float64(v11)*weightX
		return uint8(math.Round(top*(1-weightY) + bottom*weightY))
	}
	return color.NRGBA{
		R: interpolate(c00.R, c10.R, c01.R, c11.R),
		G: interpolate(c00.G, c10.G, c01.G, c11.G),
		B: interpolate(c00.B, c10.B, c01.B, c11.B),
		A: 255,
	}
}

func nativeFaceEmbeddingBBox(source image.Image, face map[string]interface{}) ([]float64, bool) {
	if source == nil {
		return nil, false
	}
	if bbox, ok := nativeFaceCoordinateSlice(face["pixel_bbox"]); ok && len(bbox) >= 4 {
		return append([]float64(nil), bbox[:4]...), true
	}
	bbox, ok := nativeFaceCoordinateSlice(face["bbox"])
	if !ok || len(bbox) < 4 {
		return nil, false
	}
	result := append([]float64(nil), bbox[:4]...)
	if !nativeFaceBBoxLooksNormalized(result) {
		return result, true
	}
	bounds := source.Bounds()
	width := float64(maxInt(1, bounds.Dx()))
	height := float64(maxInt(1, bounds.Dy()))
	return []float64{
		float64(bounds.Min.X) + result[0]*width,
		float64(bounds.Min.Y) + result[1]*height,
		float64(bounds.Min.X) + result[2]*width,
		float64(bounds.Min.Y) + result[3]*height,
	}, true
}

func nativeFaceBBoxLooksNormalized(bbox []float64) bool {
	if len(bbox) < 4 {
		return false
	}
	for _, value := range bbox[:4] {
		if value < 0 || value > 1 {
			return false
		}
	}
	return true
}

func nativeFaceEmbeddingPixels(source image.Image, profile nativeVisionProfile, bbox []float64) ([]byte, int, int, error) {
	bounds := source.Bounds()
	left := clampFloat64(math.Floor(bbox[0]), float64(bounds.Min.X), float64(bounds.Max.X-1))
	top := clampFloat64(math.Floor(bbox[1]), float64(bounds.Min.Y), float64(bounds.Max.Y-1))
	right := clampFloat64(math.Ceil(bbox[2]), left+1, float64(bounds.Max.X))
	bottom := clampFloat64(math.Ceil(bbox[3]), top+1, float64(bounds.Max.Y))
	rect := image.Rect(int(left), int(top), int(right), int(bottom))
	width := maxInt(1, profile.faceEmbeddingWidth)
	height := maxInt(1, profile.faceEmbeddingHeight)
	crop := imaging.Crop(source, rect)
	prepared := imaging.Fill(crop, width, height, imaging.Center, imaging.Linear)
	return nativeVisionRGBPixels(prepared), width, height, nil
}

func nativeYOLOv8ProjectDetection(detection nativeYOLOv8Detection, input nativePreparedVisionInput) nativeYOLOv8Detection {
	if input.scale <= 0 {
		left := detection.CX - (detection.W / 2)
		top := detection.CY - (detection.H / 2)
		detection.Left = left
		detection.Top = top
		detection.Right = left + detection.W
		detection.Bottom = top + detection.H
		return detection
	}
	left := (detection.CX - (detection.W / 2) - float64(input.padX)) / input.scale
	top := (detection.CY - (detection.H / 2) - float64(input.padY)) / input.scale
	right := (detection.CX + (detection.W / 2) - float64(input.padX)) / input.scale
	bottom := (detection.CY + (detection.H / 2) - float64(input.padY)) / input.scale
	maxWidth := float64(maxInt(1, input.sourceWidth))
	maxHeight := float64(maxInt(1, input.sourceHeight))
	left = clampFloat64(left, 0, maxWidth)
	top = clampFloat64(top, 0, maxHeight)
	right = clampFloat64(right, left, maxWidth)
	bottom = clampFloat64(bottom, top, maxHeight)
	detection.Left = left
	detection.Top = top
	detection.Right = right
	detection.Bottom = bottom
	detection.W = maxFloat64(0, right-left)
	detection.H = maxFloat64(0, bottom-top)
	detection.CX = left + (detection.W / 2)
	detection.CY = top + (detection.H / 2)
	return detection
}

func nativeYOLOv8ApplyNMS(detections []nativeYOLOv8Detection, threshold float64) []nativeYOLOv8Detection {
	if len(detections) <= 1 {
		return detections
	}
	sorted := append([]nativeYOLOv8Detection(nil), detections...)
	sort.SliceStable(sorted, func(i, j int) bool {
		if sorted[i].Confidence == sorted[j].Confidence {
			return sorted[i].ClassID < sorted[j].ClassID
		}
		return sorted[i].Confidence > sorted[j].Confidence
	})
	kept := make([]nativeYOLOv8Detection, 0, len(sorted))
	for _, candidate := range sorted {
		suppressed := false
		for _, existing := range kept {
			if candidate.ClassID != existing.ClassID {
				continue
			}
			if nativeYOLOv8IoU(candidate, existing) > threshold {
				suppressed = true
				break
			}
		}
		if !suppressed {
			kept = append(kept, candidate)
		}
	}
	return kept
}

func nativeYOLOv8IoU(a, b nativeYOLOv8Detection) float64 {
	interLeft := maxFloat64(a.Left, b.Left)
	interTop := maxFloat64(a.Top, b.Top)
	interRight := minFloat64(a.Right, b.Right)
	interBottom := minFloat64(a.Bottom, b.Bottom)
	interWidth := maxFloat64(0, interRight-interLeft)
	interHeight := maxFloat64(0, interBottom-interTop)
	interArea := interWidth * interHeight
	if interArea <= 0 {
		return 0
	}
	areaA := maxFloat64(0, a.Right-a.Left) * maxFloat64(0, a.Bottom-a.Top)
	areaB := maxFloat64(0, b.Right-b.Left) * maxFloat64(0, b.Bottom-b.Top)
	union := areaA + areaB - interArea
	if union <= 0 {
		return 0
	}
	return interArea / union
}

func clampFloat64(value, minValue, maxValue float64) float64 {
	if value < minValue {
		return minValue
	}
	if value > maxValue {
		return maxValue
	}
	return value
}

func minFloat64(a, b float64) float64 {
	if a < b {
		return a
	}
	return b
}

func maxFloat64(a, b float64) float64 {
	if a > b {
		return a
	}
	return b
}

func maxInt(a, b int) int {
	if a > b {
		return a
	}
	return b
}

func minInt(a, b int) int {
	if a < b {
		return a
	}
	return b
}

var nativeYOLOv8COCOClassLabels = []string{
	"person", "bicycle", "car", "motorcycle", "airplane", "bus", "train", "truck", "boat", "traffic light",
	"fire hydrant", "stop sign", "parking meter", "bench", "bird", "cat", "dog", "horse", "sheep", "cow",
	"elephant", "bear", "zebra", "giraffe", "backpack", "umbrella", "handbag", "tie", "suitcase", "frisbee",
	"skis", "snowboard", "sports ball", "kite", "baseball bat", "baseball glove", "skateboard", "surfboard", "tennis racket", "bottle",
	"wine glass", "cup", "fork", "knife", "spoon", "bowl", "banana", "apple", "sandwich", "orange",
	"broccoli", "carrot", "hot dog", "pizza", "donut", "cake", "chair", "couch", "potted plant", "bed",
	"dining table", "toilet", "tv", "laptop", "mouse", "remote", "keyboard", "cell phone", "microwave", "oven",
	"toaster", "sink", "refrigerator", "book", "clock", "vase", "scissors", "teddy bear", "hair drier", "toothbrush",
}
