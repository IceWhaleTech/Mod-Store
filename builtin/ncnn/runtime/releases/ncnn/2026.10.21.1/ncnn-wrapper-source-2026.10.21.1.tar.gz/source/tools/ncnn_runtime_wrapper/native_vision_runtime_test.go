package main

import (
	"encoding/json"
	"image"
	"image/color"
	"image/png"
	"math"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
	"time"
	"unsafe"
)

const testNativeVisionProfileEmbedding = nativeVisionProfileKind("test_embedding")

func TestWrapperStatusDeclaresRuntimeCompatibility(t *testing.T) {
	state := &wrapperRuntimeState{
		backendRequested: []string{"cpu"},
		loadedBundles:    make(map[string]string),
		loadedBundleIDs:  make(map[string]string),
	}
	status := state.status(embeddingHelperSpec{}, false, nativeEmbeddingSpec{backend: &nativeEmbeddingRuntime{}}, true)
	raw, err := json.Marshal(status)
	if err != nil {
		t.Fatalf("json.Marshal(status) error = %v", err)
	}
	var payload map[string]interface{}
	if err := json.Unmarshal(raw, &payload); err != nil {
		t.Fatalf("json.Unmarshal(status) error = %v", err)
	}
	if got := payload["runtime_version"]; got != "2026.09.04.1" {
		t.Fatalf("runtime_version = %#v, want 2026.09.04.1", got)
	}
	if got := payload["artifact_abi"]; got != "v7" {
		t.Fatalf("artifact_abi = %#v, want v7", got)
	}
	if got := payload["json_abi"]; got != "json-v2" {
		t.Fatalf("json_abi = %#v, want json-v2", got)
	}
	tasks, ok := payload["supported_tasks"].([]interface{})
	if !ok {
		t.Fatalf("supported_tasks = %#v, want array", payload["supported_tasks"])
	}
	for _, required := range []string{"face", "face_detect", "face_embed"} {
		found := false
		for _, task := range tasks {
			if task == required {
				found = true
				break
			}
		}
		if !found {
			t.Fatalf("supported_tasks = %#v, missing %q", tasks, required)
		}
	}
	for _, task := range tasks {
		if task == "image_embedding" {
			t.Fatalf("supported_tasks still exposes retired image embedding: %#v", tasks)
		}
	}
}

func TestDetectNativeVisionProfileRejectsRetiredImageEmbeddingBundle(t *testing.T) {
	bundleDir := writeNativeVisionBundleForTest(t)

	_, ok, err := detectNativeVisionProfile(bundleDir)
	if err != nil {
		t.Fatalf("detectNativeVisionProfile() error = %v", err)
	}
	if ok {
		t.Fatal("retired image embedding bundle is still recognized")
	}
}

func TestDetectNativeVisionProfileRecognizesDetectGeneralBundle(t *testing.T) {
	bundleDir := t.TempDir()
	writeNativeRuntimeJSONFileForTest(t, filepath.Join(bundleDir, "metadata.json"), map[string]interface{}{
		"bundle_id":   "detect-general-int8",
		"model_class": modelClassVision,
		"provider":    "ultralytics",
		"model":       "yolov8n",
		"task":        "detect",
		"input_size":  []interface{}{640, 640},
		"input_color": "rgb",
		"normalization": map[string]interface{}{
			"mean": []interface{}{0.0, 0.0, 0.0},
			"norm": []interface{}{1.0 / 255.0, 1.0 / 255.0, 1.0 / 255.0},
		},
		"classes": 80,
	})

	profile, ok, err := detectNativeVisionProfile(bundleDir)
	if err != nil {
		t.Fatalf("detectNativeVisionProfile() error = %v", err)
	}
	if !ok {
		t.Fatal("detectNativeVisionProfile() ok = false, want true for detect-general bundle")
	}
	if profile.kind != nativeVisionProfileYOLOv8Detect {
		t.Fatalf("profile.kind = %q, want %q", profile.kind, nativeVisionProfileYOLOv8Detect)
	}
	if profile.targetWidth != 640 || profile.targetHeight != 640 {
		t.Fatalf("unexpected target size: %+v", profile)
	}
	if profile.classCount != 80 {
		t.Fatalf("classCount = %d, want 80", profile.classCount)
	}
}

func TestParseNativeVisionParamBlobNamesFindsInputAndFinalOutput(t *testing.T) {
	bundleDir := t.TempDir()
	param := "7767517\n4 4\nInput input_layer_3 0 1 input_layer_3\nConvolution conv 1 1 input_layer_3 conv:0\nSoftmax softmax 1 1 conv:0 final_softmax:0 0=1 1=1\nBinaryOp scale 1 1 final_softmax:0 scaled_output 0=2 1=1 2=3.921569e-03\n"
	if err := os.WriteFile(filepath.Join(bundleDir, "model.param"), []byte(param), 0o644); err != nil {
		t.Fatalf("WriteFile(model.param) error = %v", err)
	}

	inputBlob, outputBlob := parseNativeVisionParamBlobNames(bundleDir)
	if inputBlob != "input_layer_3" {
		t.Fatalf("input blob = %q, want input_layer_3", inputBlob)
	}
	if outputBlob != "scaled_output" {
		t.Fatalf("output blob = %q, want scaled_output", outputBlob)
	}
}

func TestDetectNativeVisionProfileRecognizesFaceBundle(t *testing.T) {
	bundleDir := t.TempDir()
	writeNativeRuntimeJSONFileForTest(t, filepath.Join(bundleDir, "metadata.json"), map[string]interface{}{
		"bundle_id":   "zima-face-ncnn-int8",
		"model_class": modelClassVision,
		"pipeline": map[string]interface{}{
			"detector": map[string]interface{}{
				"model":      "face_yolov8n_v2",
				"task":       "face_detect",
				"input_size": []interface{}{640, 640},
				"normalization": map[string]interface{}{
					"mean": []interface{}{0.0, 0.0, 0.0},
					"norm": []interface{}{1.0 / 255.0, 1.0 / 255.0, 1.0 / 255.0},
				},
			},
			"embedding": map[string]interface{}{
				"task":             "face_embedding",
				"input_size":       []interface{}{112, 112},
				"output_dimension": 512,
				"normalization": map[string]interface{}{
					"mean": []interface{}{127.5, 127.5, 127.5},
					"norm": []interface{}{1.0 / 127.5, 1.0 / 127.5, 1.0 / 127.5},
				},
			},
		},
	})

	profile, ok, err := detectNativeVisionProfile(bundleDir)
	if err != nil {
		t.Fatalf("detectNativeVisionProfile() error = %v", err)
	}
	if !ok {
		t.Fatal("detectNativeVisionProfile() ok = false, want true for face bundle")
	}
	if profile.kind != nativeVisionProfileYOLOv8Detect {
		t.Fatalf("profile.kind = %q, want %q", profile.kind, nativeVisionProfileYOLOv8Detect)
	}
	if !profile.faceBundle {
		t.Fatal("profile.faceBundle = false, want true")
	}
	if profile.classCount != 1 || len(profile.classLabels) != 1 || profile.classLabels[0] != "face" {
		t.Fatalf("unexpected face labels/count: %+v", profile)
	}
	if profile.targetWidth != 640 || profile.targetHeight != 640 {
		t.Fatalf("unexpected detector target size: %+v", profile)
	}
	if profile.faceEmbeddingWidth != 112 || profile.faceEmbeddingHeight != 112 || profile.faceEmbeddingDim != 512 {
		t.Fatalf("unexpected embedding profile: %+v", profile)
	}
}

func TestDetectNativeVisionProfileUsesSCRFDDetectorSubdirWhenPresent(t *testing.T) {
	bundleDir := t.TempDir()
	writeNativeRuntimeJSONFileForTest(t, filepath.Join(bundleDir, "metadata.json"), map[string]interface{}{
		"bundle_id":   "zima-face-ncnn-int8",
		"model_class": modelClassVision,
		"pipeline": map[string]interface{}{
			"detector": map[string]interface{}{
				"model":      "face_yolov8n_v2",
				"task":       "face_detect",
				"input_size": []interface{}{640, 640},
				"normalization": map[string]interface{}{
					"mean": []interface{}{0.0, 0.0, 0.0},
					"norm": []interface{}{1.0 / 255.0, 1.0 / 255.0, 1.0 / 255.0},
				},
			},
			"embedding": map[string]interface{}{
				"task":             "face_embedding",
				"input_size":       []interface{}{112, 112},
				"output_dimension": 512,
			},
		},
	})
	detectorDir := filepath.Join(bundleDir, "detector", "scrfd-500m-kps")
	if err := os.MkdirAll(detectorDir, 0o755); err != nil {
		t.Fatalf("MkdirAll(detector) error = %v", err)
	}
	param := "7767517\n103 112\nInput input.1 0 1 input.1\nSigmoid Sigmoid_160 1 1 411 412\nBinaryOp Mul_156 1 1 407 415 0=2 1=1 2=7.957783e-01\nSigmoid Sigmoid_214 1 1 473 474\nBinaryOp Mul_210 1 1 469 477 0=2 1=1 2=1.201926e+00\nSigmoid Sigmoid_268 1 1 535 536\nBinaryOp Mul_264 1 1 531 539 0=2 1=1 2=1.992024e+00\n"
	if err := os.WriteFile(filepath.Join(detectorDir, "model.param"), []byte(param), 0o644); err != nil {
		t.Fatalf("WriteFile(detector model.param) error = %v", err)
	}

	profile, ok, err := detectNativeVisionProfile(bundleDir)
	if err != nil {
		t.Fatalf("detectNativeVisionProfile() error = %v", err)
	}
	if !ok {
		t.Fatal("detectNativeVisionProfile() ok = false, want true for face bundle")
	}
	if profile.kind != nativeVisionProfileSCRFDFace {
		t.Fatalf("profile.kind = %q, want %q", profile.kind, nativeVisionProfileSCRFDFace)
	}
	if profile.detectorSubdir != filepath.Join("detector", "scrfd-500m-kps") {
		t.Fatalf("detectorSubdir = %q, want detector/scrfd-500m-kps", profile.detectorSubdir)
	}
	if profile.inputBlobName != "input.1" {
		t.Fatalf("inputBlobName = %q, want input.1", profile.inputBlobName)
	}
	wantMean := []float32{127.5, 127.5, 127.5}
	wantNorm := []float32{1.0 / 128.0, 1.0 / 128.0, 1.0 / 128.0}
	for i := range wantMean {
		if profile.meanValues[i] != wantMean[i] {
			t.Fatalf("meanValues[%d] = %.12f, want %.12f", i, profile.meanValues[i], wantMean[i])
		}
		if math.Abs(float64(profile.normValues[i]-wantNorm[i])) > 1e-9 {
			t.Fatalf("normValues[%d] = %.12f, want %.12f", i, profile.normValues[i], wantNorm[i])
		}
	}
	wantScores := []string{"412", "474", "536"}
	wantBoxes := []string{"415", "477", "539"}
	for i := range wantScores {
		if profile.scrfdScoreBlobs[i] != wantScores[i] || profile.scrfdBBoxBlobs[i] != wantBoxes[i] {
			t.Fatalf("scrfd blobs[%d] = %q/%q, want %q/%q", i, profile.scrfdScoreBlobs[i], profile.scrfdBBoxBlobs[i], wantScores[i], wantBoxes[i])
		}
	}
}

func TestDetectNativeVisionProfileReadsSCRFDKeypointHeadsFromDetectorMetadata(t *testing.T) {
	bundleDir := t.TempDir()
	writeNativeRuntimeJSONFileForTest(t, filepath.Join(bundleDir, "metadata.json"), map[string]interface{}{
		"bundle_id":   "face-int8",
		"model_class": modelClassVision,
		"pipeline": map[string]interface{}{
			"detector": map[string]interface{}{
				"task":       "face_detect",
				"input_size": []interface{}{640, 640},
			},
			"default_detector": "scrfd-500m-kps-int8",
			"detector_candidates": map[string]interface{}{
				"scrfd-500m-kps-int8": map[string]interface{}{
					"task": "face_detect",
					"postprocess": map[string]interface{}{
						"feature_strides": []interface{}{8, 16, 32},
						"output_blobs": map[string]interface{}{
							"stride8":  []interface{}{"out0", "out3", "out6"},
							"stride16": []interface{}{"out1", "out4", "out7"},
							"stride32": []interface{}{"out2", "out5", "out8"},
						},
					},
				},
			},
			"embedding": map[string]interface{}{
				"task":       "face_embedding",
				"input_size": []interface{}{112, 112},
			},
		},
	})
	detectorDir := filepath.Join(bundleDir, "detector", "scrfd-500m-kps")
	if err := os.MkdirAll(detectorDir, 0o755); err != nil {
		t.Fatalf("MkdirAll(detector) error = %v", err)
	}
	if err := os.WriteFile(filepath.Join(detectorDir, "model.param"), []byte("7767517\n1 1\nInput in0 0 1 in0\n"), 0o644); err != nil {
		t.Fatalf("WriteFile(detector model.param) error = %v", err)
	}

	profile, ok, err := detectNativeVisionProfile(bundleDir)
	if err != nil {
		t.Fatalf("detectNativeVisionProfile() error = %v", err)
	}
	if !ok {
		t.Fatal("detectNativeVisionProfile() ok = false, want true")
	}
	if profile.inputBlobName != "in0" {
		t.Fatalf("inputBlobName = %q, want in0", profile.inputBlobName)
	}
	wantScores := []string{"out0", "out1", "out2"}
	wantBoxes := []string{"out3", "out4", "out5"}
	wantKeypoints := []string{"out6", "out7", "out8"}
	if !reflect.DeepEqual(profile.scrfdScoreBlobs, wantScores) {
		t.Fatalf("scrfdScoreBlobs = %#v, want %#v", profile.scrfdScoreBlobs, wantScores)
	}
	if !reflect.DeepEqual(profile.scrfdBBoxBlobs, wantBoxes) {
		t.Fatalf("scrfdBBoxBlobs = %#v, want %#v", profile.scrfdBBoxBlobs, wantBoxes)
	}
	if !reflect.DeepEqual(profile.scrfdKPSBlobs, wantKeypoints) {
		t.Fatalf("scrfdKPSBlobs = %#v, want %#v", profile.scrfdKPSBlobs, wantKeypoints)
	}
	if !reflect.DeepEqual(profile.scrfdStrides, []int{8, 16, 32}) {
		t.Fatalf("scrfdStrides = %#v, want [8 16 32]", profile.scrfdStrides)
	}
	wantOutputs := []string{"out0", "out1", "out2", "out3", "out4", "out5", "out6", "out7", "out8"}
	if got := nativeSCRFDOutputBlobNames(profile); !reflect.DeepEqual(got, wantOutputs) {
		t.Fatalf("nativeSCRFDOutputBlobNames() = %#v, want %#v", got, wantOutputs)
	}
}

func TestDecodeNativeSCRFDFaceOutputProjectsBBoxAndSuppressesOverlap(t *testing.T) {
	profile := nativeVisionProfile{
		kind:            nativeVisionProfileSCRFDFace,
		targetWidth:     640,
		targetHeight:    640,
		scrfdStrides:    []int{8, 16, 32},
		scrfdScoreBlobs: []string{"412", "474", "536"},
		scrfdBBoxBlobs:  []string{"415", "477", "539"},
		faceBundle:      true,
	}
	input := nativePreparedVisionInput{
		profile:      profile,
		width:        640,
		height:       640,
		sourceWidth:  320,
		sourceHeight: 240,
		scale:        2,
		padY:         80,
	}
	scoreValues := make([]float32, 22*21)
	scoreValues[20*22+20] = 0.95
	scoreValues[20*22+21] = 0.90
	boxValues := make([]float32, 4*22*21)
	for _, x := range []int{20, 21} {
		boxValues[0*22*21+20*22+x] = 2
		boxValues[1*22*21+20*22+x] = 3
		boxValues[2*22*21+20*22+x] = 5
		boxValues[3*22*21+20*22+x] = 6
	}
	outputs := map[string]nativeVisionOutputMat{
		"412": {values: scoreValues, dims: 3, width: 22, height: 21, channels: 1},
		"415": {values: boxValues, dims: 3, width: 22, height: 21, channels: 4},
		"474": {values: []float32{0.20}, dims: 3, width: 1, height: 1, channels: 1},
		"477": {values: []float32{0.25, 0.25, 0.25, 0.25}, dims: 3, width: 1, height: 1, channels: 4},
		"536": {values: []float32{0.05}, dims: 3, width: 1, height: 1, channels: 1},
		"539": {values: []float32{0, 0, 0, 0}, dims: 3, width: 1, height: 1, channels: 4},
	}

	output := decodeNativeSCRFDFaceOutput(outputs, input)
	faces, ok := output["faces"].([]map[string]interface{})
	if !ok {
		t.Fatalf("faces type = %T, want []map[string]interface{}", output["faces"])
	}
	if len(faces) != 1 {
		t.Fatalf("len(faces) = %d, want NMS to keep 1 face", len(faces))
	}
	bbox, ok := faces[0]["bbox"].([]float64)
	if !ok {
		t.Fatalf("bbox type = %T, want []float64", faces[0]["bbox"])
	}
	want := []float64{72.0 / 320.0, 28.0 / 240.0, 100.0 / 320.0, 64.0 / 240.0}
	for i := range want {
		if math.Abs(bbox[i]-want[i]) > 1e-9 {
			t.Fatalf("bbox[%d] = %.12f, want %.12f (bbox=%#v)", i, bbox[i], want[i], bbox)
		}
	}
	pixelBBox, ok := faces[0]["pixel_bbox"].([]float64)
	if !ok {
		t.Fatalf("pixel_bbox type = %T, want []float64", faces[0]["pixel_bbox"])
	}
	wantPixels := []float64{72, 28, 100, 64}
	for i := range wantPixels {
		if math.Abs(pixelBBox[i]-wantPixels[i]) > 1e-9 {
			t.Fatalf("pixel_bbox[%d] = %.12f, want %.12f (pixel_bbox=%#v)", i, pixelBBox[i], wantPixels[i], pixelBBox)
		}
	}
	if faces[0]["confidence"].(float64) < 0.94 {
		t.Fatalf("confidence = %#v, want high score", faces[0]["confidence"])
	}
	detections, ok := output["detections"].([]map[string]interface{})
	if !ok || len(detections) != 1 {
		t.Fatalf("detections = %#v, want 1", output["detections"])
	}
}

func TestDecodeNativeSCRFDFaceOutputDecodesFlatFivePointLandmarks(t *testing.T) {
	profile := nativeVisionProfile{
		kind:            nativeVisionProfileSCRFDFace,
		targetWidth:     16,
		targetHeight:    16,
		scrfdStrides:    []int{8},
		scrfdScoreBlobs: []string{"out0"},
		scrfdBBoxBlobs:  []string{"out3"},
		scrfdKPSBlobs:   []string{"out6"},
		faceBundle:      true,
	}
	input := nativePreparedVisionInput{
		profile:      profile,
		width:        16,
		height:       16,
		sourceWidth:  8,
		sourceHeight: 6,
		scale:        2,
		padY:         2,
	}
	scores := make([]float32, 8)
	scores[7] = 0.95
	boxes := make([]float32, 8*4)
	copy(boxes[7*4:], []float32{1, 1, 1, 1})
	keypoints := make([]float32, 8*10)
	copy(keypoints[7*10:], []float32{
		-0.5, -0.25,
		0.5, -0.25,
		0, 0,
		-0.375, 0.5,
		0.375, 0.5,
	})
	outputs := map[string]nativeVisionOutputMat{
		"out0": {values: scores, dims: 2, width: 1, height: 8},
		"out3": {values: boxes, dims: 2, width: 4, height: 8},
		"out6": {values: keypoints, dims: 2, width: 10, height: 8},
	}

	output := decodeNativeSCRFDFaceOutput(outputs, input)
	faces, ok := output["faces"].([]map[string]interface{})
	if !ok || len(faces) != 1 {
		t.Fatalf("faces = %#v, want one decoded face", output["faces"])
	}
	pixelLandmarks, ok := faces[0]["pixel_landmarks"].([][]float64)
	if !ok {
		t.Fatalf("pixel_landmarks type = %T, want [][]float64", faces[0]["pixel_landmarks"])
	}
	wantPixels := [][]float64{{2, 2}, {6, 2}, {4, 3}, {2.5, 5}, {5.5, 5}}
	if !nativeVisionPointsClose(pixelLandmarks, wantPixels, 1e-9) {
		t.Fatalf("pixel_landmarks = %#v, want %#v", pixelLandmarks, wantPixels)
	}
	landmarks, ok := faces[0]["landmarks"].([][]float64)
	if !ok {
		t.Fatalf("landmarks type = %T, want [][]float64", faces[0]["landmarks"])
	}
	wantNormalized := [][]float64{{0.25, 2.0 / 6.0}, {0.75, 2.0 / 6.0}, {0.5, 0.5}, {0.3125, 5.0 / 6.0}, {0.6875, 5.0 / 6.0}}
	if !nativeVisionPointsClose(landmarks, wantNormalized, 1e-9) {
		t.Fatalf("landmarks = %#v, want %#v", landmarks, wantNormalized)
	}
}

func TestNativeSCRFDFaceBundleIntegration(t *testing.T) {
	libraryPath := strings.TrimSpace(os.Getenv("ZIMAOS_NCNN_INTEGRATION_LIBRARY"))
	bundleDir := strings.TrimSpace(os.Getenv("ZIMAOS_NCNN_INTEGRATION_FACE_BUNDLE"))
	imagePath := strings.TrimSpace(os.Getenv("ZIMAOS_NCNN_INTEGRATION_FACE_IMAGE"))
	if libraryPath == "" || bundleDir == "" || imagePath == "" {
		t.Skip("set NCNN integration library, face bundle, and image paths to run")
	}

	t.Setenv(envNativeLibraryPath, libraryPath)
	backend, err := openNativeEmbeddingBackend()
	if err != nil {
		t.Fatalf("openNativeEmbeddingBackend() error = %v", err)
	}
	runtimeValue := &nativeEmbeddingRuntime{base: backend, loaded: make(map[string]*nativeEmbeddingModel)}
	const modelClass = "vision:face-int8"
	if err := runtimeValue.load(modelClass, bundleDir, nativeEmbeddingLoadOptions{threadLimit: 4}); err != nil {
		t.Fatalf("load face bundle error = %v", err)
	}
	t.Cleanup(func() { runtimeValue.unload(modelClass) })

	input, err := prepareNativeVisionImageInput(bundleDir, map[string]interface{}{"image": imagePath})
	if err != nil {
		t.Fatalf("prepareNativeVisionImageInput() error = %v", err)
	}
	output, err := runtimeValue.detectVision(modelClass, input, 4, "face", true)
	if err != nil {
		t.Fatalf("detectVision() error = %v", err)
	}
	faces, ok := output["faces"].([]map[string]interface{})
	if !ok || len(faces) == 0 {
		t.Fatalf("faces = %#v, want at least one detected face", output["faces"])
	}
	pixelBBox, ok := faces[0]["pixel_bbox"].([]float64)
	if !ok || len(pixelBBox) < 4 || pixelBBox[2] <= pixelBBox[0] || pixelBBox[3] <= pixelBBox[1] {
		t.Fatalf("pixel_bbox = %#v, want a valid projected box", faces[0]["pixel_bbox"])
	}
	pixelLandmarks, ok := faces[0]["pixel_landmarks"].([][]float64)
	if !ok || len(pixelLandmarks) != 5 {
		t.Fatalf("pixel_landmarks = %#v, want five projected points", faces[0]["pixel_landmarks"])
	}
	embedding, ok := faces[0]["embedding"].([]float64)
	if !ok || len(embedding) != 512 {
		t.Fatalf("embedding length = %d, want 512", len(embedding))
	}
	norm := 0.0
	for _, value := range embedding {
		norm += value * value
	}
	if math.Abs(math.Sqrt(norm)-1) > 1e-5 {
		t.Fatalf("embedding L2 norm = %.8f, want 1", math.Sqrt(norm))
	}
	t.Logf("detected %d face(s); first pixel bbox=%v landmarks=%v confidence=%.6f embedding_dim=%d", len(faces), pixelBBox, pixelLandmarks, float64FromInterface(faces[0]["confidence"]), len(embedding))
}

func TestTryNativeVisionInferSupportsSplitFaceTasks(t *testing.T) {
	bundleDir := writeNativeSplitFaceBundleForTest(t)
	imagePath := writeNativeVisionSourceImageForTest(t)
	runtimeValue := newNativeSplitFaceRuntimeForTest(t, bundleDir)
	state := &wrapperRuntimeState{
		loadedBundles:   make(map[string]string),
		loadedBundleIDs: make(map[string]string),
	}
	state.rememberLoad(modelClassVision, []string{"cpu"}, bundleDir, "face-int8")
	native := nativeEmbeddingSpec{backend: runtimeValue}

	detectResult, handled := tryNativeVisionInfer(state, native, inferRequest{
		ModelClass: modelClassVision,
		Task:       "face_detect",
		Input:      map[string]interface{}{"image": imagePath},
	})
	if !handled {
		t.Fatal("face_detect handled = false, want true")
	}
	if got := detectResult.Output["error"]; got != nil {
		t.Fatalf("face_detect error = %#v, want success", got)
	}
	detectedFaces, ok := detectResult.Output["faces"].([]map[string]interface{})
	if !ok || len(detectedFaces) != 1 {
		t.Fatalf("face_detect faces = %#v, want one face", detectResult.Output["faces"])
	}
	if _, exists := detectedFaces[0]["embedding"]; exists {
		t.Fatalf("face_detect unexpectedly embedded face: %#v", detectedFaces[0])
	}

	embedResult, handled := tryNativeVisionInfer(state, native, inferRequest{
		ModelClass: modelClassVision,
		Task:       "face_embed",
		Input: map[string]interface{}{
			"image": imagePath,
			"faces": []interface{}{map[string]interface{}{
				"confidence": 0.96,
				"pixel_landmarks": []interface{}{
					[]interface{}{166.0, 92.0},
					[]interface{}{218.0, 92.0},
					[]interface{}{192.0, 118.0},
					[]interface{}{174.0, 144.0},
					[]interface{}{210.0, 144.0},
				},
			}},
		},
	})
	if !handled {
		t.Fatal("face_embed handled = false, want true")
	}
	if got := embedResult.Output["error"]; got != nil {
		t.Fatalf("face_embed error = %#v, want success", got)
	}
	embeddedFaces, ok := embedResult.Output["faces"].([]map[string]interface{})
	if !ok || len(embeddedFaces) != 1 {
		t.Fatalf("face_embed faces = %#v, want one face", embedResult.Output["faces"])
	}
	embedding, ok := embeddedFaces[0]["embedding"].([]float64)
	if !ok || len(embedding) != 3 {
		t.Fatalf("face_embed embedding = %#v, want 3 values", embeddedFaces[0]["embedding"])
	}
	if math.Abs(embedding[0]-0.6) > 1e-9 || math.Abs(embedding[1]-0.8) > 1e-9 || math.Abs(embedding[2]) > 1e-9 {
		t.Fatalf("face_embed embedding = %#v, want normalized [0.6 0.8 0]", embedding)
	}
}

func TestTryNativeVisionInferKeepsCombinedFaceTaskCompatible(t *testing.T) {
	bundleDir := writeNativeSplitFaceBundleForTest(t)
	imagePath := writeNativeVisionSourceImageForTest(t)
	runtimeValue := newNativeSplitFaceRuntimeForTest(t, bundleDir)
	state := &wrapperRuntimeState{
		loadedBundles:   make(map[string]string),
		loadedBundleIDs: make(map[string]string),
	}
	state.rememberLoad(modelClassVision, []string{"cpu"}, bundleDir, "face-int8")

	result, handled := tryNativeVisionInfer(state, nativeEmbeddingSpec{backend: runtimeValue}, inferRequest{
		ModelClass: modelClassVision,
		Task:       "face",
		Input:      map[string]interface{}{"image": imagePath},
	})
	if !handled {
		t.Fatal("face handled = false, want true")
	}
	if got := result.Output["error"]; got != nil {
		t.Fatalf("face error = %#v, want success", got)
	}
	faces, ok := result.Output["faces"].([]map[string]interface{})
	if !ok || len(faces) != 1 {
		t.Fatalf("face output = %#v, want one face", result.Output["faces"])
	}
	if embedding, ok := faces[0]["embedding"].([]float64); !ok || len(embedding) != 3 {
		t.Fatalf("combined face embedding = %#v, want 3 values", faces[0]["embedding"])
	}
}

func writeNativeSplitFaceBundleForTest(t *testing.T) string {
	t.Helper()
	bundleDir := t.TempDir()
	writeNativeRuntimeJSONFileForTest(t, filepath.Join(bundleDir, "metadata.json"), map[string]interface{}{
		"bundle_id":   "face-int8",
		"model_class": modelClassVision,
		"pipeline": map[string]interface{}{
			"detector": map[string]interface{}{
				"task":       "face_detect",
				"input_size": []interface{}{8, 8},
			},
			"embedding": map[string]interface{}{
				"task":             "face_embedding",
				"input_size":       []interface{}{112, 112},
				"output_dimension": 3,
			},
		},
	})
	return bundleDir
}

func newNativeSplitFaceRuntimeForTest(t *testing.T, bundleDir string) *nativeEmbeddingRuntime {
	t.Helper()
	profile, ok, err := detectNativeVisionProfile(bundleDir)
	if err != nil || !ok {
		t.Fatalf("detectNativeVisionProfile() profile=%+v ok=%v err=%v", profile, ok, err)
	}
	detectValues := []float32{4, 4, 4, 4, 0.95}
	embedValues := []float32{3, 4, 0}
	bindings := nativeNCNNBindings{
		matFromPixels:             func(*byte, int32, int32, int32, int32, uintptr) uintptr { return 10 },
		matDestroy:                func(uintptr) {},
		matSubstractMeanNormalize: func(uintptr, *float32, *float32) {},
		extractorCreate:           func(net uintptr) uintptr { return net + 100 },
		extractorDestroy:          func(uintptr) {},
		extractorInput:            func(uintptr, *byte, uintptr) int32 { return 0 },
		extractorExtract: func(extractor uintptr, _ *byte, output *uintptr) int32 {
			switch extractor {
			case 101:
				*output = 201
			case 102:
				*output = 202
			default:
				return -1
			}
			return 0
		},
		matGetDims: func(mat uintptr) int32 {
			if mat == 201 {
				return 2
			}
			return 1
		},
		matGetW: func(mat uintptr) int32 {
			if mat == 201 {
				return 5
			}
			return 3
		},
		matGetH: func(uintptr) int32 { return 1 },
		matGetD: func(uintptr) int32 { return 1 },
		matGetC: func(uintptr) int32 { return 1 },
		matGetData: func(mat uintptr) unsafe.Pointer {
			if mat == 201 {
				return unsafe.Pointer(&detectValues[0])
			}
			return unsafe.Pointer(&embedValues[0])
		},
	}
	return &nativeEmbeddingRuntime{
		base: &nativeEmbeddingBackend{bindings: bindings},
		loaded: map[string]*nativeEmbeddingModel{
			modelClassVision: {
				net:              1,
				faceEmbeddingNet: 2,
				visionProfile:    profile,
			},
		},
	}
}

func TestDecodeNativeSCRFDFaceOutputIncludesDebugSummaryWhenEnabled(t *testing.T) {
	t.Setenv(envNativeSCRFDDebug, "1")
	profile := nativeVisionProfile{
		kind:            nativeVisionProfileSCRFDFace,
		targetWidth:     640,
		targetHeight:    640,
		scrfdStrides:    []int{8},
		scrfdScoreBlobs: []string{"412"},
		scrfdBBoxBlobs:  []string{"415"},
		faceBundle:      true,
	}
	input := nativePreparedVisionInput{
		profile:      profile,
		width:        640,
		height:       640,
		sourceWidth:  640,
		sourceHeight: 640,
		scale:        1,
	}
	outputs := map[string]nativeVisionOutputMat{
		"412": {values: []float32{0.12, 0.72, 0.20, 0.05}, dims: 3, width: 2, height: 2, channels: 1},
		"415": {values: []float32{
			1, 2, 3, 4,
			5, 6, 7, 8,
			9, 10, 11, 12,
			13, 14, 15, 16,
		}, dims: 3, width: 2, height: 2, channels: 4},
	}

	output := decodeNativeSCRFDFaceOutput(outputs, input)
	debug, ok := output["scrfd_debug"].(map[string]interface{})
	if !ok {
		t.Fatalf("scrfd_debug type = %T, want map[string]interface{}", output["scrfd_debug"])
	}
	scoreSummaries, ok := debug["score_blobs"].([]map[string]interface{})
	if !ok || len(scoreSummaries) != 1 {
		t.Fatalf("score_blobs = %#v, want one score summary", debug["score_blobs"])
	}
	if got := scoreSummaries[0]["name"]; got != "412" {
		t.Fatalf("score blob name = %#v, want 412", got)
	}
	if got := scoreSummaries[0]["max"]; got != float64(0.72) {
		t.Fatalf("score max = %#v, want 0.72", got)
	}
	if got := scoreSummaries[0]["top_x"]; got != 1 {
		t.Fatalf("score top_x = %#v, want 1", got)
	}
	if got := scoreSummaries[0]["top_y"]; got != 0 {
		t.Fatalf("score top_y = %#v, want 0", got)
	}
	if got := debug["candidates_before_nms"]; got != 1 {
		t.Fatalf("candidates_before_nms = %#v, want 1", got)
	}
	if got := debug["detections_after_nms"]; got != 1 {
		t.Fatalf("detections_after_nms = %#v, want 1", got)
	}
}

func TestNativeVisionLoadUsesSCRFDDetectorSubdirForFaceBundle(t *testing.T) {
	bundleDir := t.TempDir()
	writeNativeRuntimeJSONFileForTest(t, filepath.Join(bundleDir, "metadata.json"), map[string]interface{}{
		"bundle_id":   "face-int8",
		"model_class": modelClassVision,
		"pipeline": map[string]interface{}{
			"detector": map[string]interface{}{
				"task":       "face_detect",
				"input_size": []interface{}{640, 640},
			},
			"embedding": map[string]interface{}{
				"task":       "face_embedding",
				"input_size": []interface{}{112, 112},
			},
		},
	})
	detectorDir := filepath.Join(bundleDir, "detector", "scrfd-500m-kps")
	embeddingDir := filepath.Join(bundleDir, "embedding")
	if err := os.MkdirAll(detectorDir, 0o755); err != nil {
		t.Fatalf("MkdirAll(detector) error = %v", err)
	}
	if err := os.MkdirAll(embeddingDir, 0o755); err != nil {
		t.Fatalf("MkdirAll(embedding) error = %v", err)
	}
	if err := os.WriteFile(filepath.Join(detectorDir, "model.param"), []byte("7767517\n1 1\nInput input.1 0 1 input.1\n"), 0o644); err != nil {
		t.Fatalf("WriteFile(detector model.param) error = %v", err)
	}

	var loadedDirs []string
	runtime := &nativeEmbeddingRuntime{
		base:   &nativeEmbeddingBackend{},
		loaded: map[string]*nativeEmbeddingModel{},
	}
	previous := nativeLoadNetFromDir
	nativeLoadNetFromDir = func(_ *nativeEmbeddingBackend, dir string, _ nativeEmbeddingLoadOptions) (uintptr, error) {
		loadedDirs = append(loadedDirs, filepath.ToSlash(dir))
		return uintptr(len(loadedDirs)), nil
	}
	t.Cleanup(func() { nativeLoadNetFromDir = previous })

	if err := runtime.load(modelClassVision, bundleDir, nativeEmbeddingLoadOptions{}); err != nil {
		t.Fatalf("runtime.load() error = %v", err)
	}
	if len(loadedDirs) != 2 {
		t.Fatalf("loadedDirs = %#v, want detector and embedding", loadedDirs)
	}
	if got, want := loadedDirs[0], filepath.ToSlash(detectorDir); got != want {
		t.Fatalf("detector load dir = %q, want %q", got, want)
	}
	if got, want := loadedDirs[1], filepath.ToSlash(embeddingDir); got != want {
		t.Fatalf("embedding load dir = %q, want %q", got, want)
	}
}

func TestNativeVisionLoadRejectsEscapingSCRFDDetectorSubdir(t *testing.T) {
	for _, testCase := range []struct {
		name   string
		subdir func(string) string
	}{
		{
			name: "parent traversal",
			subdir: func(string) string {
				return filepath.Join("..", "outside-scrfd")
			},
		},
		{
			name: "absolute path",
			subdir: func(bundleDir string) string {
				return filepath.Join(filepath.Dir(bundleDir), "outside-scrfd")
			},
		},
	} {
		t.Run(testCase.name, func(t *testing.T) {
			bundleDir := t.TempDir()
			writeNativeRuntimeJSONFileForTest(t, filepath.Join(bundleDir, "metadata.json"), map[string]interface{}{
				"bundle_id":   "face-int8",
				"model_class": modelClassVision,
				"pipeline": map[string]interface{}{
					"detector": map[string]interface{}{
						"task":   "face_detect",
						"subdir": testCase.subdir(bundleDir),
					},
					"embedding": map[string]interface{}{
						"task": "face_embedding",
					},
				},
			})

			var loadedDirs []string
			runtime := &nativeEmbeddingRuntime{
				base:   &nativeEmbeddingBackend{},
				loaded: map[string]*nativeEmbeddingModel{},
			}
			previous := nativeLoadNetFromDir
			nativeLoadNetFromDir = func(_ *nativeEmbeddingBackend, dir string, _ nativeEmbeddingLoadOptions) (uintptr, error) {
				loadedDirs = append(loadedDirs, filepath.Clean(dir))
				return uintptr(len(loadedDirs)), nil
			}
			t.Cleanup(func() { nativeLoadNetFromDir = previous })

			if err := runtime.load(modelClassVision, bundleDir, nativeEmbeddingLoadOptions{}); err != nil {
				t.Fatalf("runtime.load() error = %v", err)
			}
			if len(loadedDirs) != 2 {
				t.Fatalf("loadedDirs = %#v, want detector and embedding", loadedDirs)
			}
			if got, want := loadedDirs[0], filepath.Clean(bundleDir); got != want {
				t.Fatalf("detector load dir = %q, want safe legacy root %q", got, want)
			}
		})
	}
}

func TestExtractNativeVisionOutputMatDestroysNonzeroMatOnError(t *testing.T) {
	const outputMat = uintptr(73)
	for _, testCase := range []struct {
		name        string
		extractCode int32
		dims        int32
		width       int32
		value       float32
		hasData     bool
	}{
		{name: "extract error", extractCode: -1},
		{name: "empty output", dims: 1},
		{name: "nil data", dims: 1, width: 1},
		{name: "non-finite data", dims: 1, width: 1, value: float32(math.NaN()), hasData: true},
	} {
		t.Run(testCase.name, func(t *testing.T) {
			var destroyed []uintptr
			runtime := &nativeEmbeddingRuntime{base: &nativeEmbeddingBackend{bindings: nativeNCNNBindings{
				extractorExtract: func(_ uintptr, _ *byte, out *uintptr) int32 {
					*out = outputMat
					return testCase.extractCode
				},
				matDestroy: func(handle uintptr) {
					destroyed = append(destroyed, handle)
				},
				matGetDims: func(uintptr) int32 { return testCase.dims },
				matGetW:    func(uintptr) int32 { return testCase.width },
				matGetH:    func(uintptr) int32 { return 1 },
				matGetD:    func(uintptr) int32 { return 1 },
				matGetC:    func(uintptr) int32 { return 1 },
				matGetData: func(uintptr) unsafe.Pointer {
					if !testCase.hasData {
						return nil
					}
					return unsafe.Pointer(&testCase.value)
				},
			}}}

			if _, err := runtime.extractNativeVisionOutputMat(1, "output"); err == nil {
				t.Fatal("extractNativeVisionOutputMat() error = nil, want error")
			}
			if len(destroyed) != 1 || destroyed[0] != outputMat {
				t.Fatalf("destroyed mats = %#v, want [%d]", destroyed, outputMat)
			}
		})
	}
}

func TestNativeVisionInferRejectsNonFiniteOutput(t *testing.T) {
	const (
		inputMat  = uintptr(201)
		outputMat = uintptr(202)
		extractor = uintptr(301)
	)
	value := float32(math.Inf(-1))
	runtimeValue := &nativeEmbeddingRuntime{
		base: &nativeEmbeddingBackend{bindings: nativeNCNNBindings{
			matFromPixels:             func(*byte, int32, int32, int32, int32, uintptr) uintptr { return inputMat },
			matDestroy:                func(uintptr) {},
			matSubstractMeanNormalize: func(uintptr, *float32, *float32) {},
			extractorCreate:           func(uintptr) uintptr { return extractor },
			extractorDestroy:          func(uintptr) {},
			extractorInput:            func(uintptr, *byte, uintptr) int32 { return 0 },
			extractorExtract: func(_ uintptr, _ *byte, out *uintptr) int32 {
				*out = outputMat
				return 0
			},
			matGetDims: func(uintptr) int32 { return 1 },
			matGetW:    func(uintptr) int32 { return 1 },
			matGetH:    func(uintptr) int32 { return 1 },
			matGetD:    func(uintptr) int32 { return 1 },
			matGetC:    func(uintptr) int32 { return 1 },
			matGetData: func(uintptr) unsafe.Pointer { return unsafe.Pointer(&value) },
		}},
		loaded: map[string]*nativeEmbeddingModel{
			modelClassVision: {
				net: 101,
				visionProfile: nativeVisionProfile{
					kind:           testNativeVisionProfileEmbedding,
					inputBlobName:  "input",
					outputBlobName: "output",
				},
			},
		},
	}

	_, err := runtimeValue.inferVision(modelClassVision, nativePreparedVisionInput{
		profile: nativeVisionProfile{
			kind:           testNativeVisionProfileEmbedding,
			inputBlobName:  "input",
			outputBlobName: "output",
		},
		width:  1,
		height: 1,
		pixels: []byte{0, 0, 0},
	}, 0)
	if err == nil || !strings.Contains(err.Error(), "non-finite") {
		t.Fatalf("inferVision() error = %v, want non-finite rejection", err)
	}
}

func TestNativeVisionInferenceDefersDestroyWhileInFlight(t *testing.T) {
	for _, testCase := range []struct {
		name   string
		detect bool
		reload bool
	}{
		{name: "infer unload"},
		{name: "infer reload", reload: true},
		{name: "detect unload", detect: true},
		{name: "detect reload", detect: true, reload: true},
	} {
		t.Run(testCase.name, func(t *testing.T) {
			const (
				oldNet    = uintptr(101)
				newNet    = uintptr(102)
				inputMat  = uintptr(201)
				outputMat = uintptr(202)
				extractor = uintptr(301)
			)
			inferStarted := make(chan struct{})
			allowInfer := make(chan struct{})
			destroyed := make(chan uintptr, 2)
			output := []float32{1}
			if testCase.detect {
				output = []float32{0, 0, 0, 0, 0}
			}
			bindings := nativeNCNNBindings{
				netDestroy: func(handle uintptr) {
					if handle == oldNet {
						destroyed <- handle
					}
				},
				matFromPixels: func(*byte, int32, int32, int32, int32, uintptr) uintptr {
					return inputMat
				},
				matDestroy:                func(uintptr) {},
				matSubstractMeanNormalize: func(uintptr, *float32, *float32) {},
				extractorCreate:           func(uintptr) uintptr { return extractor },
				extractorDestroy:          func(uintptr) {},
				extractorInput:            func(uintptr, *byte, uintptr) int32 { return 0 },
				extractorExtract: func(_ uintptr, _ *byte, out *uintptr) int32 {
					close(inferStarted)
					<-allowInfer
					*out = outputMat
					return 0
				},
				matGetDims: func(uintptr) int32 {
					if testCase.detect {
						return 2
					}
					return 1
				},
				matGetW: func(uintptr) int32 {
					if testCase.detect {
						return 5
					}
					return 1
				},
				matGetH:    func(uintptr) int32 { return 1 },
				matGetD:    func(uintptr) int32 { return 1 },
				matGetC:    func(uintptr) int32 { return 1 },
				matGetData: func(uintptr) unsafe.Pointer { return unsafe.Pointer(&output[0]) },
			}
			profile := nativeVisionProfile{
				kind:           testNativeVisionProfileEmbedding,
				outputDim:      1,
				inputBlobName:  "input",
				outputBlobName: "output",
			}
			if testCase.detect {
				profile = nativeVisionProfile{
					kind:           nativeVisionProfileYOLOv8Detect,
					targetWidth:    1,
					targetHeight:   1,
					classCount:     1,
					classLabels:    []string{"object"},
					inputBlobName:  "images",
					outputBlobName: "output0",
				}
			}
			oldModel := &nativeEmbeddingModel{net: oldNet, visionProfile: profile}
			runtimeValue := &nativeEmbeddingRuntime{
				base: &nativeEmbeddingBackend{bindings: bindings},
				loaded: map[string]*nativeEmbeddingModel{
					modelClassVision: oldModel,
				},
			}

			var reloadBundleDir string
			if testCase.reload {
				reloadBundleDir = writeNativeVisionLifecycleBundleForTest(t, testCase.detect)
				previous := nativeLoadNetFromDir
				nativeLoadNetFromDir = func(_ *nativeEmbeddingBackend, _ string, _ nativeEmbeddingLoadOptions) (uintptr, error) {
					return newNet, nil
				}
				t.Cleanup(func() { nativeLoadNetFromDir = previous })
			}

			inferDone := make(chan error, 1)
			go func() {
				input := nativePreparedVisionInput{
					profile:      profile,
					width:        1,
					height:       1,
					sourceWidth:  1,
					sourceHeight: 1,
					scale:        1,
					pixels:       []byte{0, 0, 0},
				}
				if testCase.detect {
					_, err := runtimeValue.detectVision(modelClassVision, input, 0, "", true)
					inferDone <- err
					return
				}
				_, err := runtimeValue.inferVision(modelClassVision, input, 0)
				inferDone <- err
			}()

			select {
			case <-inferStarted:
			case <-time.After(2 * time.Second):
				t.Fatal("vision infer did not reach extractorExtract")
			}

			mutationDone := make(chan error, 1)
			go func() {
				if testCase.reload {
					mutationDone <- runtimeValue.load(modelClassVision, reloadBundleDir, nativeEmbeddingLoadOptions{})
					return
				}
				runtimeValue.unload(modelClassVision)
				mutationDone <- nil
			}()

			prematureDestroy, mutationObservedErr := waitForNativeEmbeddingMutationForTest(
				runtimeValue,
				modelClassVision,
				oldModel,
				testCase.reload,
				destroyed,
			)
			if prematureDestroy == 0 {
				select {
				case prematureDestroy = <-destroyed:
				case <-time.After(100 * time.Millisecond):
				}
			}
			close(allowInfer)

			select {
			case err := <-inferDone:
				if err != nil {
					t.Errorf("vision infer error = %v", err)
				}
			case <-time.After(2 * time.Second):
				t.Error("vision infer did not finish after release")
			}
			select {
			case err := <-mutationDone:
				if err != nil {
					t.Errorf("model mutation error = %v", err)
				}
			case <-time.After(2 * time.Second):
				t.Error("model mutation did not finish after vision infer completed")
			}

			if mutationObservedErr != nil {
				t.Error(mutationObservedErr)
			}
			if prematureDestroy != 0 {
				t.Errorf("netDestroy(%d) ran before in-flight vision infer completed", prematureDestroy)
			}
			if prematureDestroy == 0 {
				select {
				case destroyedNet := <-destroyed:
					if destroyedNet != oldNet {
						t.Fatalf("destroyed net = %d, want old net %d", destroyedNet, oldNet)
					}
				case <-time.After(2 * time.Second):
					t.Fatal("old vision model net was not destroyed after infer completed")
				}
			}
		})
	}
}

func writeNativeVisionLifecycleBundleForTest(t *testing.T, detect bool) string {
	t.Helper()
	bundleDir := t.TempDir()
	metadata := map[string]interface{}{
		"bundle_id":   "detect-general-int8",
		"model_class": modelClassVision,
		"provider":    "ultralytics",
		"model":       "yolov8n",
		"task":        "detect",
		"input_size":  []interface{}{1, 1},
		"classes":     1,
	}
	writeNativeRuntimeJSONFileForTest(t, filepath.Join(bundleDir, "metadata.json"), metadata)
	return bundleDir
}

func TestDecodeNativeYOLOv8DetectOutputReturnsDogLabel(t *testing.T) {
	profile := nativeVisionProfile{
		kind:         nativeVisionProfileYOLOv8Detect,
		targetWidth:  640,
		targetHeight: 640,
		classCount:   80,
	}
	input := nativePreparedVisionInput{
		profile: profile,
		width:   640,
		height:  640,
	}
	rows := 2
	cols := 84
	values := make([]float32, rows*cols)

	values[0*cols+0] = 320
	values[0*cols+1] = 320
	values[0*cols+2] = 200
	values[0*cols+3] = 180
	values[0*cols+4+16] = 0.91

	values[1*cols+0] = 100
	values[1*cols+1] = 100
	values[1*cols+2] = 60
	values[1*cols+3] = 50
	values[1*cols+4+0] = 0.24

	output := decodeNativeYOLOv8DetectOutput(values, rows, cols, input)
	detections, ok := output["detections"].([]map[string]interface{})
	if !ok {
		t.Fatalf("detections type = %T, want []map[string]interface{}", output["detections"])
	}
	if len(detections) != 1 {
		t.Fatalf("len(detections) = %d, want 1", len(detections))
	}
	if got := detections[0]["label"]; got != "dog" {
		t.Fatalf("detections[0][label] = %#v, want dog", got)
	}
	objects, ok := output["objects"].([]string)
	if !ok {
		t.Fatalf("objects type = %T, want []string", output["objects"])
	}
	if len(objects) != 1 || objects[0] != "dog" {
		t.Fatalf("objects = %#v, want [dog]", objects)
	}
}

func TestDecodeNativeYOLOv8DetectOutputReturnsFacesForFaceBundle(t *testing.T) {
	profile := nativeVisionProfile{
		kind:         nativeVisionProfileYOLOv8Detect,
		targetWidth:  640,
		targetHeight: 640,
		classCount:   1,
		classLabels:  []string{"face"},
		faceBundle:   true,
	}
	input := nativePreparedVisionInput{
		profile:      profile,
		width:        640,
		height:       640,
		sourceWidth:  640,
		sourceHeight: 640,
		scale:        1,
	}
	rows := 1
	cols := 5
	values := make([]float32, rows*cols)
	values[0] = 320
	values[1] = 320
	values[2] = 200
	values[3] = 180
	values[4] = 0.91

	output := decodeNativeYOLOv8DetectOutput(values, rows, cols, input)
	faces, ok := output["faces"].([]map[string]interface{})
	if !ok {
		t.Fatalf("faces type = %T, want []map[string]interface{}", output["faces"])
	}
	if len(faces) != 1 {
		t.Fatalf("len(faces) = %d, want 1", len(faces))
	}
	bbox, ok := faces[0]["bbox"].([]float64)
	if !ok {
		t.Fatalf("bbox type = %T, want []float64", faces[0]["bbox"])
	}
	want := []float64{220.0 / 640.0, 230.0 / 640.0, 420.0 / 640.0, 410.0 / 640.0}
	for i := range want {
		if math.Abs(bbox[i]-want[i]) > 1e-9 {
			t.Fatalf("bbox[%d] = %.12f, want %.12f (bbox=%#v)", i, bbox[i], want[i], bbox)
		}
	}
	pixelBBox, ok := faces[0]["pixel_bbox"].([]float64)
	if !ok {
		t.Fatalf("pixel_bbox type = %T, want []float64", faces[0]["pixel_bbox"])
	}
	wantPixels := []float64{220, 230, 420, 410}
	for i := range wantPixels {
		if math.Abs(pixelBBox[i]-wantPixels[i]) > 1e-9 {
			t.Fatalf("pixel_bbox[%d] = %.12f, want %.12f (pixel_bbox=%#v)", i, pixelBBox[i], wantPixels[i], pixelBBox)
		}
	}
	if faces[0]["confidence"] != 0.9100000262260437 {
		t.Fatalf("confidence = %#v, want YOLO score", faces[0]["confidence"])
	}
	objects, ok := output["objects"].([]string)
	if !ok || len(objects) != 1 || objects[0] != "face" {
		t.Fatalf("objects = %#v, want [face]", output["objects"])
	}
}

func TestNativeFaceEmbeddingBBoxPrefersPixelBBoxAndScalesNormalizedBBox(t *testing.T) {
	source := image.NewNRGBA(image.Rect(0, 0, 200, 100))
	pixelBBox, ok := nativeFaceEmbeddingBBox(source, map[string]interface{}{
		"bbox":       []float64{0.10, 0.20, 0.50, 0.80},
		"pixel_bbox": []float64{12, 18, 98, 90},
	})
	if !ok {
		t.Fatal("nativeFaceEmbeddingBBox() ok = false, want true")
	}
	wantPixels := []float64{12, 18, 98, 90}
	for i := range wantPixels {
		if pixelBBox[i] != wantPixels[i] {
			t.Fatalf("pixelBBox[%d] = %.12f, want %.12f", i, pixelBBox[i], wantPixels[i])
		}
	}

	scaledBBox, ok := nativeFaceEmbeddingBBox(source, map[string]interface{}{
		"bbox": []float64{0.10, 0.20, 0.50, 0.80},
	})
	if !ok {
		t.Fatal("nativeFaceEmbeddingBBox() normalized ok = false, want true")
	}
	wantScaled := []float64{20, 20, 100, 80}
	for i := range wantScaled {
		if math.Abs(scaledBBox[i]-wantScaled[i]) > 1e-9 {
			t.Fatalf("scaledBBox[%d] = %.12f, want %.12f", i, scaledBBox[i], wantScaled[i])
		}
	}
}

func TestNativeFaceEmbeddingPixelsForFaceAlignsFiveLandmarksToAdaFaceTemplate(t *testing.T) {
	source := image.NewNRGBA(image.Rect(0, 0, 128, 128))
	template := [][]float64{
		{38.2946, 51.6963},
		{73.5318, 51.5014},
		{56.0252, 71.7366},
		{41.5493, 92.3655},
		{70.7299, 92.2041},
	}
	colors := []color.NRGBA{
		{R: 255, A: 255},
		{G: 255, A: 255},
		{B: 255, A: 255},
		{R: 255, G: 255, A: 255},
		{G: 255, B: 255, A: 255},
	}
	sourceLandmarks := make([][]float64, 0, len(template))
	for index, point := range template {
		x := point[0]*0.8 + 10
		y := point[1]*0.8 + 5
		sourceLandmarks = append(sourceLandmarks, []float64{x, y})
		centerX := int(math.Round(x))
		centerY := int(math.Round(y))
		fillNativeVisionRect(source, image.Rect(centerX-2, centerY-2, centerX+3, centerY+3), colors[index])
	}
	profile := nativeVisionProfile{faceEmbeddingWidth: 112, faceEmbeddingHeight: 112}
	face := map[string]interface{}{
		"pixel_bbox":      []float64{0, 0, 12, 12},
		"pixel_landmarks": sourceLandmarks,
	}

	pixels, width, height, err := nativeFaceEmbeddingPixelsForFace(source, profile, face)
	if err != nil {
		t.Fatalf("nativeFaceEmbeddingPixelsForFace() error = %v", err)
	}
	if width != 112 || height != 112 {
		t.Fatalf("aligned size = %dx%d, want 112x112", width, height)
	}
	for index, point := range template {
		x := int(math.Round(point[0]))
		y := int(math.Round(point[1]))
		pixelIndex := (y*width + x) * 3
		got := color.NRGBA{R: pixels[pixelIndex], G: pixels[pixelIndex+1], B: pixels[pixelIndex+2], A: 255}
		want := colors[index]
		if math.Abs(float64(got.R)-float64(want.R)) > 30 || math.Abs(float64(got.G)-float64(want.G)) > 30 || math.Abs(float64(got.B)-float64(want.B)) > 30 {
			t.Fatalf("aligned marker %d at (%d,%d) = %#v, want near %#v", index, x, y, got, want)
		}
	}
}

func TestNativeFaceEmbeddingPixelsForFaceFallsBackToBBoxWithoutValidLandmarks(t *testing.T) {
	source := image.NewNRGBA(image.Rect(0, 0, 100, 100))
	fillNativeVisionRect(source, image.Rect(20, 20, 80, 80), color.NRGBA{R: 25, G: 150, B: 230, A: 255})
	profile := nativeVisionProfile{faceEmbeddingWidth: 112, faceEmbeddingHeight: 112}
	bbox := []float64{20, 20, 80, 80}
	face := map[string]interface{}{
		"pixel_bbox": bbox,
		"pixel_landmarks": [][]float64{
			{30, 35}, {70, 35}, {50, 50}, {35, 70},
		},
	}

	gotPixels, gotWidth, gotHeight, err := nativeFaceEmbeddingPixelsForFace(source, profile, face)
	if err != nil {
		t.Fatalf("nativeFaceEmbeddingPixelsForFace() error = %v", err)
	}
	wantPixels, wantWidth, wantHeight, err := nativeFaceEmbeddingPixels(source, profile, bbox)
	if err != nil {
		t.Fatalf("nativeFaceEmbeddingPixels() error = %v", err)
	}
	if gotWidth != wantWidth || gotHeight != wantHeight || !reflect.DeepEqual(gotPixels, wantPixels) {
		t.Fatal("invalid landmarks did not fall back to the existing bbox crop")
	}
}

func TestPostprocessNativeVisionOutputNormalizesEmbeddingProfiles(t *testing.T) {
	embeddingProfile := nativeVisionProfile{
		kind:            testNativeVisionProfileEmbedding,
		normalizeOutput: true,
	}

	embedding := postprocessNativeVisionOutput([]float64{3, 4}, embeddingProfile)
	if math.Abs(embedding[0]-0.6) > 1e-9 || math.Abs(embedding[1]-0.8) > 1e-9 {
		t.Fatalf("embedding output = %#v, want [0.6 0.8]", embedding)
	}
}

func TestNativeYOLOv8OutputRowsTransposesFeatureMajor2DOutput(t *testing.T) {
	profile := nativeVisionProfile{
		kind:         nativeVisionProfileYOLOv8Detect,
		targetWidth:  640,
		targetHeight: 640,
		classCount:   80,
	}
	rows := 2
	cols := 84
	detectionRows := make([]float32, rows*cols)

	detectionRows[0*cols+0] = 320
	detectionRows[0*cols+1] = 320
	detectionRows[0*cols+2] = 200
	detectionRows[0*cols+3] = 180
	detectionRows[0*cols+4+16] = 0.91

	detectionRows[1*cols+0] = 100
	detectionRows[1*cols+1] = 100
	detectionRows[1*cols+2] = 60
	detectionRows[1*cols+3] = 50
	detectionRows[1*cols+4+0] = 0.24

	featureMajor := make([]float32, rows*cols)
	for col := 0; col < cols; col++ {
		for row := 0; row < rows; row++ {
			featureMajor[col*rows+row] = detectionRows[row*cols+col]
		}
	}

	reordered, gotRows, gotCols, err := nativeYOLOv8OutputRows(profile, featureMajor, 2, rows, cols, 0, 0)
	if err != nil {
		t.Fatalf("nativeYOLOv8OutputRows() error = %v", err)
	}
	if gotRows != rows || gotCols != cols {
		t.Fatalf("nativeYOLOv8OutputRows() shape = (%d,%d), want (%d,%d)", gotRows, gotCols, rows, cols)
	}
	if len(reordered) != len(detectionRows) {
		t.Fatalf("len(reordered) = %d, want %d", len(reordered), len(detectionRows))
	}
	for i := range detectionRows {
		if reordered[i] != detectionRows[i] {
			t.Fatalf("reordered[%d] = %v, want %v", i, reordered[i], detectionRows[i])
		}
	}
}

func TestPrepareNativeVisionImageInputRejectsRetiredEmbeddingBundle(t *testing.T) {
	bundleDir := writeNativeVisionBundleForTest(t)
	imagePath := writeNativeVisionSourceImageForTest(t)

	_, err := prepareNativeVisionImageInput(bundleDir, map[string]interface{}{
		"image": imagePath,
	})
	if err == nil || !strings.Contains(err.Error(), "unsupported native vision bundle") {
		t.Fatalf("prepareNativeVisionImageInput() error = %v, want unsupported bundle", err)
	}
}

func nativeVisionPointsClose(got [][]float64, want [][]float64, tolerance float64) bool {
	if len(got) != len(want) {
		return false
	}
	for index := range want {
		if len(got[index]) != len(want[index]) {
			return false
		}
		for coordinate := range want[index] {
			if math.Abs(got[index][coordinate]-want[index][coordinate]) > tolerance {
				return false
			}
		}
	}
	return true
}

func writeNativeVisionBundleForTest(t *testing.T) string {
	t.Helper()

	bundleDir := t.TempDir()
	writeNativeRuntimeJSONFileForTest(t, filepath.Join(bundleDir, "metadata.json"), map[string]interface{}{
		"bundle_id":            "mobileclip-s2",
		"model_class":          modelClassVision,
		"model":                "mobileclip-s2",
		"output_dimension":     256,
		"source_dimension":     512,
		"projection":           "reshape_256x2_mean_then_l2_normalize",
		"validated_with":       "python-ncnn",
		"validated_output":     "out0",
		"validated_output_dim": 256,
	})
	return bundleDir
}

func writeNativeVisionSourceImageForTest(t *testing.T) string {
	t.Helper()

	img := image.NewNRGBA(image.Rect(0, 0, 512, 256))
	fillNativeVisionRect(img, image.Rect(0, 0, 128, 256), color.NRGBA{R: 0, G: 0, B: 0, A: 255})
	fillNativeVisionRect(img, image.Rect(128, 0, 256, 256), color.NRGBA{R: 255, G: 0, B: 0, A: 255})
	fillNativeVisionRect(img, image.Rect(256, 0, 384, 256), color.NRGBA{R: 0, G: 255, B: 0, A: 255})
	fillNativeVisionRect(img, image.Rect(384, 0, 512, 256), color.NRGBA{R: 0, G: 0, B: 255, A: 255})

	path := filepath.Join(t.TempDir(), "source.png")
	file, err := os.Create(path)
	if err != nil {
		t.Fatalf("os.Create(%s) error = %v", path, err)
	}
	defer file.Close()
	if err := png.Encode(file, img); err != nil {
		t.Fatalf("png.Encode() error = %v", err)
	}
	return path
}

func fillNativeVisionRect(img *image.NRGBA, rect image.Rectangle, value color.NRGBA) {
	for y := rect.Min.Y; y < rect.Max.Y; y++ {
		for x := rect.Min.X; x < rect.Max.X; x++ {
			img.SetNRGBA(x, y, value)
		}
	}
}

func writeNativeVisionReadyManifestForTest(t *testing.T, bundleDir string, bundleID string) {
	t.Helper()

	raw, err := json.Marshal(bundleReadyManifest{
		BundleID:   bundleID,
		ModelClass: modelClassVision,
		Artifacts: []string{
			"model.param",
			"model.bin",
			"metadata.json",
		},
	})
	if err != nil {
		t.Fatalf("json.Marshal(bundleReadyManifest) error = %v", err)
	}
	if err := os.WriteFile(filepath.Join(bundleDir, ".ready.json"), raw, 0o644); err != nil {
		t.Fatalf("WriteFile(.ready.json) error = %v", err)
	}
}
