package main

import (
	"fmt"
	"math"
	"reflect"
	"runtime"
	"testing"
)

func nativeYOLOLayoutFixture(rows, classes, hits int, layout string) (nativeVisionOutputMat, nativePreparedVisionInput) {
	cols := 4 + classes
	values := make([]float32, rows*cols)
	for row := 0; row < hits; row++ {
		entry := values[row*cols : (row+1)*cols]
		entry[0], entry[1], entry[2], entry[3] = float32(row%80*7+4), float32(row/80*7+84), 4, 4
		entry[4+row%classes] = 0.8
	}
	output := nativeVisionOutputMat{values: values, dims: 2, width: cols, height: rows, channels: 1, depth: 1}
	switch layout {
	case "row3":
		output.dims, output.height, output.channels = 3, rows/2, 2
	case "row4":
		output.dims, output.height, output.channels = 4, rows/2, 2
	case "channel1":
		output.dims = 3
	case "fallback":
		output.dims, output.width, output.height = 1, len(values), 1
	case "depth2fallback":
		output.dims, output.height, output.depth = 4, rows/2, 2
	case "feature2", "feature3", "feature4":
		transposed := make([]float32, len(values))
		for row := 0; row < rows; row++ {
			for col := 0; col < cols; col++ {
				transposed[col*rows+row] = values[row*cols+col]
			}
		}
		output.values = transposed
		output.width, output.height = rows, cols
		if layout != "feature2" {
			output.dims, output.width, output.height, output.channels = 3, rows/2, 2, cols
		}
		if layout == "feature4" {
			output.dims = 4
		}
	}
	input := nativePreparedVisionInput{profile: nativeVisionProfile{kind: nativeVisionProfileYOLOv8Detect, classCount: classes}, width: 640, height: 640, sourceWidth: 400, sourceHeight: 300, scale: 1.6, padY: 80}
	return output, input
}

func nativeYOLOOriginalOutput(output nativeVisionOutputMat, input nativePreparedVisionInput, requested string) (map[string]interface{}, error) {
	values, rows, cols, err := nativeYOLOReferenceRows(input.profile, output.values, output.dims, output.width, output.height, output.depth, output.channels)
	if err != nil {
		return nil, err
	}
	return nativeYOLOReferenceDecode(values, rows, cols, input, requested), nil
}

func TestNativeYOLOMatDecodingMatchesOriginalLayoutsAndFiltering(t *testing.T) {
	for _, layout := range []string{"row2", "feature2", "row3", "feature3", "row4", "feature4", "channel1", "fallback", "depth2fallback"} {
		for _, hits := range []int{0, 1, 16, 96} {
			for _, requested := range []string{"", "person", " CAT ", "missing"} {
				t.Run(fmt.Sprintf("%s/%d/%s", layout, hits, requested), func(t *testing.T) {
					output, input := nativeYOLOLayoutFixture(96, 3, hits, layout)
					before := append([]float32(nil), output.values...)
					want, wantErr := nativeYOLOOriginalOutput(output, input, requested)
					got, err := decodeNativeYOLOv8OutputMatWithClass(output, input.profile, input, requested)
					if err != nil || wantErr != nil || !reflect.DeepEqual(got, want) {
						t.Fatalf("changed output: got=%#v err=%v want=%#v err=%v", got, err, want, wantErr)
					}
					if !reflect.DeepEqual(output.values, before) {
						t.Fatal("decoding modified native output")
					}
				})
			}
		}
	}
}

func TestNativeYOLOMatDecodingPreservesThresholdTiesNMSAndFaceResults(t *testing.T) {
	output, input := nativeYOLOLayoutFixture(12, 3, 0, "row2")
	input.profile.faceBundle = true
	input.profile.classLabels = []string{"face", "cat", "dog"}
	entries := [][]float32{
		{100, 200, 40, 50, .25, .25, 0}, // equality at threshold and first-class tie
		{100, 200, 40, 50, .25, 0, 0},   // equal score and box: stable NMS
		{100, 200, 40, 50, 0, .25, 0},   // same box, different class survives
		{200, 200, 0, 50, .9, 0, 0},     // zero width
		{200, 200, 40, -1, .9, 0, 0},    // negative height
		{300, 200, 40, 50, float32(math.Nextafter32(.25, 0)), 0, 0},
		{350, 200, 40, 50, float32(math.Nextafter32(.25, 1)), 0, 0},
	}
	for i, entry := range entries {
		copy(output.values[i*7:], entry)
	}
	feature := nativeVisionOutputMat{values: make([]float32, len(output.values)), dims: 2, width: 12, height: 7}
	for row := 0; row < 12; row++ {
		for col := 0; col < 7; col++ {
			feature.values[col*12+row] = output.values[row*7+col]
		}
	}
	for _, layout := range []nativeVisionOutputMat{output, feature} {
		for _, requested := range []string{"", "face", " FACE ", "cat"} {
			want, _ := nativeYOLOOriginalOutput(layout, input, requested)
			got, err := decodeNativeYOLOv8OutputMatWithClass(layout, input.profile, input, requested)
			if err != nil || !reflect.DeepEqual(got, want) {
				t.Fatalf("changed face/NMS result: got=%#v err=%v want=%#v", got, err, want)
			}
		}
	}
	for _, invalid := range []nativeVisionOutputMat{{}, {values: []float32{1, 2, 3}}} {
		if _, err := decodeNativeYOLOv8OutputMatWithClass(invalid, input.profile, input, ""); err == nil {
			t.Fatal("accepted invalid output shape")
		}
	}
	input.profile.classCount = 0
	if _, err := decodeNativeYOLOv8OutputMatWithClass(output, input.profile, input, ""); err == nil {
		t.Fatal("accepted invalid class count")
	}
}

func TestNativeYOLOEmptyMatDoesNotAllocateFullTransposeOrCandidates(t *testing.T) {
	for _, layout := range []string{"row2", "feature2"} {
		output, input := nativeYOLOLayoutFixture(8400, 80, 0, layout)
		runtime.GC()
		var before, after runtime.MemStats
		runtime.ReadMemStats(&before)
		for i := 0; i < 8; i++ {
			result, err := decodeNativeYOLOv8OutputMatWithClass(output, input.profile, input, "")
			if err != nil || len(result["detections"].([]map[string]interface{})) != 0 {
				t.Fatalf("empty output: %v", err)
			}
		}
		runtime.ReadMemStats(&after)
		if perImage := (after.TotalAlloc - before.TotalAlloc) / 8; perImage > 64<<10 {
			t.Fatalf("%s: empty image still allocates full transpose/candidate storage: %d bytes/image", layout, perImage)
		}
	}
}

func TestNativeVisionDetectUsesLoadedModelOutputShape(t *testing.T) {
	bundleDir := writeNativeSplitFaceBundleForTest(t)
	r := newNativeSplitFaceRuntimeForTest(t, bundleDir)
	input, err := prepareNativeVisionImageInput(bundleDir, map[string]interface{}{"image": writeNativeVisionSourceImageForTest(t)})
	if err != nil {
		t.Fatal(err)
	}
	// Prepared metadata may differ from the profile of the already loaded net.
	// Its tensor shape must still be interpreted with the loaded model profile.
	input.profile.classCount = 2
	result, err := r.detectVision(modelClassVision, input, 0, "face", false)
	if err != nil || len(result["faces"].([]map[string]interface{})) != 1 {
		t.Fatalf("loaded output shape changed: result=%#v err=%v", result, err)
	}
}
