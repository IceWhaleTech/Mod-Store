package main

// This view stays within the lifetime of the extracted native Mat. Feature-
// major tensors can be decoded directly instead of materializing a transpose.
type nativeYOLOv8OutputView struct {
	values       []float32
	rows, cols   int
	featureMajor bool
}

func nativeYOLOv8ViewFromMat(output nativeVisionOutputMat, profile nativeVisionProfile) (nativeYOLOv8OutputView, error) {
	rows, cols, err := nativeYOLOv8OutputShape(profile, len(output.values))
	if err != nil {
		return nativeYOLOv8OutputView{}, err
	}
	view := nativeYOLOv8OutputView{values: output.values, rows: rows, cols: cols}
	dims := output.dims
	if dims == 4 && output.depth == 1 {
		dims = 3
	}
	if dims == 3 && output.channels == 1 {
		dims = 2
	}
	switch dims {
	case 2:
		switch {
		case output.width == cols && output.height > 0:
			view.rows = output.height
		case output.height == cols && output.width > 0:
			view.rows, view.featureMajor = output.width, true
		}
	case 3:
		if output.width > 0 && output.height > 0 && output.channels > 0 && len(output.values) == output.width*output.height*output.channels {
			switch {
			case output.width == cols:
				view.rows = output.height * output.channels
			case output.channels == cols:
				view.rows, view.featureMajor = output.width*output.height, true
			}
		}
	}
	return view, nil
}

func (view nativeYOLOv8OutputView) bestClass(row int) (int, float64) {
	if !view.featureMajor {
		start := row * view.cols
		return nativeYOLOv8BestClass(view.values[start+4 : start+view.cols])
	}
	bestIndex, bestScore := 0, float64(view.values[4*view.rows+row])
	for class := 1; class < view.cols-4; class++ {
		score := float64(view.values[(class+4)*view.rows+row])
		if score > bestScore {
			bestIndex, bestScore = class, score
		}
	}
	return bestIndex, bestScore
}

func decodeNativeYOLOv8OutputMatWithClass(output nativeVisionOutputMat, profile nativeVisionProfile, input nativePreparedVisionInput, requestedClass string) (map[string]interface{}, error) {
	view, err := nativeYOLOv8ViewFromMat(output, profile)
	if err != nil {
		return nil, err
	}
	return decodeNativeYOLOv8DetectOutputView(view, input, requestedClass), nil
}
