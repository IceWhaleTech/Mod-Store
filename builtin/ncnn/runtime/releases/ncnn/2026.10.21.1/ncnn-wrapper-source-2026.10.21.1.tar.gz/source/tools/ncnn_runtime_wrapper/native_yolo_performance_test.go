package main

import (
	"fmt"
	"testing"
)

func BenchmarkNativeYOLOPostprocess(b *testing.B) {
	for _, layout := range []string{"row2", "feature2"} {
		for _, hits := range []int{0, 16, 512} {
			b.Run(fmt.Sprintf("%s/%d", layout, hits), func(b *testing.B) {
				output, input := nativeYOLOLayoutFixture(8400, 80, hits, layout)
				b.ReportAllocs()
				b.ResetTimer()
				for i := 0; i < b.N; i++ {
					result, err := decodeNativeYOLOv8OutputMatWithClass(output, input.profile, input, "")
					if err != nil || len(result["detections"].([]map[string]interface{})) != hits {
						b.Fatalf("postprocess: %v", err)
					}
				}
			})
		}
	}
}
