package main

import "strings"

// Frozen pre-round-7 row decoder, retained only as an independent parity oracle.
func nativeYOLOReferenceDecode(values []float32, rows, cols int, input nativePreparedVisionInput, requestedClass string) map[string]interface{} {
	requestedClass = strings.ToLower(strings.TrimSpace(requestedClass))
	if rows <= 0 || cols <= 4 || len(values) < rows*cols {
		output := map[string]interface{}{
			"objects":    []string{},
			"detections": []map[string]interface{}{},
		}
		if input.profile.faceBundle {
			output["faces"] = []map[string]interface{}{}
		}
		return output
	}
	candidates := make([]nativeYOLOv8Detection, 0, rows)
	for row := 0; row < rows; row++ {
		start := row * cols
		entry := values[start : start+cols]
		classID, score := nativeYOLOv8BestClass(entry[4:])
		if classID < 0 || score < defaultYOLOv8DetectScoreThreshold {
			continue
		}
		label := nativeYOLOv8ClassLabel(input.profile, classID)
		if requestedClass != "" && label != requestedClass {
			continue
		}
		detection := nativeYOLOv8ProjectDetection(nativeYOLOv8Detection{
			ClassID:    classID,
			Label:      label,
			Confidence: score,
			CX:         float64(entry[0]),
			CY:         float64(entry[1]),
			W:          float64(entry[2]),
			H:          float64(entry[3]),
		}, input)
		if detection.W <= 0 || detection.H <= 0 {
			continue
		}
		candidates = append(candidates, detection)
	}
	kept := nativeYOLOv8ApplyNMS(candidates, defaultYOLOv8DetectNMSThreshold)
	objects := make([]string, 0, len(kept))
	seenObjects := make(map[string]struct{}, len(kept))
	detections := make([]map[string]interface{}, 0, len(kept))
	for _, detection := range kept {
		if _, ok := seenObjects[detection.Label]; !ok && detection.Label != "" {
			seenObjects[detection.Label] = struct{}{}
			objects = append(objects, detection.Label)
		}
		detections = append(detections, map[string]interface{}{
			"class_id":   detection.ClassID,
			"label":      detection.Label,
			"confidence": detection.Confidence,
			"left":       detection.Left,
			"top":        detection.Top,
			"right":      detection.Right,
			"bottom":     detection.Bottom,
			"cx":         detection.CX,
			"cy":         detection.CY,
			"w":          detection.W,
			"h":          detection.H,
		})
	}
	output := map[string]interface{}{
		"objects":    objects,
		"detections": detections,
	}
	if input.profile.faceBundle {
		output["faces"] = nativeFaceOutputsFromDetections(detections, input)
	}
	return output
}

func nativeYOLOReferenceRows(profile nativeVisionProfile, values []float32, dims, width, height, depth, channels int) ([]float32, int, int, error) {
	rows, cols, err := nativeYOLOv8OutputShape(profile, len(values))
	if err != nil {
		return nil, 0, 0, err
	}
	switch dims {
	case 2:
		switch {
		case width == cols && height > 0:
			return values, height, cols, nil
		case height == cols && width > 0:
			reordered := make([]float32, len(values))
			for row := 0; row < width; row++ {
				for col := 0; col < height; col++ {
					reordered[row*height+col] = values[col*width+row]
				}
			}
			return reordered, width, height, nil
		}
	case 3:
		switch {
		case channels == 1:
			return nativeYOLOReferenceRows(profile, values, 2, width, height, 0, 0)
		case width == cols && height > 0 && channels > 0 && len(values) == width*height*channels:
			return values, height * channels, cols, nil
		case channels == cols && width > 0 && height > 0 && len(values) == width*height*channels:
			reordered := make([]float32, 0, len(values))
			for y := 0; y < height; y++ {
				for x := 0; x < width; x++ {
					for ch := 0; ch < channels; ch++ {
						index := ch*width*height + y*width + x
						reordered = append(reordered, values[index])
					}
				}
			}
			return reordered, width * height, channels, nil
		}
	case 4:
		if depth == 1 {
			return nativeYOLOReferenceRows(profile, values, 3, width, height, 0, channels)
		}
	}
	return values, rows, cols, nil
}
